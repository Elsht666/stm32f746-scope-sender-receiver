> **当前交付：SAVE-USB R6。请先阅读《最新版R6说明.md》。图片已改为八位快照标识命名的 BMP；下文旧版本的 SCREEN.BMP 描述以 R6 说明为准。**

# 远程数据采集系统（双 STM32F746G-DISCO 以太网示波器）— 无脚本、全 main.c 版

> 版本：AllInMain（在已验证可用的 R3 基础上重构）
> 工具链：STM32CubeMX 6.18.1（生成时选 **EWARM**、最低 **V8.32**）；IAR for ARM **8.32.1**（编译 / 下载 / 校验）
> 本版功能、接线、协议与已验证 R3 **完全不变**，只改变工程组织方式。

## 0. 这是给你的几句话（初学者先读）

- **两个独立工程**：`ScopeSender`（发送板，采集并网口发数据）、`ScopeReceiver`（接收板，网口收数据并显示/存盘）。
- **所有功能代码都写在各自 `Src/main.c` 的 USER CODE 0 段里**，只用 **C 语言 + STM32 HAL 库** 两件套，**不依赖任何 `.py` 脚本**，也没有 `App/`、`tools/` 目录。
- 所以：**解压 → 打开 → Rebuild All → 下载**，就这么简单。**不需要**运行任何脚本。
- 你习惯每次用 CubeMX 重新生成，没关系：功能代码全部在 CubeMX 会保留的 USER CODE 区里，重新生成**不会覆盖**。
- **唯一要你在 IAR 里手动核对的一项**（关系到 DMA 能否工作）：见第 4 节「CubeMX 再生成后的唯一手动核对项」。

## 1. 工程结构

```
ScopeSystem_IAR832_R3_AllInMain/
├── ScopeSystem.eww                  ← 顶层工作区（同时加载发送端、接收端）
├── README.md                        ← 本说明（唯一权威入口）
├── 新版接线与使用说明.md             ← 接线与通道定义（与 R3 一致，可作参考）
├── ScopeSender/                      ← 发送板工程
│   ├── Src/main.c                   ← ★ 全部发送功能代码（采集/打包/触发/网络/显示）
│   ├── Src/fmc.c / eth.c / tim.c / adc.c / ...（CubeMX 生成，勿手改，USER CODE 保留调用）
│   ├── Inc/                         ← 头文件（含 scope_project_config.h）
│   └── EWARM/ScopeSender.ewp/.eww   ← IAR 工程
└── ScopeReceiver/                    ← 接收板工程
    ├── Src/main.c                   ← ★ 全部接收功能代码（解码/触发/显示/USB存盘）
    ├── Src/fmc.c / eth.c / usbd_storage_if.c / ...（CubeMX 生成，USER CODE 保留调用）
    ├── Inc/
    └── EWARM/ScopeReceiver.ewp/.eww
```

两个 `Src/main.c` 是最重要、也是唯一需要你日后修改的文件；所有其它 `Src/*.c` 都是 CubeMX 生成的板级文件，**不要再动它们**（只有 `fmc.c`、`usbd_storage_if.c` 里已经放好的几行 USER CODE 调用保留着，那正是接 main.c 的入口）。

## 2. 下载到板子前，先用 IAR 编译（Reuild All）

1. 完整解压本包，双击打开根目录 **`ScopeSystem.eww`**（也可分别打开 `ScopeSender/EWARM/ScopeSender.eww`、`ScopeReceiver/EWARM/ScopeReceiver.eww`）。
2. 左侧工程树选中 **ScopeSender**，菜单 **Project → Rebuild All**，看底部无 0 错误、0 警告。
3. 再选中 **ScopeReceiver**，同样 **Project → Rebuild All**。
4. 若出现任何错误，把完整报错贴给我，**不要自己蒙着改**。

> 提示：当前两份 `.ewp` 已把优化设为 **High/Speed（Level 3）**、链接配置指向 **`stm32f746xx_flash.icf`**（RAM 起点 0x20010000），与已验证 R3 完全一致，无需你再设。

## 3. 下载与运行

1. **发送板**：Project → Download and Debug（Ctrl+D），探针选发送板 ST-LINK（序号末 8 位 43244853），进入 main 后按 F5。发送屏标题应为 `SCOP R3 SENDER`，`CN9: LINK 100Mbps`。
2. **接收板**：同法下载，探针选接收板（序号末 8 位 67244354）。两块板同时接时按角色选探针。
3. 两板各自经 CN14 供电，**CN9 之间插网线**，链路应显示 100Mbps。
4. 接收端默认五通道、10ms/div、AUTO；先显示 `CFG WAIT`，发送端确认配置后变 `AUTO` / `HW TRIG`。
5. 旋转发送板电位器，接收端 CH1 直流位置实时变化；对麦克风说话，CH2 变化。`RX/LOSS/CRC` 在正常时稳定（LOSS、CRC 不持续增长）。

接线和通道定义（CH1=A1/PF10、CH2=A0/PA0、D0=D9/PA15、D1=D7/PI3、D2=D8/PI2、D3=PB4 方波）与 R3 完全一致，详见《新版接线与使用说明.md》，此处不再重复。

## 4. ★ CubeMX 再生成后的唯一手动核对项（关系到 DMA 能否工作）

你每次都用 CubeMX 重新生成工程。生成后，**功能代码不会丢**（都在 USER CODE 区），但 **IAR 的链接配置文件有可能被 CubeMX 改回默认 RAM 起点**。你必须手动核对一次：

**对两端分别执行：`Project → Options（Alt+F7）→ Linker → Config`**
- 确认 `Linker configuration file` 是勾选 `Override default`，且文件为 **`$PROJ_DIR$\stm32f746xx_flash.icf`**。
- 打开这份 `.icf`，看第 9 行：
  ```
  define symbol __ICFEDIT_region_RAM_start__ = 0x20010000;
  ```
  必须是 **0x20010000**（不是 0x20000000）。

**为什么这行最重要**：以太网 DMA 描述符表用 `#pragma location` 固定在 SRAM 高地址（0x2004C000 附近）。如果 RAM 起点被 CubeMX 改回 0x20000000，链接器会把 `.data/.bss/堆栈` 铺到 0x2004C000 附近，和 DMA 描述符**重叠**，导致以太网 DMA 收发错乱、接收板收不到数据。所以 CubeMX 再生成后，请务必核对这一项。

> 其它都不用管：`scope_project_config.h` 里的 RX16/TX4（发送）、RX64/TX4（接收）计数、优化 High/Speed、应用入口调用，全部在 USER CODE / 保留文件中，CubeMX 不会动。

## 5. 出问题怎么办

- **不要猜、不要蒙着改**。本机没有 IAR 编译器，最终编译结果以你在 IAR 里 Rebuild All 为准。
- 若 Rebuild All 报错：把**完整错误文本**发我，我据此修。
- 若编译通过但实板现象异常：说明板子、接线、探针选择等，我帮你定位。

## 6. 验证清单（交付前你自己可在实板过一遍）

- [ ] 两端 Rebuild All：0 错误、0 警告。
- [ ] 发送屏 `SCOP R3 SENDER`、`LINK 100Mbps`、CAP/TX 增长、ERR/DROP/RESTART 不持续增长。
- [ ] 接收端五通道、10ms/5ms 波形正常，CH1 电位器、CH2 麦克风实时变化；RX/LOSS/CRC 稳定。
- [ ] 触发：AUTO/NORMAL/SINGLE、RISE/FALL、阈值均可配置并被发送端确认。
- [ ] SAVE USB：接收端点 SAVE 后，插 USB CN13 到电脑可读出 README.TXT、WAVE.CSV、SCREEN.BMP。
