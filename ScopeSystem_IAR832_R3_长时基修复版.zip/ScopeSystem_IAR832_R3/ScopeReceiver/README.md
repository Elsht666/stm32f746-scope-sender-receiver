# ScopeReceiver R3

打开 EWARM/ScopeReceiver.eww，或上级 ScopeSystem.eww。Rebuild All 后下载并运行。当前已设置High/Speed。每次CubeMX再生成后运行tools/post_generate.py，详情见上级R3使用与验证.md。
