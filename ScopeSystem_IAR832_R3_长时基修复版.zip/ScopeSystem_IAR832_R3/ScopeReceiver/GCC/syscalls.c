/* No semihosting or host I/O is used by the firmware. */
#include <errno.h>
#include <stddef.h>
#include <sys/stat.h>
int _write(int fd,char *ptr,int len){(void)fd;(void)ptr;(void)len;errno=ENOSYS;return -1;}
int _read(int fd,char *ptr,int len){(void)fd;(void)ptr;(void)len;errno=ENOSYS;return -1;}
int _close(int fd){(void)fd;errno=EBADF;return -1;}
int _lseek(int fd,int pos,int whence){(void)fd;(void)pos;(void)whence;errno=ESPIPE;return -1;}
int _isatty(int fd){(void)fd;return 0;}
int _fstat(int fd,struct stat *st){(void)fd;st->st_mode=S_IFCHR;return 0;}
int _getpid(void){return 1;}
int _kill(int pid,int sig){(void)pid;(void)sig;errno=EINVAL;return -1;}
void *_sbrk(ptrdiff_t n){
  extern char _end;static char *top;char *old;
  if(!top)top=&_end;
  old=top;
  if(n<0||n>1024-(top-&_end)){errno=ENOMEM;return (void*)-1;}
  top+=n;return old;
}
