#include "scope_core.h"
#include "scope_app.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#undef assert
#define assert(x) do { if(!(x)) { fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#x); exit(1); } } while(0)
static uint32_t ring[SCOPE_RING_SIZE];
static uint8_t packet[32+4*256];
static uint16_t pixels[480*272];
void Scope_DiskBuild(const ScopeFrame*,const uint16_t*);
int Scope_DiskDump(const char*);
static void p16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void p32(uint8_t *p,uint32_t v){p16(p,(uint16_t)v);p16(p+2,(uint16_t)(v>>16));}
static uint16_t analog(uint32_t i,int ch){return (uint16_t)(2048+(ch?800:1200)*sin(6.283185307179586*(ch?2000:1000)*i/500000.0));}
static void make_packet(uint32_t seq,uint32_t first,uint8_t reset){
  memset(packet,0,sizeof(packet));memcpy(packet,"SCOP",4);packet[4]=packet[5]=1;p16(packet+6,256);p32(packet+8,seq);p32(packet+12,first);
  p32(packet+16,500000);p16(packet+20,3300);packet[22]=31;packet[23]=reset;
  for(unsigned n=0;n<256;n++){uint32_t i=first+n,d=(i%1000<50)|((i%500<125)<<1)|((i%250<62)<<2);p32(packet+32+n*4,analog(i,0)|((uint32_t)analog(i,1)<<12)|(d<<24));}
  p32(packet+28,Scope_CRC32(packet,28,packet+32,1024));
}
static uint16_t checksum(const uint8_t *p,unsigned n,uint32_t sum){while(n>1){sum+=((unsigned)p[0]<<8)|p[1];p+=2;n-=2;}if(n)sum+=(unsigned)p[0]<<8;while(sum>>16)sum=(sum&65535)+(sum>>16);return (uint16_t)~sum;}
static void be16put(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
int main(int argc,char **argv){
  assert(Scope_CRC32((const uint8_t*)"123456789",9,0,0)==0xCBF43926u);
  ScopeStream s;Scope_Reset(&s,ring);ScopeConfig c={0,31,0,0,0,2048};ScopeFrame f;
  for(unsigned n=0;n<256;n++){make_packet(n,n*256,n==0);assert(Scope_Ingest(&s,packet,sizeof(packet),n));}
  assert(s.valid==65536&&s.packets==256&&s.lost==0);
  for(int tb=0;tb<5;tb++){
    c.timebase=(uint8_t)tb;assert(Scope_MakeFrame(&s,&c,&f)==1);assert(f.step==scope_timebase_us[tb]/100);
    assert(f.triggered);assert((uint64_t)f.step*50000000/s.rate==scope_timebase_us[tb]);
    if(tb<3){assert(f.frequency_mhz[0]>990000&&f.frequency_mhz[0]<1010000);assert(f.frequency_mhz[1]>1980000&&f.frequency_mhz[1]<2020000);}
    if(tb<4)assert(f.vpp_mv[0]>1900&&f.vpp_mv[0]<1950);
    printf("timebase=%luus step=%lu trigger=%u CH1=%lumHz CH2=%lumHz D0=%luus\n",(unsigned long)scope_timebase_us[tb],(unsigned long)f.step,f.triggered,(unsigned long)f.frequency_mhz[0],(unsigned long)f.frequency_mhz[1],(unsigned long)f.width_us[0]);
  }
  c.timebase=2;c.source=2;c.mode=1;
  assert(Scope_MakeFrame(&s,&c,&f)==1&&f.triggered);assert(f.width_us[0]==100);assert(f.frequency_mhz[2]==500000);
  unsigned transitions=0;for(unsigned i=1;i<400;i++)if(((f.sample[i]^f.sample[i-1])>>24)&1)transitions++;
  assert(transitions>0); /* 0.1 ms digital pulses remain visible at 1 ms/div. */
  c.source=1;c.falling=1;assert(Scope_MakeFrame(&s,&c,&f)==1&&f.triggered);
  c.channels=1;assert(Scope_MakeFrame(&s,&c,&f)==1&&f.channels==1&&f.frequency_mhz[1]==0);
  c.channels=31;c.source=0;c.falling=0;c.timebase=0;assert(Scope_MakeFrame(&s,&c,&f)==1);
  if(argc>1){for(unsigned y=0;y<272;y++)for(unsigned x=0;x<480;x++)pixels[y*480+x]=(uint16_t)(((x*31/479)<<11)|((y*63/271)<<5)|(x*31/479));Scope_DiskBuild(&f,pixels);assert(Scope_DiskReady());assert(Scope_DiskDump(argv[1])==0);uint8_t sector[512];assert(Scope_DiskRead(sector,2048,1)!=0);assert(Scope_DiskRead(sector,0,1)==0&&sector[510]==0x55);}
  /* Corruption, duplicate, forward gap, insufficient history, source restart. */
  make_packet(256,65536,0);packet[40]^=0x40;assert(!Scope_Ingest(&s,packet,sizeof(packet),300)&&s.bad==1);
  make_packet(255,65280,0);assert(!Scope_Ingest(&s,packet,sizeof(packet),300)&&s.stale==1);
  make_packet(257,65792,0);assert(Scope_Ingest(&s,packet,sizeof(packet),300)&&s.lost==1&&s.valid==256);assert(!Scope_MakeFrame(&s,&c,&f));
  make_packet(0,0,1);assert(Scope_Ingest(&s,packet,sizeof(packet),301)&&s.valid==256);
  /* Sequence and sample-index wrap are valid. */
  make_packet(0xFFFFFFFFu,0xFFFFFF00u,1);assert(Scope_Ingest(&s,packet,sizeof(packet),302));make_packet(0,0,0);assert(Scope_Ingest(&s,packet,sizeof(packet),303)&&s.valid==512);
  make_packet(1,256,0);p32(packet+16,5000);p32(packet+28,Scope_CRC32(packet,28,packet+32,1024));assert(Scope_Ingest(&s,packet,sizeof(packet),304));c.timebase=4;assert(Scope_MakeFrame(&s,&c,&f)==-1);
  /* Exercise the real Ethernet/IP/UDP parser, including a nonzero UDP checksum. */
  uint8_t eth[14+20+8+sizeof(packet)];memset(eth,0,sizeof(eth));memset(eth,255,6);eth[12]=8;eth[14]=0x45;be16put(eth+16,sizeof(eth)-14);eth[22]=64;eth[23]=17;
  eth[26]=192;eth[27]=168;eth[28]=7;eth[29]=1;memset(eth+30,255,4);be16put(eth+24,checksum(eth+14,20,0));be16put(eth+34,5001);be16put(eth+36,5000);be16put(eth+38,8+sizeof(packet));memcpy(eth+42,packet,sizeof(packet));size_t n=0;
  assert(Scope_UDP(eth,sizeof(eth),&n)==eth+42&&n==sizeof(packet));
  uint32_t pseudo=17+8+sizeof(packet);for(int i=26;i<34;i+=2)pseudo+=((uint32_t)eth[i]<<8)|eth[i+1];be16put(eth+40,checksum(eth+34,8+sizeof(packet),pseudo));assert(Scope_UDP(eth,sizeof(eth),&n));
  eth[50]^=1;assert(!Scope_UDP(eth,sizeof(eth),&n));eth[50]^=1;
  eth[20]=0x20;assert(!Scope_UDP(eth,sizeof(eth),&n));eth[20]=0;
  for(size_t i=0;i<42;i++)assert(!Scope_UDP(eth,i,&n));
  puts("PASS: CRC, rates, ring wrap, triggers, raw measurements, channels, loss/reorder, UDP, disk export");return 0;
}
