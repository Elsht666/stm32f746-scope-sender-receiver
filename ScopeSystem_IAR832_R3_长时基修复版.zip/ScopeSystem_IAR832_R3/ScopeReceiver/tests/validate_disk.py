"""Independent FAT12/CSV/BMP validation of the image produced by test_scope.c."""
import csv,io,struct,sys
from pathlib import Path
data=Path(sys.argv[1]).read_bytes()
u16=lambda p:struct.unpack_from('<H',data,p)[0]
assert len(data)==1048576 and data[510:512]==b'\x55\xaa'
sector=u16(11);spc=data[13];reserved=u16(14);fats=data[16];roots=u16(17);fat_sectors=u16(22)
assert (sector,spc,reserved,fats,roots,fat_sectors)==(512,1,1,2,64,6)
assert data[512:7*512]==data[7*512:13*512]
root_sector=reserved+fats*fat_sectors;data_sector=root_sector+(roots*32+511)//512
def cluster_next(c):
    off=512+c+c//2;pair=u16(off)
    return (pair>>4 if c&1 else pair)&0xFFF
files={}
allocated=set()
for off in range(root_sector*512,(root_sector*512)+roots*32,32):
    entry=data[off:off+32]
    if not entry[0]:break
    name=entry[:8].decode().rstrip()+'.'+entry[8:11].decode().rstrip()
    c=struct.unpack_from('<H',entry,26)[0];size=struct.unpack_from('<I',entry,28)[0];buf=bytearray();seen=set()
    while c<0xFF8:
        assert 2<=c<2033 and c not in seen and c not in allocated
        seen.add(c);allocated.add(c);start=(data_sector+c-2)*512;buf+=data[start:start+512];c=cluster_next(c)
    assert len(buf)-512<size<=len(buf)
    files[name]=bytes(buf[:size])
assert set(files)=={'README.TXT','WAVE.CSV','SCREEN.BMP'}
rows=list(csv.DictReader(io.StringIO(files['WAVE.CSV'].decode())))
assert len(rows)==400 and int(rows[0]['time_us'])==0 and int(rows[-1]['time_us'])==79800
assert all(int(rows[i]['time_us'])-int(rows[i-1]['time_us'])==200 for i in range(1,400))
assert all(int(r['D0']) in [0,1] and 0<=int(r['CH1_mV'])<=3300 for r in rows)
bmp=files['SCREEN.BMP'];assert bmp[:2]==b'BM' and struct.unpack_from('<I',bmp,2)[0]==len(bmp)
assert struct.unpack_from('<ii',bmp,18)==(480,272) and struct.unpack_from('<H',bmp,28)[0]==24
assert bmp[54:57]==b'\x00\xff\x00' and bmp[-3:]==b'\xff\x00\xff'
print('PASS: FAT12 boot sector, both FATs, nonoverlapping exact cluster chains, 400 CSV samples, BMP size/format/orientation')
