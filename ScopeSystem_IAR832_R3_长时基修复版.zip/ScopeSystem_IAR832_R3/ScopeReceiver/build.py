"""Offline build using an installed GNU Arm toolchain (Python 3 standard library only)."""
from pathlib import Path
import os,shutil,subprocess,sys,concurrent.futures
ROOT=Path(__file__).resolve().parent
def find_gcc():
    override=os.environ.get('GCC_ARM_BIN')
    if override:return Path(override)/'arm-none-eabi-gcc.exe'
    found=shutil.which('arm-none-eabi-gcc')
    if found:return Path(found)
    for p in [Path('C:/32/ST'),Path('C:/ST')]:
        if p.exists():
            found=next(p.glob('**/arm-none-eabi-gcc.exe'),None)
            if found:return found
    raise SystemExit('GNU Arm compiler not found. Set GCC_ARM_BIN to its bin directory.')
def main():
    gcc=find_gcc();bindir=gcc.parent;out=ROOT/'Build';out.mkdir(exist_ok=True)
    includes=['Inc','App','Drivers/CMSIS/Include','Drivers/CMSIS/Device/ST/STM32F7xx/Include','Drivers/STM32F7xx_HAL_Driver/Inc','Drivers/STM32F7xx_HAL_Driver/Inc/Legacy','Middlewares/ST/STM32_USB_Device_Library/Core/Inc','Middlewares/ST/STM32_USB_Device_Library/Class/MSC/Inc']
    flags=['-mcpu=cortex-m7','-mthumb','-mfpu=fpv5-sp-d16','-mfloat-abi=hard','-O2','-g3','-ffunction-sections','-fdata-sections','-Wall','-Wextra','-Wno-unused-parameter','-DSTM32F746xx','-DUSE_HAL_DRIVER','-DETH_RX_DESC_CNT=64','-DETH_TX_DESC_CNT=4']
    for i in includes:flags+=['-I',str(ROOT/i)]
    sources=list((ROOT/'Src').glob('*.c'))+list((ROOT/'App').glob('*.c'))+list((ROOT/'GCC').glob('*.c'))+list((ROOT/'Drivers/STM32F7xx_HAL_Driver/Src').glob('*.c'))+list((ROOT/'Middlewares').glob('**/Src/*.c'))+[ROOT/'GCC/startup_stm32f746xx.s']
    sources=[p for p in sources if not p.name.endswith('_template.c')]
    objects=[]
    def compile(src):
        obj=out/('_'.join(src.relative_to(ROOT).parts)+'.o')
        cmd=[str(gcc),*flags,('-std=c11' if src.suffix=='.c' else '-x'),*(['assembler-with-cpp'] if src.suffix!='.c' else []),'-c',str(src),'-o',str(obj)]
        r=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        return src,obj,r
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8,os.cpu_count() or 2)) as pool:
        for src,obj,r in pool.map(compile,sources):
            if r.stdout:print(r.stdout,end='')
            results.append(r.returncode);objects.append(obj)
    if any(results):raise SystemExit('Compilation failed')
    elf=out/'ScopeReceiver.elf'
    cmd=[str(gcc),*flags,*map(str,objects),'-T',str(ROOT/'GCC/STM32F746NGHx_FLASH.ld'),'--specs=nano.specs','--specs=nosys.specs','-Wl,--gc-sections','-Wl,--no-warn-rwx-segments','-Wl,-Map='+str(out/'ScopeReceiver.map'),'-Wl,--print-memory-usage','-o',str(elf)]
    subprocess.run(cmd,cwd=ROOT,check=True)
    for fmt,suffix in [('ihex','hex'),('binary','bin')]:subprocess.run([str(bindir/'arm-none-eabi-objcopy.exe'),'-O',fmt,str(elf),str(out/f'ScopeReceiver.{suffix}')],check=True)
    subprocess.run([str(bindir/'arm-none-eabi-size.exe'),str(elf)],check=True)
    print('Built:',elf)
if __name__=='__main__':main()
