"""Reapply the receiver application integration after CubeMX Generate Code."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
def block(path,tag,text):
    p=ROOT/path;s=p.read_text(encoding='utf8')
    pattern=r'(/\* USER CODE BEGIN '+re.escape(tag)+r' \*/).*?(/\* USER CODE END '+re.escape(tag)+r' \*/)'
    s,n=re.subn(pattern,lambda m:m[1]+'\n'+text+'\n  '+m[2],s,flags=re.S)
    if n!=1:raise RuntimeError(f'Expected one USER CODE {tag} in {path}, found {n}')
    p.write_text(s,encoding='utf8')
def main():
    header=ROOT/'Inc/stm32f7xx_hal_conf.h'
    content=header.read_text()
    if '#include "scope_project_config.h"' not in content:
        content=content.replace('/* USER CODE END Header */','#include "scope_project_config.h"\n/* USER CODE END Header */',1)
        header.write_text(content)
    block('Src/main.c','Includes','#include "scope_app.h"')
    block('Src/main.c','2','  Scope_AppInit();')
    block('Src/main.c','3','    Scope_AppTask();\n  }')
    block('Src/fmc.c','0','#include "scope_app.h"')
    block('Src/fmc.c','FMC_Init 2','  Scope_MemoryInit();')
    block('Src/eth.c','MACADDRESS','  MACAddr[0]=0x02; MACAddr[1]=0x00; MACAddr[2]=0x00;\n  MACAddr[3]=0x00; MACAddr[4]=0x07; MACAddr[5]=0x46;')
    p=ROOT/'Src/eth.c';s=p.read_text();s=re.sub(r'#if defined \( __ICCARM__ \).*?#endif',
        '/* DMA-accessible SRAM; kept portable for GCC and Arm Compiler 6. */\n'
        'ETH_DMADescTypeDef DMARxDscrTab[ETH_RX_DESC_CNT] __attribute__((aligned(32)));\n'
        'ETH_DMADescTypeDef DMATxDscrTab[ETH_TX_DESC_CNT] __attribute__((aligned(32)));',s,count=1,flags=re.S);p.write_text(s)
    block('Src/usbd_storage_if.c','INCLUDE','#include "scope_app.h"')
    block('Src/usbd_storage_if.c','3','  UNUSED(lun); *block_num=2048; *block_size=512; return USBD_OK;')
    block('Src/usbd_storage_if.c','4','  UNUSED(lun); return Scope_DiskReady()?USBD_OK:USBD_FAIL;')
    block('Src/usbd_storage_if.c','5','  UNUSED(lun); return 1; /* read-only medium */')
    block('Src/usbd_storage_if.c','6','  UNUSED(lun); return Scope_DiskRead(buf,blk_addr,blk_len)==0?USBD_OK:USBD_FAIL;')
    block('Src/usbd_storage_if.c','7','  UNUSED(lun); UNUSED(buf); UNUSED(blk_addr); UNUSED(blk_len); return USBD_FAIL;')
    block('Inc/usbd_conf.h','INCLUDE','void *Scope_USB_Alloc(size_t size);\nvoid Scope_USB_Free(void *ptr);')
    p=ROOT/'Inc/usbd_conf.h';s=p.read_text();s=re.sub(r'(#define USBD_malloc\s+)\w+',r'\1Scope_USB_Alloc',s);s=re.sub(r'(#define USBD_free\s+)\w+',r'\1Scope_USB_Free',s);s=re.sub(r'(#define USBD_LPM_ENABLED\s+)\d+U',r'\g<1>0U',s);p.write_text(s)
    block('Src/usbd_conf.c','0','''void *Scope_USB_Alloc(size_t size) {
  static uint32_t storage[512];
  return size<=sizeof(storage)?storage:NULL;
}
void Scope_USB_Free(void *ptr) { (void)ptr; }''')
    # Consistent descriptor counts for every compilation unit and toolchain.
    p=ROOT/'Inc/stm32f7xx_hal_conf.h';s=p.read_text();mark='/* Receiver DMA descriptor counts */';s=re.sub(re.escape(mark)+r'.*?\n\n','',s,flags=re.S)
    s=s.replace('#define HAL_MODULE_ENABLED',mark+'\n#ifndef ETH_RX_DESC_CNT\n#define ETH_RX_DESC_CNT 64U\n#endif\n#ifndef ETH_TX_DESC_CNT\n#define ETH_TX_DESC_CNT 4U\n#endif\n\n#define HAL_MODULE_ENABLED',1);p.write_text(s)
    project=ROOT/'MDK-ARM/ScopeReceiver.uvprojx';
    if project.exists():
        tree=ET.parse(project);target=tree.find('.//Target')
        for tag,value in [('pCCUsed','6190000::V6.19::ARMCLANG'),('uAC6','1')]:
            el=target.find(tag)
            if el is None:el=ET.SubElement(target,tag)
            el.text=value
        def setval(path,value):
            e=target.find(path)
            if e is None:raise RuntimeError('Missing '+path)
            e.text=value
        base='TargetOption/TargetArmAds/'
        setval(base+'Cads/VariousControls/IncludePath',target.find(base+'Cads/VariousControls/IncludePath').text+';../App' if '../App' not in target.find(base+'Cads/VariousControls/IncludePath').text else target.find(base+'Cads/VariousControls/IncludePath').text)
        setval(base+'Cads/VariousControls/MiscControls','-std=c11')
        setval(base+'LDads/umfTarg','0');setval(base+'LDads/useFile','1');setval(base+'LDads/ScatterFile','ScopeReceiver.sct');setval(base+'LDads/DataAddressRange','0x20010000')
        setval('TargetOption/TargetCommonOption/Cpu','IRAM(0x20010000-0x2004FFFF) IROM(0x8000000-0x80FFFFF) CLOCK(200000000) FPU3(SFPU) CPUTYPE("Cortex-M7") ELITTLE')
        groups=target.find('Groups')
        for g in list(groups):
            if g.findtext('GroupName')=='Application/Scope':groups.remove(g)
        g=ET.SubElement(groups,'Group');ET.SubElement(g,'GroupName').text='Application/Scope';files=ET.SubElement(g,'Files')
        for src in sorted((ROOT/'App').glob('*.c')):
            f=ET.SubElement(files,'File');ET.SubElement(f,'FileName').text=src.name;ET.SubElement(f,'FileType').text='1';ET.SubElement(f,'FilePath').text='../App/'+src.name
        ET.indent(tree,space='  ');tree.write(project,encoding='utf-8',xml_declaration=True)
    integrate_iar()
    print('CubeMX application integration applied.')
def integrate_iar():
    """Preserve the custom application when CubeMX generates EWARM projects."""
    project=ROOT/'EWARM/ScopeReceiver.ewp'
    if not project.exists():return
    tree=ET.parse(project)
    for config in tree.findall('configuration'):
        for option in config.findall('.//option'):
            name=option.findtext('name')
            if name in ('CCOptLevel','CCOptStrategy','CCOptStrategySlave'):
                option.find('state').text='3' if name=='CCOptLevel' else '2'
            if name=='CCDefines':
                for item in list(option.findall('state')):
                    if (item.text or '').startswith('SCOPE_IAR_INTEGRATED'):option.remove(item)
                ET.SubElement(option,'state').text='SCOPE_IAR_INTEGRATED=3'
            if name=='CCIncludePath2':
                paths=[s.text for s in option.findall('state')]
                if '$PROJ_DIR$/../App' not in paths:
                    ET.SubElement(option,'state').text='$PROJ_DIR$/../App'
            elif name=='IlinkMapFile':option.find('state').text='1'
            elif name=='IlinkIcfOverride':option.find('state').text='1'
            elif name=='IlinkIcfFile':option.find('state').text='$PROJ_DIR$/stm32f746xx_flash.icf'
    groups=tree.getroot()
    for group in list(groups):
        if group.tag=='group' and (group.findtext('name') or '').startswith('Application/'):
            groups.remove(group)
    group=ET.SubElement(groups,'group')
    ET.SubElement(group,'name').text='Application/Receiver'
    for source in sorted((ROOT/'App').glob('*.c')):
        entry=ET.SubElement(group,'file')
        ET.SubElement(entry,'name').text='$PROJ_DIR$/../App/'+source.name
    entry=ET.SubElement(group,'file')
    ET.SubElement(entry,'name').text='$PROJ_DIR$/../Inc/scope_project_config.h'
    normalize_iar_sources(tree)
    ET.indent(tree,space='  ')
    tree.write(project,encoding='utf-8',xml_declaration=True)
    icf=ROOT/'EWARM/stm32f746xx_flash.icf'
    s=icf.read_text()
    s=re.sub(r'(__ICFEDIT_region_RAM_start__\s*=\s*)0x[0-9A-Fa-f]+',r'\g<1>0x20010000',s)
    icf.write_text(s)

def normalize_iar_sources(tree):
    """Repair CubeMX absolute entries and remove duplicate source references."""
    for entry in tree.findall('.//file/name'):
        value=(entry.text or '').replace('\\','/')
        marker='/'+ROOT.name+'/'
        if marker in value:
            rel=value.rsplit(marker,1)[1]
            if not (ROOT/rel).is_file():raise RuntimeError('Missing source: '+value)
            entry.text='$PROJ_DIR$/../'+rel
    seen=set()
    for parent in tree.iter():
        for item in list(parent):
            if item.tag!='file' or item.find('name') is None:continue
            value=(item.findtext('name') or '').replace('\\','/')
            if not value.startswith('$PROJ_DIR$/'):raise RuntimeError('Nonportable source: '+value)
            source=(ROOT/'EWARM'/value.replace('$PROJ_DIR$/','')).resolve()
            if not source.is_file() or not source.is_relative_to(ROOT.resolve()):
                raise RuntimeError('Invalid source: '+value)
            if source in seen:parent.remove(item)
            else:seen.add(source)

if __name__=='__main__':main()
