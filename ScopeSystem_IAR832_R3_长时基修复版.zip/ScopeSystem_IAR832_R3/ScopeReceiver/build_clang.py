"""Optional LLVM Arm build, using installed Clang and GNU newlib libraries."""
from pathlib import Path
import concurrent.futures,os,subprocess,struct
ROOT=Path(__file__).resolve().parent
CLANG=Path(os.environ.get('ARM_CLANG',r'C:\Program Files\Windhawk\Compiler\bin\clang-20.exe'))
GNU=Path(os.environ.get('GNU_ARM_ROOT',r'C:\32\ST\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.externaltools.gnu-tools-for-stm32.13.3.rel1.win32_1.0.0.202411081344\tools'))
def main():
 out=ROOT/'BuildLLVM';out.mkdir(exist_ok=True)
 temp=out/'tmp';temp.mkdir(exist_ok=True);os.environ['TMP']=os.environ['TEMP']=str(temp)
 flags=['--no-default-config','--target=arm-none-eabi','-mcpu=cortex-m7','-mthumb','-mfpu=fpv5-sp-d16','-mfloat-abi=hard','-O2','-g','-ffunction-sections','-fdata-sections','-Wall','-Wextra','-Wno-unused-parameter','-DSTM32F746xx','-DUSE_HAL_DRIVER','-isystem',str(GNU/'arm-none-eabi/include')]
 includes=['Inc','App','Drivers/CMSIS/Include','Drivers/CMSIS/Device/ST/STM32F7xx/Include','Drivers/STM32F7xx_HAL_Driver/Inc','Drivers/STM32F7xx_HAL_Driver/Inc/Legacy','Middlewares/ST/STM32_USB_Device_Library/Core/Inc','Middlewares/ST/STM32_USB_Device_Library/Class/MSC/Inc']
 for p in includes:flags+=['-I',str(ROOT/p)]
 sources=list((ROOT/'Src').glob('*.c'))+list((ROOT/'App').glob('*.c'))+list((ROOT/'GCC').glob('*.c'))+list((ROOT/'Drivers/STM32F7xx_HAL_Driver/Src').glob('*.c'))+list((ROOT/'Middlewares').glob('**/Src/*.c'))+[ROOT/'GCC/startup_stm32f746xx.s']
 sources=[s for s in sources if not s.name.endswith('_template.c')]
 runtime=out/'runtime_init.c';runtime.write_text('void _init(void) {}\nvoid _fini(void) {}\n');sources.append(runtime)
 def compile(s):
  obj=out/('_'.join(s.relative_to(ROOT).parts)+'.o')
  r=subprocess.run([str(CLANG),*flags,*(['-std=c11'] if s.suffix=='.c' else ['-x','assembler-with-cpp']),'-c',str(s),'-o',str(obj)],capture_output=True,text=True)
  return r,obj
 objects=[];failed=False
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for r,obj in pool.map(compile,sources):
   if r.stdout:print(r.stdout)
   if r.stderr:print(r.stderr)
   failed|=r.returncode!=0;objects.append(obj)
 if failed:raise SystemExit('Clang compilation failed')
 role=ROOT.name;elf=out/(role+'.elf')
 lib=GNU/'arm-none-eabi/lib/thumb/v7e-m+fp/hard';gcc=GNU/'lib/gcc/arm-none-eabi/13.3.1/thumb/v7e-m+fp/hard'
 cmd=[str(CLANG.parent/'ld.lld.exe'),'-T',str(ROOT/'GCC/STM32F746NGHx_FLASH.ld'),'--gc-sections','--Map='+str(out/(role+'.map')),'--print-memory-usage','-o',str(elf),*map(str,objects),'-L',str(lib),'-L',str(gcc),'--start-group','-lc_nano','-lm','-lgcc','-lnosys','--end-group']
 subprocess.run(cmd,check=True)
 data=elf.read_bytes();assert data[:5]==b'\x7fELF\x01'
 phoff=struct.unpack_from('<I',data,28)[0];phsize,phnum=struct.unpack_from('<HH',data,42)
 segments=[]
 for n in range(phnum):
  typ,off,va,pa,fs,ms,fl,al=struct.unpack_from('<8I',data,phoff+n*phsize)
  if typ==1 and fs and 0x08000000<=pa<0x08100000:segments.append((pa,data[off:off+fs]))
 assert segments
 end=max(a+len(d) for a,d in segments);binary=bytearray(b'\xff'*(end-0x08000000))
 for a,d in segments:binary[a-0x08000000:a-0x08000000+len(d)]=d
 (out/(role+'.bin')).write_bytes(binary)
 def line(addr,typ,payload):
  b=bytes([len(payload),addr>>8,addr&255,typ])+payload;return ':'+(b+bytes([-sum(b)&255])).hex().upper()
 lines=[];upper=None
 for a,d in sorted(segments):
  for i in range(0,len(d),16):
   addr=a+i
   if upper!=addr>>16:upper=addr>>16;lines.append(line(0,4,upper.to_bytes(2,'big')))
   lines.append(line(addr&65535,0,d[i:i+16]))
 lines.append(line(0,1,b''));(out/(role+'.hex')).write_text('\n'.join(lines)+'\n')
 print('Built LLVM:',elf,'flash image bytes',len(binary))
if __name__=='__main__':main()
