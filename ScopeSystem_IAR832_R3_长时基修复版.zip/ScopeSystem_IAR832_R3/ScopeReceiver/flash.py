"""Flash the built receiver using the locally installed STM32CubeProgrammer."""
from pathlib import Path
import os,shutil,subprocess,sys
root=Path(__file__).resolve().parent
def main():
    name=os.environ.get('STM32_PROGRAMMER_CLI') or shutil.which('STM32_Programmer_CLI')
    if not name:
        for base in [Path('C:/32/ST'),Path('C:/ST')]:
            if base.exists():
                p=next(base.glob('**/STM32_Programmer_CLI.exe'),None)
                if p:name=str(p);break
    if not name:raise SystemExit('Set STM32_PROGRAMMER_CLI to the STM32CubeProgrammer CLI path.')
    candidates=[root/'EWARM/ScopeReceiver/Exe/ScopeReceiver.hex',root/'BuildLLVM/ScopeReceiver.hex',root/'Build/ScopeReceiver.hex']
    candidates=[p for p in candidates if p.exists()]
    if not candidates:raise SystemExit('No firmware HEX. Rebuild in IAR or run an available build script.')
    firmware=max(candidates,key=lambda p:p.stat().st_mtime_ns)
    print('Firmware:',firmware)
    discovery=subprocess.run([name,'-l','stlink'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    print(discovery.stdout)
    if discovery.stdout.count('ST-Link Probe ')!=1:raise SystemExit('Connect exactly one intended ST-LINK board before flashing.')
    subprocess.run([name,'-c','port=SWD','mode=UR','-w',str(firmware),'-v','-rst'],check=True)
if __name__=='__main__':main()
