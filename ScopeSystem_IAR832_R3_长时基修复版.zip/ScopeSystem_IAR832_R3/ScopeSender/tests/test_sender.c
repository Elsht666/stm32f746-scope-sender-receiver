#include "sender_codec.h"
#include "receiver_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static uint32_t a[256],b[256],ga[256],gi[256],ring[SCOPE_RING_SIZE];
static uint8_t frame[SENDER_FRAME_BYTES];
int main(int argc,char **argv){
  Sender_CodecInit();CHECK(Sender_CRC32((const uint8_t*)"123456789",9,0,0)==0xCBF43926u);
  ScopeStream stream;Scope_Reset(&stream,ring);
  for(unsigned block=0;block<256;block++){
    for(unsigned i=0;i<256;i++){unsigned index=block*256+i;a[i]=(uint16_t)(index&4095);b[i]=(uint16_t)(4095-(index&4095));ga[i]=(i&1)?(1u<<15):0;gi[i]=((i&1)?0:1u)|((i&2)?8u:0)|((i&4)?4u:0);}
    Sender_Packet(frame,a,b,ga,gi,block,block*256,block==0,0);size_t bytes=0;
    const uint8_t *p=Scope_UDP(frame,sizeof(frame),&bytes);CHECK(p==frame+42&&bytes==SENDER_PAYLOAD);CHECK(Scope_Ingest(&stream,p,bytes,block));
    for(unsigned i=0;i<256;i++){uint32_t w=ring[(stream.write-256+i)&65535];CHECK((w&4095)==a[i]);CHECK(((w>>12)&4095)==b[i]);CHECK(((w>>24)&7)==(i&7));}
  }
  CHECK(stream.valid==65536&&stream.rate==500000&&stream.vref==3300&&stream.lost==0&&stream.bad==0);
  ScopeFrame view;ScopeConfig cfg={0,31,0,0,0,2048};
  for(int i=0;i<5;i++){cfg.timebase=(uint8_t)i;CHECK(Scope_MakeFrame(&stream,&cfg,&view)==1);CHECK(view.step==scope_timebase_us[i]/100);}
  Sender_SetReset(frame,1);size_t bytes=0;const uint8_t *p=Scope_UDP(frame,sizeof(frame),&bytes);CHECK(p&&Scope_Ingest(&stream,p,bytes,300)&&stream.valid==256);
  frame[80]^=1;p=Scope_UDP(frame,sizeof(frame),&bytes);CHECK(p&&!Scope_Ingest(&stream,p,bytes,301)&&stream.bad==1);frame[80]^=1;
  if(argc>1){FILE *f=fopen(argv[1],"wb");CHECK(f);CHECK(fwrite(frame,1,sizeof(frame),f)==sizeof(frame));fclose(f);}
  puts("PASS: sender Ethernet/IPv4/UDP/SCOP packets accepted by actual receiver C decoder; ADC channels, D9/D7/D8 packing with D5 ignored, CRC/reset, 65536 samples and all five timebases");return 0;
}
