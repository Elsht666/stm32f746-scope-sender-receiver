# R3：IAR 长时基丢包修复与使用

本版已在本机 IAR for ARM 8.32.1 界面分别完整编译发送端、接收端，两端均为 0 错误、0 警告；随后使用这次 IAR 实际生成的固件下载到两板并运行。用户确认：10ms、5ms 均能正常显示五条波形，电位器、麦克风响应正常；发送 DROP、接收 LOSS、CRC 均为 0。

## 问题原因

原 IAR 工程再次经 CubeMX 生成后，应用的以太网接收缓冲数量回退到 HAL 默认的 4 个；IAR 原配置使用 High/Size，发送端绘屏期间处理发包不够及时。用户观察到发送 DROP 和接收 LOSS 持续增加、CRC 为 0。

接收端遇到丢包会丢弃此前不连续的采样窗口。10ms/div 需要 39901 个连续样本，约 79.8ms、156 个数据包；5ms/div 需要 19951 个，约 39.9ms、78 个包。连续丢包时这些窗口无法填满，1ms 档需要的连续数据较短，因此可能仍能显示。旧提示在尚未形成完整波形时统一显示“Connect acquisition board”，会误导为网线未连接。

## 修复内容

1. 两端 IAR 使用 High/Speed（-Ohs）。
2. 恢复发送 RX16/TX4、接收 RX64/TX4；新增 Inc/scope_project_config.h，放在 HAL 配置头 USER CODE 区引入，CubeMX 再生成后仍保留。
3. .ioc 保存描述符数量和互不重叠的 Rx/Tx 地址。恢复脚本将 DMA 数组交给链接器在可被 DMA 访问的 SRAM 中作 32 字节对齐分配；实际 IAR map 已核实数量、地址、无重叠。
4. 发送队列从 32 扩至 64 块，可容纳约 32.8ms 数据；绘制文字、矩形和背景时更频繁地处理发包。
5. 接收端分别提示物理链路断开、等待数据、等待配置回执、样本缓冲、等待触发，避免把缓冲未满显示成“请连接网线”。
6. CubeMX 再生成后若未运行恢复脚本，IAR 编译会提示 Run_tools_post_generate_py_after_CubeMX_Generate_Code，防止静默生成配置回退的固件。

采样率仍为每通道 500kSa/s，协议为 SCOP v2。CH1 电位器 A1/PF10，CH2 麦克风 A0/PA0；D0=D9/PA15、D1=D7/PI3、D2=D8/PI2。D3/PB4 是测试方波输出；D5 不作为 D0 的输入。接线无需因本次修复改变。

## 在 IAR 中打开、编译和下载

1. 完整解压本工程包，打开根目录 ScopeSystem.eww。两个单独的工作区也可用：ScopeSender/EWARM/ScopeSender.eww、ScopeReceiver/EWARM/ScopeReceiver.eww。
2. 当前配置已恢复，直接选择 ScopeSender，执行 Project → Rebuild All；再选择 ScopeReceiver，执行同样操作。无需先点击 CubeMX Generate Code。
3. 下载发送工程：Project → Download and Debug（Ctrl+D）。出现 Debug Probe Selection 时选择 43244853，确认后等待进入 main，按 F5 运行。发送屏标题包含 SCOP R3 SENDER。
4. 下载接收工程时选择 67244354，下载后同样按 F5。两块板同时连接时，务必按角色选择探针。
5. 两板 CN14 用于供电和 ST-LINK；CN9 之间接网线，链路应为 100Mbps。
6. 接收端选 AUTO，10ms、5ms 分别运行约 30 秒，检查五条波形、模拟输入实时响应，以及 DROP/LOSS 是否持续增加、CRC 是否为 0；再切换 1ms、500us、100us。
7. 调试暂停、重新下载或重配时可能有一次性计数变化，应在正常运行后比较增量。

完整 ST-LINK 序号：发送 066FFF313130525043244853；接收 066FFF514966504867244354。此版本 IAR 的探针选择窗口显示上述末 8 位序号。

## 固件在哪里

- IARFirmware/ScopeSender、IARFirmware/ScopeReceiver：本次实际 IAR 编译、已下载验证的 .hex、.out、.map，以及从同一 HEX 转出的 .bin。BIN 烧录地址是 0x08000000。
- 两端重新构建后的常规输出：各自 EWARM/<工程名>/Exe。打包不包含中间对象文件，Rebuild All 会重新生成。
- VerifiedFirmware：本版另用 LLVM Arm 构建的备用固件，与本次 IAR 实板验证记录分开；验证本次问题请使用 IARFirmware 或自行在 IAR 重建。

## 每次 CubeMX Generate Code 之后

仍使用 STM32CubeMX 6.18.1，工具链 EWARM、最低 V8.32。生成后，在对应的 ScopeSender 或 ScopeReceiver 根目录运行：

```text
python tools/post_generate.py
```

本机可使用 C:\allpython\anaconda\python.exe。两端都重新生成时，两端都要运行各自脚本。脚本恢复 App 源文件与头文件路径、应用入口、Speed 优化、USB 配置及 DMA 布局。完成后重新打开工作区并 Rebuild All。

## 验证记录

实际 C 核心测试通过，包括四 DMA 汇合、通道打包与解码、触发/控制协议、五档时基、FAT12/CSV/BMP 导出。新增 40 块突发测试：20.48ms 未处理前台任务后，队列仍能按序发出且不丢包；超过真实队列容量时仍如实计数并保留丢包序号，未伪造或补画缺失样本。

两端已实际用 CubeMX 6.18.1 再生成并恢复，确认 App 未被覆盖、关键头文件保留、源文件引用唯一且为相对路径。独立 LLVM Arm 构建和原生 IAR GUI 构建均通过。IAR 内部 RAM 使用：发送 122352 字节，接收 172431 字节，均在 0x20010000～0x2004FFFF 区间允许容量内。

命令行 IarBuild 在当前受限运行环境曾返回 LMS001；随后改用有可用许可证的原生 IAR 界面，已完成本次真实 IAR 编译和两板验证。不能将命令行失败日志误读为本版未通过 IAR。

用户已确认本次长时基故障修复通过。尚未记录具体 FPS、网线长度、电压精度及任务书全部验收数据，不据此声称完成所有性能验收。详细数据和固件哈希见 R3验证记录.json、SHA256.json。
