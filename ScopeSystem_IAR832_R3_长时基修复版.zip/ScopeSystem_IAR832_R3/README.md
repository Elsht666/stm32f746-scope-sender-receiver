# ScopeSystem IAR 8.32.1 R3

本版已修复 IAR 运行后发送 DROP、接收 LOSS 持续增长，导致 10ms/5ms 无法形成波形的问题。两端已在原生 IAR 8.32.1 编译通过（0 错误、0 警告）并下载运行，用户确认两档五条波形正常、模拟输入实时变化，DROP/LOSS/CRC 均为 0。

打开 ScopeSystem.eww。使用步骤及 CubeMX 再生成后的处理见《R3使用与验证.md》。IARFirmware 是本次 IAR 实际编译并烧录的固件；VerifiedFirmware 是单独的 LLVM 备用构建。接线延续上一版，CH1=A1、CH2=A0、D0=D9、D1=D7、D2=D8。
