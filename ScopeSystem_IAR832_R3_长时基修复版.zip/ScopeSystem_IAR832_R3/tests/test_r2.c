#include "sender_codec.h"
#include "scope_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static uint32_t ch1[256],ch2[256],pa[256],pi[256],ring[65536];
static uint8_t frame[SENDER_FRAME_BYTES],command[CONTROL_FRAME_BYTES];
static ScopeStream stream;
static void ingest(unsigned seq,unsigned first,SenderTrigger *trigger,int reset){
  Sender_Packet(frame,ch1,ch2,pa,pi,seq,first,(uint8_t)reset,trigger);
  size_t len=0;const uint8_t *p=Scope_UDP(frame,sizeof(frame),&len);
  CHECK(p==frame+42&&len==1064);CHECK(Scope_Ingest(&stream,p,len,seq));
}
static void p32(uint8_t *p,uint32_t v){for(int i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static void refresh_crc(void){uint8_t *p=frame+42;p32(p+28,Sender_CRC32(p,28,p+32,SENDER_PAYLOAD-32));}
int main(void){
 Sender_CodecInit();CHECK(Sender_CRC32((const uint8_t*)"123456789",9,0,0)==0xcbf43926u);
 ScopeControl control={1,31,1,1,0,2048,0x12345678u,10},decoded;
 Control_Encode(command,&control);CHECK(Control_Decode(command,sizeof(command),&decoded));
 CHECK(decoded.source==1&&decoded.mode==1&&decoded.level==2048&&decoded.session==control.session&&decoded.revision==10);
 for(unsigned i=0;i<CONTROL_FRAME_BYTES;i++)CHECK(!Control_Decode(command,i,&decoded));
 command[55]^=1;CHECK(!Control_Decode(command,sizeof(command),&decoded));command[55]^=1;
 command[24]^=1;CHECK(!Control_Decode(command,sizeof(command),&decoded));command[24]^=1;
 command[49]=7;p32(command+66,Sender_CRC32(command+42,24,0,0));CHECK(!Control_Decode(command,sizeof(command),&decoded));
 Control_Encode(command,&control);
 puts("PASS control Ethernet/IPv4/UDP/SCTL roundtrip, CRC, invalid fields and truncation");

 Scope_Reset(&stream,ring);
 for(unsigned block=0;block<256;block++){
  for(unsigned i=0;i<256;i++){
   unsigned n=block*256+i;ch1[i]=n&4095;ch2[i]=4095-(n&4095);
   pa[i]=(i&1)?(1u<<15):0;
   /* PI0=D5 deliberately toggles and must have no effect on D0. */
   pi[i]=((i&1)?0:1u)|((i&2)?8u:0)|((i&4)?4u:0);
  }
  ingest(block,block*256,0,block==0);
  for(unsigned i=0;i<256;i++){uint32_t w=ring[(stream.write-256+i)&65535];CHECK((w&4095)==ch1[i]);CHECK(((w>>12)&4095)==ch2[i]);CHECK(((w>>24)&7)==(i&7));}
 }
 CHECK(stream.protocol==2&&stream.valid==65536&&stream.bad==0&&stream.lost==0);
 ScopeConfig cfg={0,31,1,0,0,2048};ScopeFrame view;
 for(unsigned tb=0;tb<5;tb++){cfg.timebase=(uint8_t)tb;CHECK(Scope_MakeFrame(&stream,&cfg,&view)==1);CHECK(view.step==scope_timebase_us[tb]/100);}
 puts("PASS physical D9/PA15 D0 packing, D5 independence, CH1/CH2 fields and all timebases");

 /* A waveform that crosses the threshold must NOT trigger v2 NORMAL
    unless the sender supplies a valid trigger index and control ack. */
 cfg.timebase=1;cfg.mode=1;CHECK(Scope_MakeFrame(&stream,&cfg,&view)==0);
 control.timebase=1;control.source=0;control.mode=1;
 SenderTrigger trigger;Sender_TriggerReset(&trigger,&control);Scope_Reset(&stream,ring);
 for(unsigned block=0;block<256;block++){
  for(unsigned i=0;i<256;i++){unsigned n=block*256+i;ch1[i]=(n%500>=100)?3000:1000;ch2[i]=1500;pa[i]=pi[i]=0;}
  Sender_TriggerBlock(&trigger,ch1,ch2,pa,pi,block*256,256);ingest(block,block*256,&trigger,block==0);
 }
 CHECK(trigger.valid&&stream.control_valid&&stream.control_revision==10);
 cfg.source=0;CHECK(Scope_MakeFrame(&stream,&cfg,&view)==1&&view.triggered);
 CHECK(view.first_index+view.step*100==45100);CHECK((view.sample[100]&4095)==3000);
 CHECK(view.frequency_mhz[0]==1000000);CHECK(view.vpp_mv[0]>=1610&&view.vpp_mv[0]<=1612);
 puts("PASS sender-owned analog trigger, pre/post window, control ack and 1kHz raw measurements");

 control.mode=2;control.timebase=2;control.source=1;control.revision++;
 Sender_TriggerReset(&trigger,&control);Scope_Reset(&stream,ring);
 for(unsigned block=0;block<128;block++){
  for(unsigned i=0;i<256;i++){unsigned n=block*256+i;ch1[i]=1200;ch2[i]=n<6000?1000:((n%500<250)?3000:1000);pa[i]=pi[i]=0;}
  Sender_TriggerBlock(&trigger,ch1,ch2,pa,pi,block*256,256);ingest(block,block*256,&trigger,block==0);
 }
 CHECK(trigger.index==6000);cfg.timebase=2;cfg.mode=2;cfg.source=1;
 CHECK(Scope_MakeFrame(&stream,&cfg,&view)==1&&view.triggered);CHECK(view.first_index+view.step*100==6000);
 uint32_t old_index=trigger.index;Sender_TriggerReset(&trigger,&control);CHECK(!trigger.valid&&old_index==6000);
 puts("PASS SINGLE holds first acquisition trigger until rearm, and CH2 microphone trigger");

 control.source=2;control.mode=1;control.falling=1;control.timebase=4;Sender_TriggerReset(&trigger,&control);
 for(unsigned i=0;i<256;i++){ch1[i]=ch2[i]=2048;pa[i]=i<150?(1u<<15):0;pi[i]=(i&1)?1:0;}
 Sender_TriggerBlock(&trigger,ch1,ch2,pa,pi,0,256);CHECK(trigger.valid&&trigger.index==150);
 for(unsigned source=3;source<=4;source++){
  control.source=(uint8_t)source;control.falling=0;Sender_TriggerReset(&trigger,&control);
  for(unsigned i=0;i<256;i++){pa[i]=0;pi[i]=i>=120?(source==3?8:4):0;}
  Sender_TriggerBlock(&trigger,ch1,ch2,pa,pi,0,256);CHECK(trigger.valid&&trigger.index==120);
 }
 control.source=2;control.falling=0;Sender_TriggerReset(&trigger,&control);trigger.seen=100;
 for(unsigned i=0;i<256;i++)pa[i]=i>=20?(1u<<15):0;
 Sender_TriggerBlock(&trigger,ch1,ch2,pa,pi,0xfffffff0u,256);CHECK(trigger.valid&&trigger.index==4);
 puts("PASS independent D0/D1/D2 trigger sources, falling edges and sample-index wrap");
 control.source=2;control.mode=2;Sender_TriggerReset(&trigger,&control);
 for(unsigned i=0;i<256;i++)pa[i]=(i%100>=20)?(1u<<15):0;
 Sender_TriggerBlock(&trigger,ch1,ch2,pa,pi,0,256);CHECK(trigger.valid&&trigger.index==120);
 puts("PASS SINGLE ignores early edges until pretrigger history is available");

 unsigned bad=stream.bad;frame[74]^=1;size_t len;const uint8_t *payload=Scope_UDP(frame,sizeof(frame),&len);CHECK(payload&&!Scope_Ingest(&stream,payload,len,999)&&stream.bad==bad+1);frame[74]^=1;
 Sender_SetReset(frame,1);payload=Scope_UDP(frame,sizeof(frame),&len);CHECK(payload&&Scope_Ingest(&stream,payload,len,1000)&&stream.valid==256);
 /* Trigger and acknowledgement bytes are covered by CRC too. */
 frame[42+32]^=1;payload=Scope_UDP(frame,sizeof(frame),&len);CHECK(payload&&!Scope_Ingest(&stream,payload,len,1001));frame[42+32]^=1;
 frame[42+23]|=0x80;refresh_crc();payload=Scope_UDP(frame,sizeof(frame),&len);CHECK(payload&&!Scope_Ingest(&stream,payload,len,1002));
 puts("PASS v2 extended CRC, reset preservation and reserved flag rejection");
 puts("ALL R2 PROTOCOL AND TRIGGER TESTS PASSED");return 0;
}
