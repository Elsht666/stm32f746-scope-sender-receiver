from pathlib import Path
import os,subprocess,sys
base=Path(__file__).resolve().parents[1];tests=base/'tests';out=tests/'Build';out.mkdir(exist_ok=True)
temp=out/'tmp';temp.mkdir(exist_ok=True);os.environ['TEMP']=os.environ['TMP']=str(temp)
clang=Path(os.environ.get('HOST_CLANG',r'C:\Program Files\Windhawk\Compiler\bin\clang-20.exe'))
if not clang.exists():raise SystemExit('Set HOST_CLANG to a native Windows Clang compiler.')
s=base/'ScopeSender';r=base/'ScopeReceiver'
def run(name,source,defines=(),args=()):
 exe=out/(name+'.exe');cmd=[str(clang),'-std=c11','-O2','-Wall','-Wextra','-Werror']
 for d in defines:cmd+=['-D'+d]
 for p in [tests,s/'App',s/'tests',r/'App']:cmd+=['-I',str(p)]
 subprocess.run([*cmd,*map(str,source),'-o',str(exe)],check=True)
 subprocess.run([str(exe),*map(str,args)],check=True)
run('protocol',[tests/'test_r2.c',s/'App/sender_codec.c',s/'App/sender_trigger.c',s/'App/scope_control.c',r/'App/scope_core.c'])
run('capture',[tests/'test_capture.c',s/'App/sender_capture.c',s/'App/sender_codec.c',s/'App/sender_trigger.c'],['SENDER_CAPTURE_HOST_TEST'])
run('encoder',[s/'tests/test_sender.c',s/'tests/receiver_core.c',s/'App/sender_codec.c'])
run('receiver',[r/'tests/test_scope.c',r/'App/scope_core.c',r/'App/scope_disk.c'],['SCOPE_HOST_TEST'],[out/'disk.img'])
subprocess.run([sys.executable,str(r/'tests/validate_disk.py'),str(out/'disk.img')],check=True)
print('ALL R2 TEST SUITES PASSED')
