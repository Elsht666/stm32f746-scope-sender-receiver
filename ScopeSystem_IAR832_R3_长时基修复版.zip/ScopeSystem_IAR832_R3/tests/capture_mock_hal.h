#ifndef CAPTURE_MOCK_HAL_H
#define CAPTURE_MOCK_HAL_H
#include <stdint.h>
#include <stddef.h>
typedef struct DMA_HandleTypeDef DMA_HandleTypeDef;
struct DMA_HandleTypeDef {void (*XferHalfCpltCallback)(DMA_HandleTypeDef*);void (*XferCpltCallback)(DMA_HandleTypeDef*);void (*XferErrorCallback)(DMA_HandleTypeDef*);uint32_t source,dest,count;int running;};
typedef struct {void *Instance;} ADC_HandleTypeDef;
typedef struct {uint32_t ARR,CNT,CCR1,EGR;} TestTimer;
typedef struct {TestTimer *Instance;} TIM_HandleTypeDef;
typedef struct {uint32_t IDR;} TestGPIO;
extern TestGPIO gpio_a,gpio_i;
extern ADC_HandleTypeDef hadc1,hadc3;
extern TIM_HandleTypeDef htim3,htim8;
#define GPIOA (&gpio_a)
#define GPIOI (&gpio_i)
#define ADC1 ((void*)1)
#define ADC3 ((void*)3)
#define TIM_CHANNEL_1 0u
#define TIM_DMA_UPDATE 1u
#define TIM_DMA_CC1 2u
#define TIM_FLAG_UPDATE 1u
#define TIM_FLAG_CC1 2u
#define TIM_EGR_UG 1u
#define HAL_OK 0
#define __DMB() ((void)0)
#define __HAL_TIM_DISABLE_DMA(h,b) ((void)(h),(void)(b))
#define __HAL_TIM_ENABLE_DMA(h,b) ((void)(h),(void)(b))
#define __HAL_TIM_CLEAR_FLAG(h,b) ((void)(h),(void)(b))
#define __HAL_TIM_SET_COUNTER(h,n) ((h)->Instance->CNT=(n))
#define __HAL_TIM_GET_AUTORELOAD(h) ((h)->Instance->ARR)
#define __HAL_TIM_SET_AUTORELOAD(h,n) ((h)->Instance->ARR=(n))
#define __HAL_TIM_SET_COMPARE(h,c,n) ((void)(c),(h)->Instance->CCR1=(n))
int HAL_TIM_OC_Stop(TIM_HandleTypeDef*,unsigned);
int HAL_TIM_OC_Start(TIM_HandleTypeDef*,unsigned);
int HAL_TIM_Base_Stop(TIM_HandleTypeDef*);
int HAL_ADC_Stop_DMA(ADC_HandleTypeDef*);
int HAL_ADC_Start_DMA(ADC_HandleTypeDef*,uint32_t*,unsigned);
int HAL_DMA_Abort(DMA_HandleTypeDef*);
int HAL_DMA_Start_IT(DMA_HandleTypeDef*,uint32_t,uint32_t,unsigned);
int HAL_TIM_PWM_Stop(TIM_HandleTypeDef*,unsigned);
int HAL_TIM_PWM_Start(TIM_HandleTypeDef*,unsigned);
void Error_Handler(void);
#endif
