#include "capture_mock_hal.h"
#include "sender_app.h"
#include "sender_codec.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);}}while(0)
TestGPIO gpio_a,gpio_i;
ADC_HandleTypeDef hadc1={ADC1},hadc3={ADC3};
static TestTimer tim3={999,0,500,0},tim8={399,0,0,0};
TIM_HandleTypeDef htim3={&tim3},htim8={&tim8};
DMA_HandleTypeDef hdma_tim8_up,hdma_tim8_ch1;
static uint32_t *adc1,*adc3;
static uint8_t last_frame[SENDER_FRAME_BYTES];
static unsigned sent,starts;
static unsigned check_sequence,expected_sequence;
int HAL_TIM_OC_Stop(TIM_HandleTypeDef*h,unsigned c){(void)h;(void)c;return 0;}
int HAL_TIM_OC_Start(TIM_HandleTypeDef*h,unsigned c){(void)c;CHECK(h->Instance->CNT==399);CHECK(h->Instance->CCR1==0);starts++;return 0;}
int HAL_TIM_Base_Stop(TIM_HandleTypeDef*h){(void)h;return 0;}
int HAL_ADC_Stop_DMA(ADC_HandleTypeDef*h){(void)h;return 0;}
int HAL_ADC_Start_DMA(ADC_HandleTypeDef*h,uint32_t*d,unsigned n){CHECK(n==512);if(h->Instance==ADC1)adc1=d;else adc3=d;return 0;}
int HAL_DMA_Abort(DMA_HandleTypeDef*h){h->running=0;return 0;}
int HAL_DMA_Start_IT(DMA_HandleTypeDef*h,uint32_t s,uint32_t d,unsigned n){h->source=s;h->dest=d;h->count=n;h->running=1;return 0;}
int HAL_TIM_PWM_Stop(TIM_HandleTypeDef*h,unsigned c){(void)h;(void)c;return 0;}
int HAL_TIM_PWM_Start(TIM_HandleTypeDef*h,unsigned c){(void)h;(void)c;return 0;}
void Error_Handler(void){CHECK(0);}
int Sender_NetLink(void){return 1;}
int Sender_NetSpeed(void){return 100;}
void Sender_NewSession(void){}
int Sender_Send(uint8_t *p){
 if(check_sequence){uint8_t *q=p+42+8;uint32_t seq=q[0]|(uint32_t)q[1]<<8|(uint32_t)q[2]<<16|(uint32_t)q[3]<<24;CHECK(seq==expected_sequence++);}
 memcpy(last_frame,p,sizeof(last_frame));sent++;return 1;
}
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef*);
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef*);
static uint32_t word(unsigned i){uint8_t *p=last_frame+42+40+4*i;return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void fill(unsigned half,int high){
 uint32_t *a=(uint32_t*)(uintptr_t)hdma_tim8_ch1.dest,*i=(uint32_t*)(uintptr_t)hdma_tim8_up.dest;
 for(unsigned n=half*256;n<(half+1)*256;n++){adc1[n]=3100;adc3[n]=900;a[n]=high?(1u<<15):0;i[n]=high?4u:9u;}
}
static void capture_block(unsigned block){
 unsigned half=block&1u;fill(half,half);
 if(!half){HAL_ADC_ConvHalfCpltCallback(&hadc1);HAL_ADC_ConvHalfCpltCallback(&hadc3);hdma_tim8_up.XferHalfCpltCallback(&hdma_tim8_up);hdma_tim8_ch1.XferHalfCpltCallback(&hdma_tim8_ch1);}
 else{HAL_ADC_ConvCpltCallback(&hadc1);HAL_ADC_ConvCpltCallback(&hadc3);hdma_tim8_up.XferCpltCallback(&hdma_tim8_up);hdma_tim8_ch1.XferCpltCallback(&hdma_tim8_ch1);}
}
int main(void){
 Sender_CaptureInit();CHECK(sender_running&&starts==1);CHECK(adc1&&adc3);
 CHECK(hdma_tim8_up.source==(uint32_t)(uintptr_t)&gpio_i.IDR&&hdma_tim8_ch1.source==(uint32_t)(uintptr_t)&gpio_a.IDR);
 CHECK(hdma_tim8_up.count==512&&hdma_tim8_ch1.count==512);fill(0,0);
 HAL_ADC_ConvHalfCpltCallback(&hadc1);HAL_ADC_ConvHalfCpltCallback(&hadc3);hdma_tim8_up.XferHalfCpltCallback(&hdma_tim8_up);
 Sender_CaptureService();CHECK(sent==0);hdma_tim8_ch1.XferHalfCpltCallback(&hdma_tim8_ch1);Sender_CaptureService();CHECK(sent==1);
 for(unsigned n=0;n<256;n++){uint32_t w=word(n);CHECK((w&4095)==900);CHECK(((w>>12)&4095)==3100);CHECK(((w>>24)&7)==2);}
 CHECK(sender_ch1_raw==900&&sender_ch2_raw==3100&&sender_digital==2);
 fill(1,1);hdma_tim8_ch1.XferCpltCallback(&hdma_tim8_ch1);HAL_ADC_ConvCpltCallback(&hadc3);HAL_ADC_ConvCpltCallback(&hadc1);Sender_CaptureService();CHECK(sent==1);
 hdma_tim8_up.XferCpltCallback(&hdma_tim8_up);Sender_CaptureService();CHECK(sent==2);CHECK(((word(0)>>24)&7)==5);
 HAL_ADC_ConvHalfCpltCallback(&hadc1);HAL_ADC_ConvHalfCpltCallback(&hadc1);CHECK(sender_fault&&sender_errors==1);Sender_CaptureService();CHECK(starts==2&&sender_restarts==1&&!sender_fault);
 Sender_CaptureSet(0);CHECK(!sender_running&&!hdma_tim8_ch1.running&&!hdma_tim8_up.running);
 ScopeControl control={1,31,1,1,0,2048,77,5};Sender_ControlSubmit(&control);Sender_CaptureService();CHECK(!sender_running&&starts==2);
 Sender_CaptureSet(1);CHECK(starts==3);fill(0,0);HAL_ADC_ConvHalfCpltCallback(&hadc1);HAL_ADC_ConvHalfCpltCallback(&hadc3);hdma_tim8_ch1.XferHalfCpltCallback(&hdma_tim8_ch1);hdma_tim8_up.XferHalfCpltCallback(&hdma_tim8_up);Sender_CaptureService();
 CHECK(last_frame[42+4]==2&&(last_frame[42+23]&4)&&last_frame[42+32]==77&&last_frame[42+36]==5);
 /* A 20.48ms foreground stall used to overflow the old 32-block queue. */
 Sender_CaptureSet(1);unsigned before=sent,drops=sender_drops;
 for(unsigned i=0;i<40;i++)capture_block(i);
 CHECK(sent==before&&sender_drops==drops);check_sequence=1;expected_sequence=0;
 for(unsigned i=0;i<6;i++)Sender_CaptureService();
 CHECK(sent==before+40&&expected_sequence==40&&sender_drops==drops);
 /* Overflow remains explicit and subsequent sample indices keep the gap. */
 Sender_CaptureSet(1);before=sent;expected_sequence=0;
 for(unsigned i=0;i<70;i++)capture_block(i);
 CHECK(sender_drops==drops+6);
 for(unsigned i=0;i<9;i++)Sender_CaptureService();
 CHECK(sent==before+64&&expected_sequence==64);
 expected_sequence=70;capture_block(70);Sender_CaptureService();CHECK(expected_sequence==71);
 puts("PASS R3 40-block/20.48ms foreground stall: no drops, ordered delivery; real overflow counts and packet gap preserved");
 puts("PASS actual sender_capture.c: four-DMA barrier, CH1=ADC3/A1 pot, CH2=ADC1/A0 mic, D9/D7/D8, D5 ignored, startup CNT=ARR, desync recovery and paused control updates");return 0;
}
