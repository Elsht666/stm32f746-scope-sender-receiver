# 本次实板验证使用的 IAR 固件

ScopeSender 与 ScopeReceiver 子目录的 HEX、OUT 和 MAP 来自 2026-10-30 本机原生 IAR for ARM 8.32.1 界面成功编译；两端均 0 错误、0 警告。BIN 由同目录 HEX 按原地址数据转换，起始地址 0x08000000。两板使用这些 IAR 输出完成下载运行，用户确认 10ms、5ms 波形及输入响应正常，DROP/LOSS/CRC 为 0。

发送板探针末8位 43244853，接收板 67244354。全量复现请用根目录 ScopeSystem.eww 执行 Rebuild All。具体结果见上级 R3验证记录.json。
