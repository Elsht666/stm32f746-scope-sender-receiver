/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "eth.h"
#include "i2c.h"
#include "ltdc.h"
#include "tim.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ========================= 功能代码（合并自 App/，纯 C + HAL） ========================= */
/* 说明：本工程所有业务逻辑（采集、编解码、触发、网络、显示、控制）均集中在本
   USER CODE 0 段内。CubeMX 重新生成代码时，该段原样保留，不会被覆盖。 */

/* ---- 宏定义 ---- */
#define FB0 ((uint16_t*)0xC0000000u)
#define FB1 ((uint16_t*)0xC0040000u)
#define BG 0x0841
#define WHITE 0xFFFF
#define PWM_BUTTON_WIDTH 160
#define PWM_BUTTON_Y 226
#define PWM_BUTTON_HEIGHT 30
#define SENDER_SAMPLE_RATE 500000u
#define SENDER_BLOCK 256u
#define SENDER_HEADER 40u
#define SENDER_PAYLOAD (SENDER_HEADER+SENDER_BLOCK*4u)
#define SENDER_FRAME_BYTES (14u+20u+8u+SENDER_PAYLOAD)
#define DMA_COUNT (SENDER_BLOCK*2u)
#define QUEUE_COUNT 64u
#define CONTROL_FRAME_BYTES 70u

/* ---- 类型定义 ---- */
typedef struct {
  uint8_t timebase,channels,source,mode,falling;
  uint16_t level;
  uint32_t session,revision;
} ScopeControl;

typedef struct {ScopeControl control;uint32_t index,seen;uint16_t previous;uint8_t primed,valid;} SenderTrigger;

typedef struct {uint8_t data[SENDER_FRAME_BYTES];} __attribute__((aligned(32))) Packet;

typedef struct RxSlot {uint8_t data[1536];struct RxSlot *next;uint16_t len;uint8_t used;} RxSlot;

/* ---- 全局变量 ---- */
static uint16_t *draw=FB1,*front=FB0;
static uint32_t input_tick,requested_pwm=1000;
static uint8_t pwm_on,touch_down;
static uint32_t analog1[DMA_COUNT] __attribute__((aligned(32)));
static uint32_t analog2[DMA_COUNT] __attribute__((aligned(32)));
static uint32_t digital[DMA_COUNT] __attribute__((aligned(32)));
static uint32_t digital_a[DMA_COUNT] __attribute__((aligned(32)));
static ScopeControl control={0,31,1,0,0,2048,0,0},pending_control;
static uint8_t control_pending;
static SenderTrigger trigger;
static Packet queue[QUEUE_COUNT];
static volatile uint32_t head,tail;
static uint32_t sample_index,packet_sequence;
static volatile uint8_t ready_mask[2];
static volatile uint8_t sender_running,sender_fault;
static uint32_t table[256];
static RxSlot rx_pool[ETH_RX_DESC_CNT+4] __attribute__((aligned(32)));
static ScopeControl last_control;
static uint8_t has_control;
static uint32_t phy_address,check_tick;
static int phy_found,link_up,speed;
static uint8_t session_pending=1;

extern DMA_HandleTypeDef hdma_tim8_up;
extern DMA_HandleTypeDef hdma_tim8_ch1;

/* ---- 7x12 点阵 ASCII 字体 ---- */
const uint8_t scope_font[95][12]={
  {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
  {0x00,0x00,0x10,0x10,0x10,0x10,0x10,0x10,0x00,0x10,0x00,0x00},
  {0x00,0x00,0x28,0x28,0x28,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
  {0x00,0x00,0x28,0x28,0x7C,0x28,0x28,0x7C,0x28,0x28,0x00,0x00},
  {0x00,0x10,0x38,0x54,0x50,0x30,0x18,0x14,0x54,0x38,0x10,0x00},
  {0x00,0x00,0x24,0x54,0x28,0x10,0x10,0x28,0x54,0x48,0x00,0x00},
  {0x00,0x00,0x30,0x48,0x48,0x50,0x24,0x54,0x48,0x34,0x00,0x00},
  {0x00,0x00,0x10,0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
  {0x00,0x08,0x10,0x10,0x20,0x20,0x20,0x20,0x10,0x10,0x08,0x00},
  {0x00,0x20,0x10,0x10,0x08,0x08,0x08,0x08,0x10,0x10,0x20,0x00},
  {0x00,0x00,0x00,0x00,0x10,0x54,0x38,0x54,0x10,0x00,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x10,0x10,0x7C,0x10,0x10,0x00,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x10,0x20},
  {0x00,0x00,0x00,0x00,0x00,0x00,0x7C,0x00,0x00,0x00,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x00,0x00},
  {0x00,0x04,0x04,0x08,0x08,0x10,0x10,0x20,0x20,0x40,0x40,0x00},
  {0x00,0x00,0x38,0x44,0x4C,0x54,0x54,0x64,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x10,0x70,0x10,0x10,0x10,0x10,0x10,0x7C,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x04,0x08,0x10,0x20,0x40,0x7C,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x04,0x18,0x04,0x04,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x18,0x28,0x28,0x48,0x48,0x7C,0x08,0x08,0x00,0x00},
  {0x00,0x00,0x7C,0x40,0x40,0x78,0x04,0x04,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x40,0x78,0x44,0x44,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x7C,0x04,0x04,0x08,0x08,0x10,0x10,0x10,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x44,0x38,0x44,0x44,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x44,0x44,0x3C,0x04,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x10,0x00,0x00,0x00,0x00,0x10,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x10,0x00,0x00,0x00,0x00,0x10,0x10,0x20},
  {0x00,0x00,0x00,0x04,0x08,0x10,0x20,0x10,0x08,0x04,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x00,0x7C,0x00,0x7C,0x00,0x00,0x00,0x00},
  {0x00,0x00,0x00,0x20,0x10,0x08,0x04,0x08,0x10,0x20,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x04,0x08,0x10,0x10,0x00,0x10,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x4C,0x54,0x54,0x54,0x5C,0x40,0x38,0x00},
  {0x00,0x00,0x10,0x10,0x28,0x28,0x38,0x44,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x78,0x44,0x44,0x78,0x44,0x44,0x44,0x78,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x40,0x40,0x40,0x40,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x78,0x44,0x44,0x44,0x44,0x44,0x44,0x78,0x00,0x00},
  {0x00,0x00,0x7C,0x40,0x40,0x78,0x40,0x40,0x40,0x7C,0x00,0x00},
  {0x00,0x00,0x7C,0x40,0x40,0x78,0x40,0x40,0x40,0x40,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x40,0x40,0x4C,0x44,0x44,0x3C,0x00,0x00},
  {0x00,0x00,0x44,0x44,0x44,0x7C,0x44,0x44,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x7C,0x10,0x10,0x10,0x10,0x10,0x10,0x7C,0x00,0x00},
  {0x00,0x00,0x04,0x04,0x04,0x04,0x04,0x44,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x44,0x48,0x50,0x60,0x60,0x50,0x48,0x44,0x00,0x00},
  {0x00,0x00,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x7C,0x00,0x00},
  {0x00,0x00,0x44,0x44,0x6C,0x6C,0x54,0x54,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x44,0x64,0x64,0x54,0x54,0x4C,0x4C,0x44,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x44,0x44,0x44,0x44,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x78,0x44,0x44,0x44,0x78,0x40,0x40,0x40,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x44,0x44,0x44,0x54,0x48,0x34,0x00,0x00},
  {0x00,0x00,0x78,0x44,0x44,0x44,0x78,0x48,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x38,0x44,0x40,0x30,0x08,0x04,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x7C,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x00,0x00},
  {0x00,0x00,0x44,0x44,0x44,0x44,0x44,0x44,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x44,0x44,0x44,0x28,0x28,0x28,0x10,0x10,0x00,0x00},
  {0x00,0x00,0x54,0x54,0x54,0x54,0x54,0x28,0x28,0x28,0x00,0x00},
  {0x00,0x00,0x44,0x44,0x28,0x10,0x10,0x28,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x44,0x44,0x28,0x28,0x10,0x10,0x10,0x10,0x00,0x00},
  {0x00,0x00,0x7C,0x04,0x08,0x10,0x10,0x20,0x40,0x7C,0x00,0x00},
  {0x00,0x38,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x38,0x00},
  {0x00,0x40,0x40,0x20,0x20,0x10,0x10,0x08,0x08,0x04,0x04,0x00},
  {0x00,0x38,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x38,0x00},
  {0x00,0x00,0x10,0x28,0x44,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x7C},
  {0x00,0x00,0x10,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x38,0x04,0x3C,0x44,0x44,0x3C,0x00,0x00},
  {0x00,0x00,0x40,0x40,0x78,0x44,0x44,0x44,0x44,0x78,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x38,0x44,0x40,0x40,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x04,0x04,0x3C,0x44,0x44,0x44,0x44,0x3C,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x38,0x44,0x7C,0x40,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x0C,0x10,0x7C,0x10,0x10,0x10,0x10,0x10,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x3C,0x44,0x44,0x44,0x44,0x3C,0x04,0x38},
  {0x00,0x00,0x40,0x40,0x58,0x64,0x44,0x44,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x10,0x00,0x70,0x10,0x10,0x10,0x10,0x7C,0x00,0x00},
  {0x00,0x00,0x08,0x00,0x78,0x08,0x08,0x08,0x08,0x08,0x08,0x70},
  {0x00,0x00,0x40,0x40,0x44,0x58,0x60,0x50,0x48,0x44,0x00,0x00},
  {0x00,0x00,0x70,0x10,0x10,0x10,0x10,0x10,0x10,0x0C,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x68,0x54,0x54,0x54,0x54,0x54,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x58,0x64,0x44,0x44,0x44,0x44,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x38,0x44,0x44,0x44,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x78,0x44,0x44,0x44,0x44,0x78,0x40,0x40},
  {0x00,0x00,0x00,0x00,0x3C,0x44,0x44,0x44,0x44,0x3C,0x04,0x04},
  {0x00,0x00,0x00,0x00,0x58,0x64,0x40,0x40,0x40,0x40,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x38,0x44,0x30,0x08,0x44,0x38,0x00,0x00},
  {0x00,0x00,0x10,0x10,0x7C,0x10,0x10,0x10,0x10,0x0C,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x44,0x44,0x44,0x44,0x4C,0x34,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x44,0x44,0x28,0x28,0x10,0x10,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x54,0x54,0x54,0x54,0x28,0x28,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x44,0x28,0x10,0x10,0x28,0x44,0x00,0x00},
  {0x00,0x00,0x00,0x00,0x44,0x44,0x44,0x28,0x28,0x10,0x10,0x60},
  {0x00,0x00,0x00,0x00,0x7C,0x08,0x10,0x20,0x40,0x7C,0x00,0x00},
  {0x00,0x18,0x20,0x20,0x20,0x40,0x20,0x20,0x20,0x20,0x18,0x00},
  {0x00,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x00},
  {0x00,0x30,0x08,0x08,0x08,0x04,0x08,0x08,0x08,0x08,0x30,0x00},
  {0x00,0x00,0x00,0x00,0x00,0x20,0x54,0x08,0x00,0x00,0x00,0x00}
};


/* ---- 内联辅助 ---- */
static inline uint8_t Sender_DigitalBits(uint32_t pa,uint32_t pi){return (uint8_t)(((pa>>15)&1u)|(((pi>>3)&1u)<<1)|(((pi>>2)&1u)<<2));}

/* ---- 函数原型（合并后统一前置声明，消除跨函数调用顺序依赖） ---- */
static void service(void);
static void pixel(int x,int y,uint16_t c);
static void rect(int x,int y,int w,int h,uint16_t c);
static void text(int x,int y,uint16_t color,const char *fmt,...);
static void button(int x,const char *label,uint16_t color);
static void render(void);
static void input(void);
static void completed(unsigned half,unsigned bit);
static void gpio_half(DMA_HandleTypeDef *h);
static void gpio_full(DMA_HandleTypeDef *h);
static void gpio_a_half(DMA_HandleTypeDef *h);
static void gpio_a_full(DMA_HandleTypeDef *h);
static void gpio_error(DMA_HandleTypeDef *h);
static void update_link(void);
void Sender_MemoryInit(void);
void Sender_AppInit(void);
void Sender_AppTask(void);
void Sender_ControlSubmit(const ScopeControl *control);
void Sender_CaptureInit(void);
void Sender_CaptureSet(int enabled);
void Sender_CaptureService(void);
void Sender_NetInit(void);
void Sender_NetPoll(void);
static void Sender_Send(uint8_t *frame);
void Sender_NewSession(void);
void Sender_PWMSet(uint32_t frequency,int enabled);
uint32_t Sender_PWMFrequency(void);
void Sender_CodecInit(void);
uint32_t Sender_CRC32(const uint8_t *a,size_t n,const uint8_t *b,size_t m);
void Sender_Packet(uint8_t *out,const uint32_t *ch1,const uint32_t *ch2,const uint32_t *gpio_a,const uint32_t *gpio_i,
                   uint32_t seq,uint32_t first,uint8_t reset,const SenderTrigger *trigger);
void Sender_SetReset(uint8_t *frame,uint8_t reset);
void Sender_TriggerReset(SenderTrigger *t,const ScopeControl *c);
void Sender_TriggerBlock(SenderTrigger *t,const uint32_t *a,const uint32_t *b,const uint32_t *pa,const uint32_t *pi,uint32_t first,unsigned count);
void Control_Encode(uint8_t out[CONTROL_FRAME_BYTES],const ScopeControl *c);
int Control_Decode(const uint8_t *frame,size_t bytes,ScopeControl *c);
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *h);
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *h);
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *h);
void HAL_ETH_RxAllocateCallback(uint8_t **p);
void HAL_ETH_RxLinkCallback(void **start,void **end,uint8_t *buf,uint16_t length);

/* ===== 编解码（原 sender_codec.c / sender_trigger.c）===== */
static void le16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void le32(uint8_t *p,uint32_t v){le16(p,(uint16_t)v);le16(p+2,(uint16_t)(v>>16));}
static void be16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
void Sender_CodecInit(void){for(uint32_t i=0;i<256;i++){uint32_t c=i;for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xEDB88320u:0);table[i]=c;}}
uint32_t Sender_CRC32(const uint8_t *a,size_t n,const uint8_t *b,size_t m){
  uint32_t c=0xFFFFFFFFu;for(size_t i=0;i<n;i++)c=table[(c^a[i])&255]^(c>>8);for(size_t i=0;i<m;i++)c=table[(c^b[i])&255]^(c>>8);return c^0xFFFFFFFFu;
}
static uint16_t ip_checksum(const uint8_t *p){uint32_t s=0;for(int i=0;i<20;i+=2)s+=((uint16_t)p[i]<<8)|p[i+1];while(s>>16)s=(s&65535)+(s>>16);return (uint16_t)~s;}
void Sender_SetReset(uint8_t *frame,uint8_t reset){uint8_t *p=frame+42;p[23]=(uint8_t)((p[23]&~1u)|(reset?1:0));le32(p+28,Sender_CRC32(p,28,p+32,SENDER_PAYLOAD-32));}
void Sender_Packet(uint8_t *e,const uint32_t *a,const uint32_t *b,const uint32_t *ga,const uint32_t *gi,uint32_t seq,uint32_t first,uint8_t reset,const SenderTrigger *trigger){
  memset(e,0,SENDER_FRAME_BYTES);memset(e,255,6);
  const uint8_t mac[6]={2,0,0,0,7,0x47};memcpy(e+6,mac,6);be16(e+12,0x0800);
  uint8_t *ip=e+14;ip[0]=0x45;be16(ip+2,SENDER_FRAME_BYTES-14);be16(ip+4,(uint16_t)seq);be16(ip+6,0x4000);ip[8]=64;ip[9]=17;
  ip[12]=192;ip[13]=168;ip[14]=7;ip[15]=1;memset(ip+16,255,4);be16(ip+10,ip_checksum(ip));
  uint8_t *udp=ip+20;be16(udp,5001);be16(udp+2,5000);be16(udp+4,8+SENDER_PAYLOAD); /* IPv4 UDP checksum=0 is allowed */
  uint8_t *p=udp+8;memcpy(p,"SCOP",4);p[4]=2;p[5]=1;le16(p+6,SENDER_BLOCK);le32(p+8,seq);le32(p+12,first);le32(p+16,SENDER_SAMPLE_RATE);le16(p+20,3300);p[22]=31;
  if(trigger){
    if(trigger->valid){p[23]|=2;le32(p+24,trigger->index);}
    if(trigger->control.session){p[23]|=4;le32(p+32,trigger->control.session);le32(p+36,trigger->control.revision);}
  }
  for(unsigned i=0;i<SENDER_BLOCK;i++){
    /* Independent D0=D9/PA15; D1=D7/PI3; D2=D8/PI2. D5 is unused. */
    uint32_t bits=Sender_DigitalBits(ga[i],gi[i]);
    le32(p+SENDER_HEADER+4*i,(a[i]&4095u)|((uint32_t)(b[i]&4095u)<<12)|(bits<<24));
  }
  Sender_SetReset(e,reset);
}
void Sender_TriggerReset(SenderTrigger *t,const ScopeControl *c){memset(t,0,sizeof(*t));t->control=*c;}
void Sender_TriggerBlock(SenderTrigger *t,const uint32_t *a,const uint32_t *b,const uint32_t *pa,const uint32_t *pi,uint32_t first,unsigned count){
  static const uint32_t holdoff[5]={40000,20000,4000,2000,400};
  for(unsigned i=0;i<count;i++){
    unsigned source=t->control.source;uint16_t value=source==0?(uint16_t)(a[i]&4095):source==1?(uint16_t)(b[i]&4095):(uint16_t)((Sender_DigitalBits(pa[i],pi[i])>>(source-2))&1);
    uint16_t level=source<2?t->control.level:(t->control.falling?0:1);uint32_t index=first+i;
    int edge=t->primed&&(t->control.falling?(t->previous>level&&value<=level):(t->previous<level&&value>=level));
    /* Accumulate the quarter-screen pretrigger history before arming.
       Otherwise SINGLE could latch an edge at sample 1 and never obtain
       the samples that should precede it. 'seen' also works across wrap. */
    uint32_t pre=holdoff[t->control.timebase]/4;
    if(edge&&t->seen>=pre&&(!t->valid||(t->control.mode!=2&&(uint32_t)(index-t->index)>=holdoff[t->control.timebase]))){t->index=index;t->valid=1;}
    if(t->seen<pre)t->seen++;
    t->previous=value;t->primed=1;
  }
}

/* ===== 控制帧编解码（原 scope_control.c；reader 助手改名 rle16/rle32/rbe16 以避免与本文件 le16/le32/be16 写端重名）===== */
static uint16_t rle16(const uint8_t *p){return p[0]|(uint16_t)p[1]<<8;}
static uint32_t rle32(const uint8_t *p){return rle16(p)|(uint32_t)rle16(p+2)<<16;}
static uint16_t rbe16(const uint8_t *p){return (uint16_t)p[0]<<8|p[1];}
static void pl16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void pl32(uint8_t *p,uint32_t v){pl16(p,(uint16_t)v);pl16(p+2,(uint16_t)(v>>16));}
static void pb16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static uint32_t crc(const uint8_t *p,size_t n){uint32_t c=0xffffffffu;for(size_t i=0;i<n;i++){c^=p[i];for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xedb88320u:0);}return c^0xffffffffu;}
static uint32_t sum(const uint8_t *p,size_t n,uint32_t s){while(n>=2){s+=rbe16(p);p+=2;n-=2;}if(n)s+=(uint16_t)*p<<8;return s;}
static uint16_t fold(uint32_t s){while(s>>16)s=(s&65535)+(s>>16);return (uint16_t)s;}
void Control_Encode(uint8_t *e,const ScopeControl *c){
  memset(e,0,CONTROL_FRAME_BYTES);memset(e,255,6);const uint8_t mac[6]={2,0,0,0,7,0x46};memcpy(e+6,mac,6);pb16(e+12,0x800);
  uint8_t *ip=e+14;ip[0]=0x45;pb16(ip+2,CONTROL_FRAME_BYTES-14);pb16(ip+6,0x4000);ip[8]=64;ip[9]=17;ip[12]=192;ip[13]=168;ip[14]=7;ip[15]=2;memset(ip+16,255,4);pb16(ip+10,(uint16_t)~fold(sum(ip,20,0)));
  uint8_t *u=ip+20;pb16(u,5002);pb16(u+2,5003);pb16(u+4,36);
  uint8_t *p=u+8;memcpy(p,"SCTL",4);p[4]=1;p[5]=c->timebase;p[6]=c->channels;p[7]=c->source;p[8]=c->mode;p[9]=c->falling;pl16(p+10,c->level);pl32(p+12,c->session);pl32(p+16,c->revision);pl32(p+24,crc(p,24));
}
int Control_Decode(const uint8_t *e,size_t n,ScopeControl *c){
  if(n<CONTROL_FRAME_BYTES||rbe16(e+12)!=0x800)return 0;
  const uint8_t *ip=e+14;size_t h=(ip[0]&15)*4;
  if((ip[0]>>4)!=4||h<20||n<14+h+36||ip[9]!=17||(rbe16(ip+6)&0x3fff)||rbe16(ip+2)!=h+36||fold(sum(ip,h,0))!=65535)return 0;
  if(!(ip[16]==255&&ip[17]==255&&ip[18]==255&&ip[19]==255))return 0;
  const uint8_t *u=ip+h;if(rbe16(u+2)!=5003||rbe16(u+4)!=36)return 0;
  if(rbe16(u+6)&&fold(sum(u,36,sum(ip+12,8,17+36)))!=65535)return 0;
  const uint8_t *p=u+8;
  if(memcmp(p,"SCTL",4)||p[4]!=1||p[5]>4||(p[6]&~31u)||p[7]>4||p[8]>2||p[9]>1||rle16(p+10)>4095||!rle32(p+12)||rle32(p+20)||rle32(p+24)!=crc(p,24))return 0;
  memset(c,0,sizeof(*c));c->timebase=p[5];c->channels=p[6];c->source=p[7];c->mode=p[8];c->falling=p[9];c->level=rle16(p+10);c->session=rle32(p+12);c->revision=rle32(p+16);return 1;
}

/* ===== 采集与发送（原 sender_capture.c）===== */
void Sender_ControlSubmit(const ScopeControl *c){pending_control=*c;control_pending=1;}
static void completed(unsigned half,unsigned bit){
  if(!sender_running)return;
  if(ready_mask[half]&bit){sender_fault=1;return;}
  ready_mask[half]|=(uint8_t)bit;
  if(ready_mask[half]!=15)return;
  ready_mask[half]=0;
  unsigned off=half*SENDER_BLOCK;
  uint32_t seq=packet_sequence++,first=sample_index;sample_index+=SENDER_BLOCK;
  uint32_t current_head=head;
  uint32_t current_tail=tail;
  Sender_TriggerBlock(&trigger,analog2+off,analog1+off,digital_a+off,digital+off,first,SENDER_BLOCK);
  if(current_head-current_tail>=QUEUE_COUNT)return;
  Sender_Packet(queue[current_head&(QUEUE_COUNT-1)].data,analog2+off,analog1+off,digital_a+off,digital+off,seq,first,0,&trigger);
  __DMB();head=current_head+1;
}
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *h){completed(0,h->Instance==ADC1?1:2);}
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *h){completed(1,h->Instance==ADC1?1:2);}
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *h){(void)h;sender_fault=1;}
static void gpio_half(DMA_HandleTypeDef *h){(void)h;completed(0,4);}
static void gpio_full(DMA_HandleTypeDef *h){(void)h;completed(1,4);}
static void gpio_a_half(DMA_HandleTypeDef *h){(void)h;completed(0,8);}
static void gpio_a_full(DMA_HandleTypeDef *h){(void)h;completed(1,8);}
static void gpio_error(DMA_HandleTypeDef *h){(void)h;sender_fault=1;}
void Sender_CaptureInit(void){Sender_CodecInit();Sender_CaptureSet(1);}
void Sender_CaptureSet(int enabled){
  sender_running=0;HAL_TIM_OC_Stop(&htim8,TIM_CHANNEL_1);HAL_TIM_Base_Stop(&htim8);__HAL_TIM_DISABLE_DMA(&htim8,TIM_DMA_UPDATE|TIM_DMA_CC1);
  HAL_ADC_Stop_DMA(&hadc1);HAL_ADC_Stop_DMA(&hadc3);HAL_DMA_Abort(&hdma_tim8_up);HAL_DMA_Abort(&hdma_tim8_ch1);
  ready_mask[0]=ready_mask[1]=0;head=tail=0;sample_index=packet_sequence=0;sender_fault=0;
  Sender_TriggerReset(&trigger,&control);
  if(!enabled)return;
  hdma_tim8_up.XferHalfCpltCallback=gpio_half;hdma_tim8_up.XferCpltCallback=gpio_full;hdma_tim8_up.XferErrorCallback=gpio_error;
  hdma_tim8_ch1.XferHalfCpltCallback=gpio_a_half;hdma_tim8_ch1.XferCpltCallback=gpio_a_full;hdma_tim8_ch1.XferErrorCallback=gpio_error;
  if(HAL_DMA_Start_IT(&hdma_tim8_up,(uint32_t)&GPIOI->IDR,(uint32_t)digital,DMA_COUNT)!=HAL_OK)Error_Handler();
  if(HAL_DMA_Start_IT(&hdma_tim8_ch1,(uint32_t)&GPIOA->IDR,(uint32_t)digital_a,DMA_COUNT)!=HAL_OK)Error_Handler();
  if(HAL_ADC_Start_DMA(&hadc1,(uint32_t*)analog1,DMA_COUNT)!=HAL_OK)Error_Handler();
  if(HAL_ADC_Start_DMA(&hadc3,(uint32_t*)analog2,DMA_COUNT)!=HAL_OK)Error_Handler();
  /* First tick wraps ARR to zero, generating UPDATE and CC1 together.
     This avoids a GPIOA sample occurring one period before the ADC samples. */
  __HAL_TIM_SET_COUNTER(&htim8,__HAL_TIM_GET_AUTORELOAD(&htim8));__HAL_TIM_CLEAR_FLAG(&htim8,TIM_FLAG_UPDATE|TIM_FLAG_CC1);
  __HAL_TIM_ENABLE_DMA(&htim8,TIM_DMA_UPDATE|TIM_DMA_CC1);Sender_NewSession();sender_running=1;
  if(HAL_TIM_OC_Start(&htim8,TIM_CHANNEL_1)!=HAL_OK)Error_Handler();
}
void Sender_CaptureService(void){
  if(control_pending){int running=sender_running;control=pending_control;control_pending=0;Sender_CaptureSet(running);}
  if(sender_fault)Sender_CaptureSet(1);
  /* Send promptly; at 100Mbit/s one frame takes about 90us on the wire. */
  for(unsigned i=0;i<8;i++){
    uint32_t current_tail=tail;
    uint32_t current_head=head;
    if(current_tail==current_head)break;
    Packet *p=&queue[current_tail&(QUEUE_COUNT-1)];__DMB();
    Sender_Send(p->data);
    __DMB();tail=current_tail+1;
  }
}
void Sender_PWMSet(uint32_t freq,int enabled){
  if(freq<100)freq=100;
  if(freq>10000)freq=10000;
  HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_1);
  uint32_t ticks=(1000000u+freq/2)/freq;
  __HAL_TIM_SET_AUTORELOAD(&htim3,ticks-1);__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,ticks/2);__HAL_TIM_SET_COUNTER(&htim3,0);
  htim3.Instance->EGR=TIM_EGR_UG;
  if(enabled)HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
}
uint32_t Sender_PWMFrequency(void){return 1000000u/(__HAL_TIM_GET_AUTORELOAD(&htim3)+1);}

/* ===== 网络（原 sender_net.c）===== */
void Sender_NewSession(void){session_pending=1;}
void HAL_ETH_RxAllocateCallback(uint8_t **p){*p=0;for(unsigned i=0;i<ETH_RX_DESC_CNT+4;i++)if(!rx_pool[i].used){rx_pool[i].used=1;rx_pool[i].next=0;*p=rx_pool[i].data;break;}}
void HAL_ETH_RxLinkCallback(void **start,void **end,uint8_t *buf,uint16_t length){
  RxSlot *s=(RxSlot*)buf;s->len=length;
  if(!*start)*start=s;else ((RxSlot*)*end)->next=s;
  *end=s;
}
static void update_link(void){
  if(!phy_found)return;
  uint32_t bsr=0,status=0;int now=0;
  HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr);
  if(HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr)==HAL_OK&&(bsr&4)&&HAL_ETH_ReadPHYRegister(&heth,phy_address,31,&status)==HAL_OK&&(status&0x1000))now=1;
  if(now==link_up)return;
  if(link_up)HAL_ETH_Stop(&heth);
  if(now){
    uint32_t mode=status&0x1C;ETH_MACConfigTypeDef mac;HAL_ETH_GetMACConfig(&heth,&mac);
    speed=(mode==8||mode==0x18)?100:10;mac.Speed=speed==100?ETH_SPEED_100M:ETH_SPEED_10M;
    mac.DuplexMode=(mode==0x14||mode==0x18)?ETH_FULLDUPLEX_MODE:ETH_HALFDUPLEX_MODE;
    HAL_ETH_SetMACConfig(&heth,&mac);if(HAL_ETH_Start(&heth)!=HAL_OK)now=0;session_pending=1;
  }
  link_up=now;if(!now)speed=0;
}
void Sender_NetInit(void){
  for(uint32_t p=0;p<32;p++){uint32_t id1=0,id2=0;if(HAL_ETH_ReadPHYRegister(&heth,p,2,&id1)==HAL_OK&&HAL_ETH_ReadPHYRegister(&heth,p,3,&id2)==HAL_OK&&id1==7&&(id2&0xFFF0)==0xC130){phy_address=p;phy_found=1;break;}}
  if(phy_found)HAL_ETH_WritePHYRegister(&heth,phy_address,0,0x1200);
  update_link();
}
void Sender_NetPoll(void){
  uint32_t now=HAL_GetTick();if(now-check_tick>=200){check_tick=now;update_link();}
  if(link_up)for(int i=0;i<4;i++){
    RxSlot *p=0;if(HAL_ETH_ReadData(&heth,(void**)&p)!=HAL_OK)break;
    if(p&&!p->next){ScopeControl c;if(Control_Decode(p->data,p->len,&c)){
      if(!has_control||c.session!=last_control.session||(int32_t)(c.revision-last_control.revision)>0){last_control=c;has_control=1;Sender_ControlSubmit(&c);}
    }}
    while(p){RxSlot *next=p->next;p->used=0;p=next;}
  }
}
static void Sender_Send(uint8_t *frame){
  if(!link_up||speed!=100)return;
  if(session_pending)Sender_SetReset(frame,1);
  ETH_BufferTypeDef buffer={0};buffer.buffer=frame;buffer.len=SENDER_FRAME_BYTES;
  ETH_TxPacketConfigTypeDef tx={0};tx.Attributes=ETH_TX_PACKETS_FEATURES_CRCPAD;tx.CRCPadCtrl=ETH_CRC_PAD_INSERT;tx.Length=SENDER_FRAME_BYTES;tx.TxBuffer=&buffer;
  if(HAL_ETH_Transmit(&heth,&tx,2)==HAL_OK)session_pending=0;
}

/* ===== 界面与主循环（原 sender_app.c）===== */
static void service(void){Sender_NetPoll();Sender_CaptureService();}
static void pixel(int x,int y,uint16_t c){if((unsigned)x<480&&(unsigned)y<272)draw[y*480+x]=c;}
static void rect(int x,int y,int w,int h,uint16_t c){for(int j=y;j<y+h;j++){for(int i=x;i<x+w;i++)pixel(i,j,c);if((j-y)%4==0)service();}}
static void text(int x,int y,uint16_t color,const char *fmt,...){
  service();
  char str[100];va_list a;va_start(a,fmt);vsnprintf(str,sizeof(str),fmt,a);va_end(a);service();
  for(char *p=str;*p&&x<478;p++,x+=7){if((p-str)%4==0)service();unsigned ch=(unsigned char)*p;if(ch<32||ch>126)ch='?';
    for(int j=0;j<12;j++)for(int i=0;i<7;i++)if(scope_font[ch-32][j]&(1u<<(6-i)))pixel(x+i,y+j,color);
  }
}
static void button(int x,const char *label,uint16_t color){
  rect(x,PWM_BUTTON_Y,PWM_BUTTON_WIDTH-3,PWM_BUTTON_HEIGHT,0x2124);
  text(x+5,PWM_BUTTON_Y+10,color,"%s",label);
}
static void render(void){
  for(int y=0;y<272;y++){for(int x=0;x<480;x++)draw[y*480+x]=BG;if(y%8==0)service();}
  uint32_t period=__HAL_TIM_GET_AUTORELOAD(&htim3)+1u;
  uint32_t pulse=__HAL_TIM_GET_COMPARE(&htim3,TIM_CHANNEL_1);
  uint32_t duty_tenths=(pulse*1000u+period/2u)/period;
  text(12,105,0xFD20,"%s  %lu Hz  DUTY %lu.%lu%%",pwm_on?"PWM ON":"PWM OFF",
       (unsigned long)Sender_PWMFrequency(),(unsigned long)(duty_tenths/10),(unsigned long)(duty_tenths%10));
  button(0,pwm_on?"PWM OFF":"PWM ON",0xFD20);
  button(PWM_BUTTON_WIDTH,"FREQ -",WHITE);
  button(2*PWM_BUTTON_WIDTH,"FREQ +",WHITE);
  HAL_LTDC_SetAddress_NoReload(&hltdc,(uint32_t)draw,0);HAL_LTDC_Reload(&hltdc,LTDC_RELOAD_VERTICAL_BLANKING);
  uint32_t start=HAL_GetTick();while((hltdc.Instance->SRCR&LTDC_SRCR_VBR)&&HAL_GetTick()-start<25)service();
  if(hltdc.Instance->SRCR&LTDC_SRCR_VBR)HAL_LTDC_Reload(&hltdc,LTDC_RELOAD_IMMEDIATE);
  uint16_t *tmp=front;front=draw;draw=tmp;
}
static void input(void){
  uint8_t t[5]={0};int down=0;unsigned x=0,y=0;
  if(HAL_I2C_Mem_Read(&hi2c3,0x70,2,I2C_MEMADD_SIZE_8BIT,t,5,2)==HAL_OK){down=(t[0]&15)>0;y=((t[1]&15)<<8)|t[2];x=((t[3]&15)<<8)|t[4];if(x>=480||y>=272)down=0;}
  int tapped=down&&!touch_down&&y>=PWM_BUTTON_Y&&y<PWM_BUTTON_Y+PWM_BUTTON_HEIGHT;
  touch_down=(uint8_t)down;
  if(!tapped)return;
  if(x<PWM_BUTTON_WIDTH)pwm_on=!pwm_on;
  else if(x<2*PWM_BUTTON_WIDTH){
    requested_pwm=requested_pwm>1000?requested_pwm-1000:(requested_pwm>100?requested_pwm-100:100);
  }else{
    requested_pwm+=requested_pwm<1000?100:1000;
    if(requested_pwm>10000)requested_pwm=10000;
  }
  Sender_PWMSet(requested_pwm,pwm_on);
  render();
}
void Sender_MemoryInit(void){
  MPU_Region_InitTypeDef r={0};HAL_MPU_Disable();r.Enable=MPU_REGION_ENABLE;r.Number=MPU_REGION_NUMBER0;r.BaseAddress=0xC0000000;r.Size=MPU_REGION_SIZE_8MB;
  r.AccessPermission=MPU_REGION_FULL_ACCESS;r.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;r.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;r.IsShareable=MPU_ACCESS_SHAREABLE;r.TypeExtField=MPU_TEX_LEVEL1;r.DisableExec=MPU_INSTRUCTION_ACCESS_DISABLE;
  HAL_MPU_ConfigRegion(&r);HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
  FMC_SDRAM_CommandTypeDef c={0};c.CommandTarget=FMC_SDRAM_CMD_TARGET_BANK1;c.AutoRefreshNumber=1;c.CommandMode=FMC_SDRAM_CMD_CLK_ENABLE;
  if(HAL_SDRAM_SendCommand(&hsdram1,&c,1000)!=HAL_OK)Error_Handler();
  HAL_Delay(1);c.CommandMode=FMC_SDRAM_CMD_PALL;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_AUTOREFRESH_MODE;c.AutoRefreshNumber=8;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_LOAD_MODE;c.AutoRefreshNumber=1;c.ModeRegisterDefinition=0x230;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);HAL_SDRAM_ProgramRefreshRate(&hsdram1,1542);
}
void Sender_AppInit(void){
  if(SCB->CCR&SCB_CCR_DC_Msk)SCB_DisableDCache();
  SCB_EnableICache();
  memset(FB0,0,480*272*2);memset(FB1,0,480*272*2);Sender_NetInit();Sender_PWMSet(requested_pwm,pwm_on);Sender_CaptureInit();render();
}
void Sender_AppTask(void){
  service();uint32_t tick=HAL_GetTick();if(tick-input_tick>=20){input_tick=tick;input();}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ETH_Init();
  MX_FMC_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_ADC1_Init();
  MX_ADC3_Init();
  MX_TIM3_Init();
  MX_TIM8_Init();
  /* USER CODE BEGIN 2 */
  Sender_AppInit();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    Sender_AppTask();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 400;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_6) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
