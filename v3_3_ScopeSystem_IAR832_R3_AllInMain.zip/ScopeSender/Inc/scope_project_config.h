#ifndef SCOPE_PROJECT_CONFIG_H
#define SCOPE_PROJECT_CONFIG_H
/* 本文件及其在 HAL 头文件 USER CODE 区中的 include 在 CubeMX 重新生成时保留。
   功能代码已全部并入各端 main.c，不再依赖任何 post_generate 脚本。 */
#ifndef ETH_RX_DESC_CNT
#define ETH_RX_DESC_CNT 16U
#endif
#ifndef ETH_TX_DESC_CNT
#define ETH_TX_DESC_CNT 4U
#endif
#if ETH_RX_DESC_CNT != 16U || ETH_TX_DESC_CNT != 4U
#error Incorrect_Ethernet_descriptor_counts
#endif
#endif
