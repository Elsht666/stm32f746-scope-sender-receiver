# ScopeReceiver（接收板）— 无脚本、全 main.c 版

打开 EWARM/ScopeReceiver.eww，或上级 ScopeSystem.eww。Rebuild All 后下载并运行。功能代码全部在 `Src/main.c` 的 USER CODE 0 段，**不依赖任何 .py 脚本**。每次 CubeMX 再生成后，唯一手动核对项：Project → Options → Linker → Config，确认使用 stm32f746xx_flash.icf，RAM 起点 `__ICFEDIT_region_RAM_start__ = 0x20010000`（关系到 DMA 能否工作）。详见上级 README.md 第 4 节。
