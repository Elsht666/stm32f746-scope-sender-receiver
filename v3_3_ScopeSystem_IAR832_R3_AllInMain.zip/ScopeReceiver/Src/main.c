/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "eth.h"
#include "i2c.h"
#include "ltdc.h"
#include "usb_device.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_core.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
/* USER CODE BEGIN PFP */
/* 所有非 static 接口函数均在下方 USER CODE 0 段内按序定义（先定义后调用），
   无需在此前置声明；CubeMX 重新生成时该段原样保留。 */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* =========================================================================
 * 功能代码（全部合并自 App/，纯 C + HAL，不依赖任何脚本）。
 * 说明：原 scope_control.c 的 static 读端助手 le16/le32/be16 与
 *   scope_core.c 的同名 static 冲突，已改名 rle16/rle32/rbe16；其 fold
 *   与 scope_core.c 的 fold 冲突，已改名 cfold。功能完全不变。
 * ========================================================================= */

/* ---- 基础宏（原 scope_core.h / scope_app.h / scope_disk.h / scope_net.h） ---- */
#define SCOPE_POINTS 400u
#define SCOPE_RING_SIZE 65536u
#define SCOPE_PORT 5000u
#define SCOPE_MAX_SAMPLES 256u
#define CONTROL_FRAME_BYTES 70u
#define POOL_COUNT (ETH_RX_DESC_CNT + 4)
#define SECTORS 2048u
#define DATA_SECTOR 17u
#ifndef SCOPE_HOST_TEST
#define DISK ((uint8_t*)0xC0200000u)
#else
static uint8_t host_disk[1048576];
#define DISK host_disk
#endif
#define FB0 ((uint16_t*)0xC0000000u)
#define FB1 ((uint16_t*)0xC0040000u)
#define RING ((uint32_t*)0xC0100000u)
#define SHOT ((uint16_t*)0xC0140000u)
#define SNAPSHOT ((uint32_t*)0xC0180000u)
#define BG 0x0841
#define WHITE 0xFFFF
#define GRID 0x2965
#define MUTED 0x8C71

/* ---- 类型定义（原 scope_core.h / scope_control.h / scope_net.h） ---- */
typedef struct {
  uint8_t timebase, channels, source, mode, falling;
  uint16_t level;
} ScopeConfig;
typedef struct {
  uint32_t sample[SCOPE_POINTS];
  uint32_t rate, step, first_index;
  uint16_t vref;
  uint8_t channels, triggered;
  uint32_t frequency_mhz[5], width_us[3];
  uint16_t vpp_mv[2];
} ScopeFrame;
typedef struct {
  uint32_t *ring, write, valid, next_index, sequence, rate;
  uint32_t packets, bad, lost, stale, last_tick, generation;
  uint16_t vref;
  uint8_t channels, started;
  uint32_t control_session, control_revision, trigger_history[8];
  uint8_t protocol, control_valid, trigger_count, trigger_next;
} ScopeStream;
typedef struct {
  uint8_t timebase, channels, source, mode, falling;
  uint16_t level;
  uint32_t session, revision;
} ScopeControl;
typedef struct RxSlot { uint8_t data[1536]; struct RxSlot *next; uint16_t len; uint8_t used; } RxSlot;

/* ===================== 控制帧编解码（原 scope_control.c） ===================== */
static uint16_t rle16(const uint8_t *p){ return p[0]|(uint16_t)p[1]<<8; }
static uint32_t rle32(const uint8_t *p){ return rle16(p)|(uint32_t)rle16(p+2)<<16; }
static uint16_t rbe16(const uint8_t *p){ return (uint16_t)p[0]<<8|p[1]; }
static void pl16(uint8_t *p, uint16_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void pl32(uint8_t *p, uint32_t v){ pl16(p,(uint16_t)v); pl16(p+2,(uint16_t)(v>>16)); }
static void pb16(uint8_t *p, uint16_t v){ p[0]=(uint8_t)(v>>8); p[1]=(uint8_t)v; }
static uint32_t crc(const uint8_t *p, size_t n){ uint32_t c=0xffffffffu; for(size_t i=0;i<n;i++){ c^=p[i]; for(int j=0;j<8;j++) c=(c>>1)^((c&1)?0xedb88320u:0); } return c^0xffffffffu; }
static uint32_t sum(const uint8_t *p, size_t n, uint32_t s){ while(n>=2){ s+=rbe16(p); p+=2; n-=2; } if(n) s+=(uint16_t)*p<<8; return s; }
static uint16_t cfold(uint32_t s){ while(s>>16) s=(s&65535)+(s>>16); return (uint16_t)s; }
void Control_Encode(uint8_t *e, const ScopeControl *c){
  memset(e,0,CONTROL_FRAME_BYTES); memset(e,255,6); const uint8_t mac[6]={2,0,0,0,7,0x46}; memcpy(e+6,mac,6); pb16(e+12,0x800);
  uint8_t *ip=e+14; ip[0]=0x45; pb16(ip+2,CONTROL_FRAME_BYTES-14); pb16(ip+6,0x4000); ip[8]=64; ip[9]=17; ip[12]=192; ip[13]=168; ip[14]=7; ip[15]=2; memset(ip+16,255,4); pb16(ip+10,(uint16_t)~cfold(sum(ip,20,0)));
  uint8_t *u=ip+20; pb16(u,5002); pb16(u+2,5003); pb16(u+4,36);
  uint8_t *p=u+8; memcpy(p,"SCTL",4); p[4]=1; p[5]=c->timebase; p[6]=c->channels; p[7]=c->source; p[8]=c->mode; p[9]=c->falling; pl16(p+10,c->level); pl32(p+12,c->session); pl32(p+16,c->revision); pl32(p+24,crc(p,24));
}
int Control_Decode(const uint8_t *e, size_t n, ScopeControl *c){
  if(n<CONTROL_FRAME_BYTES||rbe16(e+12)!=0x800) return 0;
  const uint8_t *ip=e+14; size_t h=(ip[0]&15)*4;
  if((ip[0]>>4)!=4||h<20||n<14+h+36||ip[9]!=17||(rbe16(ip+6)&0x3fff)||rbe16(ip+2)!=h+36||cfold(sum(ip,h,0))!=65535) return 0;
  if(!(ip[16]==255&&ip[17]==255&&ip[18]==255&&ip[19]==255)) return 0;
  const uint8_t *u=ip+h; if(rbe16(u+2)!=5003||rbe16(u+4)!=36) return 0;
  if(rbe16(u+6)&&cfold(sum(u,36,sum(ip+12,8,17+36)))!=65535) return 0;
  const uint8_t *p=u+8;
  if(memcmp(p,"SCTL",4)||p[4]!=1||p[5]>4||(p[6]&~31u)||p[7]>4||p[8]>2||p[9]>1||rle16(p+10)>4095||!rle32(p+12)||rle32(p+20)||rle32(p+24)!=crc(p,24)) return 0;
  memset(c,0,sizeof(*c)); c->timebase=p[5]; c->channels=p[6]; c->source=p[7]; c->mode=p[8]; c->falling=p[9]; c->level=rle16(p+10); c->session=rle32(p+12); c->revision=rle32(p+16); return 1;
}

/* ===================== 采样核心（原 scope_core.c） ===================== */
const uint32_t scope_timebase_us[5]={10000,5000,1000,500,100};
static void (*service_hook)(void);
void Scope_SetServiceHook(void (*hook)(void)){ service_hook=hook; }
static void pump(uint32_t i){ if(!(i&511u)&&service_hook) service_hook(); }
static uint16_t le16(const uint8_t *p){ return (uint16_t)(p[0]|(uint16_t)p[1]<<8); }
static uint32_t le32(const uint8_t *p){ return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24; }
static uint16_t be16(const uint8_t *p){ return (uint16_t)((uint16_t)p[0]<<8|p[1]); }
void Scope_Reset(ScopeStream *s, uint32_t *ring){ memset(s,0,sizeof(*s)); s->ring=ring; }
uint32_t Scope_CRC32(const uint8_t *a, size_t n, const uint8_t *b, size_t m){
  static uint32_t table[256]; static int ready;
  if(!ready){ for(uint32_t i=0;i<256;i++){ uint32_t c=i; for(int j=0;j<8;j++) c=(c>>1)^((c&1)?0xEDB88320u:0); table[i]=c; } ready=1; }
  uint32_t crc=0xFFFFFFFFu;
  for(size_t i=0;i<n;i++) crc=table[(crc^a[i])&255]^(crc>>8);
  for(size_t i=0;i<m;i++) crc=table[(crc^b[i])&255]^(crc>>8);
  return crc^0xFFFFFFFFu;
}
int Scope_Ingest(ScopeStream *s, const uint8_t *p, size_t len, uint32_t tick){
  if(len<32||memcmp(p,"SCOP",4)||(p[4]!=1&&p[4]!=2)||p[5]!=1){ s->bad++; return 0; }
  unsigned header=p[4]==2?40:32;
  if(len<header){ s->bad++; return 0; }
  uint32_t n=le16(p+6), seq=le32(p+8), first=le32(p+12), rate=le32(p+16);
  uint16_t ref=le16(p+20); uint8_t mask=p[22];
  if(!n||n>SCOPE_MAX_SAMPLES||len!=header+4*n||rate<5000||rate>500000||ref<3000||ref>3600||!mask||(mask&~31u)||(p[23]&~(p[4]==2?7u:1u))||le32(p+28)!=Scope_CRC32(p,28,p+32,len-32)){
    s->bad++; return 0;
  }
  for(uint32_t i=0;i<n;i++) if(le32(p+header+i*4)&0xF8000000u){ s->bad++; return 0; }
  uint32_t session=p[4]==2?le32(p+32):0, revision=p[4]==2?le32(p+36):0;
  int reset=(p[23]&1)||!s->started||p[4]!=s->protocol||session!=s->control_session||revision!=s->control_revision;
  if(s->started&&!reset&&(int32_t)(seq-s->sequence)<=0){ s->stale++; return 0; }
  if(s->started&&!reset&&(first!=s->next_index||seq!=s->sequence+1)){
    uint32_t gap=seq-s->sequence-1; if(gap<0x80000000u) s->lost+=gap;
    s->valid=0; s->generation++; s->trigger_count=s->trigger_next=0;
  }
  if(reset||rate!=s->rate||ref!=s->vref||mask!=s->channels){ s->valid=0; s->generation++; s->trigger_count=s->trigger_next=0; }
  s->rate=rate; s->vref=ref; s->channels=mask;
  s->protocol=p[4]; s->control_session=session; s->control_revision=revision; s->control_valid=(uint8_t)(p[4]==2&&(p[23]&4)&&session);
  if(p[4]==2&&(p[23]&2)){
    uint32_t index=le32(p+24);
    if(!s->trigger_count||s->trigger_history[(s->trigger_next+7)&7]!=index){
      s->trigger_history[s->trigger_next]=index; s->trigger_next=(s->trigger_next+1)&7;
      if(s->trigger_count<8) s->trigger_count++;
    }
  }
  for(uint32_t i=0;i<n;i++){
    s->ring[s->write]=le32(p+header+i*4); s->write=(s->write+1)&(SCOPE_RING_SIZE-1);
  }
  s->valid+=n; if(s->valid>SCOPE_RING_SIZE) s->valid=SCOPE_RING_SIZE;
  s->next_index=first+n; s->sequence=seq; s->packets++; s->last_tick=tick; s->started=1;
  return 1;
}
static uint32_t raw_at(const uint32_t *raw, uint32_t origin, uint32_t offset){ return raw[(origin+offset)&(SCOPE_RING_SIZE-1)]; }
static int crossed(uint16_t a, uint16_t b, uint16_t level, int falling){ return falling?(a>level&&b<=level):(a<level&&b>=level); }
typedef struct { uint32_t first,last,edges,rise,width_sum,width_count; uint8_t high; } Edges;
static void rise(Edges *e, uint32_t i){ e->high=1; e->rise=i; if(!e->edges) e->first=i; e->last=i; e->edges++; }
static void fall(Edges *e, uint32_t i){ e->high=0; if(e->rise){ e->width_sum+=i-e->rise; e->width_count++; } e->rise=0; }
static uint32_t frequency(const Edges *e, uint32_t rate){ return e->edges>=2&&e->last>e->first?(uint32_t)((uint64_t)(e->edges-1)*rate*1000/(e->last-e->first)):0; }
static void analog_edge(Edges *e, uint16_t v, uint16_t mid, uint16_t hys, uint32_t i){ if(!e->high&&v>mid+hys) rise(e,i); else if(e->high&&v<=mid-hys) fall(e,i); }
int Scope_MakeFrame(const ScopeStream *s, const ScopeConfig *cfg, ScopeFrame *f){
  if(!s->started||cfg->timebase>4||cfg->source>4) return 0;
  const uint32_t *raw=s->ring; uint32_t origin=(s->write-s->valid)&(SCOPE_RING_SIZE-1);
  uint64_t numerator=(uint64_t)s->rate*scope_timebase_us[cfg->timebase];
  /* Exact 50 samples/division: never silently display a false time scale. */
  if(numerator%50000000u) return -1;
  uint32_t step=(uint32_t)(numerator/50000000u), span=step*(SCOPE_POINTS-1)+1;
  if(!step||span>s->valid) return 0;
  uint32_t start=s->valid-span; int triggered=0;
  unsigned shift=cfg->source<2?cfg->source*12:24+cfg->source-2, mask=cfg->source<2?4095:1;
  uint16_t level=cfg->source<2?cfg->level:(cfg->falling?0:1);
  if(s->protocol==2){
    /* Only the acquisition board decides trigger events in SCOP v2. */
    uint32_t first=s->next_index-s->valid;
    if(s->control_valid) for(unsigned n=0;n<s->trigger_count;n++){
      uint32_t index=s->trigger_history[(s->trigger_next+7-n)&7], offset=index-first;
      if(offset>=step*100&&offset<s->valid&&s->valid-1-offset>=step*299){ start=offset-step*100; triggered=1; break; }
    }
  } else if((s->channels&(1u<<cfg->source))&&s->valid>=span+step*100){
    uint32_t newest=s->valid-1-step*299, oldest=step*100;
    /* Search at most one screen of raw data for a recent edge. */
    if(newest>span+oldest) oldest=newest-span;
    uint16_t b=(uint16_t)((raw_at(raw,origin,newest)>>shift)&mask);
    for(uint32_t i=newest;i>=oldest&&i>0;i--){
      pump(i);
      uint16_t a=(uint16_t)((raw_at(raw,origin,i-1)>>shift)&mask);
      int edge=crossed(a,b,level,cfg->falling);
      if(edge){ start=i-step*100; triggered=1; break; }
      b=a;
    }
  }
  if(cfg->mode&&!triggered) return 0;
  memset(f,0,sizeof(*f)); f->rate=s->rate; f->step=step; f->vref=s->vref;
  f->channels=cfg->channels&s->channels; f->triggered=(uint8_t)triggered;
  f->first_index=s->next_index-s->valid+start;
  for(uint32_t i=0;i<SCOPE_POINTS;i++) f->sample[i]=raw_at(raw,origin,start+i*step);
  /* Two shared passes over every raw sample: first analog extrema and digital
     edges, then analog thresholds. This keeps exact raw-sample measurements
     while avoiding ten separate reads of the SDRAM time window. */
  uint16_t lo0=4095,hi0=0,lo1=4095,hi1=0;
  Edges digital[3]={{0}}, analog[2]={{0}};
  uint32_t initial=raw_at(raw,origin,start), previous=(initial>>24)&7;
  for(int ch=0;ch<3;ch++) digital[ch].high=(uint8_t)((previous>>ch)&1);
  for(uint32_t i=0;i<span;i++){
    pump(i); uint32_t word=raw_at(raw,origin,start+i); uint16_t v0=word&4095, v1=(word>>12)&4095;
    if(v0<lo0) lo0=v0;
    if(v0>hi0) hi0=v0;
    if(v1<lo1) lo1=v1;
    if(v1>hi1) hi1=v1;
    uint32_t bits=(word>>24)&7, changed=bits^previous;
    if(i&&changed) for(int ch=0;ch<3;ch++) if(changed&(1u<<ch)){ if(bits&(1u<<ch)) rise(&digital[ch],i); else fall(&digital[ch],i); }
    previous=bits;
  }
  uint16_t mid0=(lo0+hi0)/2, mid1=(lo1+hi1)/2, hys0=(hi0-lo0)/20, hys1=(hi1-lo1)/20;
  uint8_t active0=(f->channels&1)&&(hi0-lo0>=16), active1=(f->channels&2)&&(hi1-lo1>=16);
  analog[0].high=(initial&4095)>mid0; analog[1].high=((initial>>12)&4095)>mid1;
  if(active0||active1) for(uint32_t i=1;i<span;i++){
    pump(i); uint32_t word=raw_at(raw,origin,start+i);
    if(active0) analog_edge(&analog[0],word&4095,mid0,hys0,i);
    if(active1) analog_edge(&analog[1],(word>>12)&4095,mid1,hys1,i);
  }
  if(f->channels&1){ f->vpp_mv[0]=(uint16_t)((uint32_t)(hi0-lo0)*s->vref/4095); f->frequency_mhz[0]=frequency(&analog[0],s->rate); }
  if(f->channels&2){ f->vpp_mv[1]=(uint16_t)((uint32_t)(hi1-lo1)*s->vref/4095); f->frequency_mhz[1]=frequency(&analog[1],s->rate); }
  for(int ch=0;ch<3;ch++) if(f->channels&(4u<<ch)){
    f->frequency_mhz[ch+2]=frequency(&digital[ch],s->rate);
    if(digital[ch].width_count) f->width_us[ch]=(uint32_t)((uint64_t)digital[ch].width_sum*1000000/(s->rate*(uint64_t)digital[ch].width_count));
  }
  return 1;
}
static uint32_t sum16(const uint8_t *p, size_t n, uint32_t sum){
  while(n>=2){ sum+=be16(p); p+=2; n-=2; } if(n) sum+=(uint16_t)p[0]<<8; return sum;
}
static uint16_t fold(uint32_t s){ while(s>>16) s=(s&65535)+(s>>16); return (uint16_t)s; }
const uint8_t *Scope_UDP(const uint8_t *e, size_t len, size_t *payload_len){
  if(len<42||be16(e+12)!=0x0800) return NULL;
  const uint8_t *ip=e+14; size_t ihl=(ip[0]&15)*4;
  if((ip[0]>>4)!=4||ihl<20||len<14+ihl+8||ip[9]!=17) return NULL;
  uint16_t total=be16(ip+2); if(total<ihl+8||total>len-14||(be16(ip+6)&0x3FFF)) return NULL;
  if(fold(sum16(ip,ihl,0))!=65535) return NULL;
  /* Broadcast destination only: no ARP or IP transmission is needed. */
  if(!(ip[16]==255&&ip[17]==255&&ip[18]==255&&ip[19]==255)) return NULL;
  const uint8_t *udp=ip+ihl; uint16_t ulen=be16(udp+4);
  if(be16(udp+2)!=SCOPE_PORT||ulen<8||ulen!=total-ihl) return NULL;
  if(be16(udp+6)){
    uint32_t sum=sum16(ip+12,8,17+ulen); if(fold(sum16(udp,ulen,sum))!=65535) return NULL;
  }
  *payload_len=ulen-8; return udp+8;
}

/* ===================== FAT12 软盘（原 scope_disk.c） ===================== */
static volatile int ready;
static char csv_text[32768];
static uint16_t next_cluster;
static unsigned dir_entry;
static void put16(uint8_t *p, uint16_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void put32(uint8_t *p, uint32_t v){ put16(p,(uint16_t)v); put16(p+2,(uint16_t)(v>>16)); }
static void fat(uint16_t cluster, uint16_t value){
  for(int copy=0;copy<2;copy++){
    uint8_t *f=DISK+(1+copy*6)*512; unsigned o=cluster+cluster/2;
    if(cluster&1){ f[o]=(uint8_t)((f[o]&15)|(value<<4)); f[o+1]=(uint8_t)(value>>4); }
    else { f[o]=(uint8_t)value; f[o+1]=(uint8_t)((f[o+1]&0xF0)|(value>>8)); }
  }
}
static uint8_t *file(const char name[11], uint32_t size){
  uint16_t first=next_cluster, n=(uint16_t)((size+511)/512); uint8_t *d=DISK+13*512+dir_entry++*32;
  memcpy(d,name,11); d[11]=0x21; /* archive + read-only */
  put16(d+24,(uint16_t)((46<<9)|(10<<5)|26)); /* 2026-10-26, no RTC configured */
  put16(d+26,first); put32(d+28,size);
  for(unsigned i=0;i<n;i++) fat(next_cluster++, i+1==n?0xFFF:(uint16_t)(first+i+1));
  return DISK+(DATA_SECTOR+first-2)*512;
}
void Scope_DiskBuild(const ScopeFrame *frame, const uint16_t *pixels){
  ready=0; memset(DISK,0,1048576); next_cluster=2; dir_entry=0;
  uint8_t *b=DISK; b[0]=0xEB; b[1]=0x3C; b[2]=0x90; memcpy(b+3,"SCOPERX ",8);
  put16(b+11,512); b[13]=1; put16(b+14,1); b[16]=2; put16(b+17,64); put16(b+19,SECTORS); b[21]=0xF8;
  put16(b+22,6); put16(b+24,1); put16(b+26,1); b[36]=0x80; b[38]=0x29;
  put32(b+39,0x7462026); memcpy(b+43,"SCOPE_RX   ",11); memcpy(b+54,"FAT12   ",8); b[510]=0x55; b[511]=0xAA;
  fat(0,0xFF8); fat(1,0xFFF);
  static const char info[]="STM32F746G-DISCO receive-only oscilloscope\r\n"
    "WAVE.CSV: 400 displayed samples, 50 points/div, common time axis.\r\n"
    "SCREEN.BMP: exact 480 x 272 RGB screenshot at SAVE.\r\n"
    "Files are frozen until the next SAVE; RAM is cleared on reset.\r\n"
    "Unplug CN13 before SAVE again; then reconnect to refresh host cache.\r\n"
    "No PC is needed for reception, display, trigger or measurement.\r\n";
  memcpy(file("README  TXT",sizeof(info)-1), info, sizeof(info)-1);
  uint8_t *csv=(uint8_t*)csv_text; size_t pos=0;
  pos+=(size_t)snprintf((char*)csv,32768,"time_us,CH1_mV,CH2_mV,D0,D1,D2,channel_mask,sample_index\r\n");
  for(unsigned i=0;i<SCOPE_POINTS;i++){
    uint32_t s=frame->sample[i], a=(s&4095)*frame->vref/4095, bv=((s>>12)&4095)*frame->vref/4095;
    pos+=(size_t)snprintf((char*)csv+pos,32768-pos,"%lu,%lu,%lu,%lu,%lu,%lu,%u,%lu\r\n",
      (unsigned long)((uint64_t)i*frame->step*1000000/frame->rate),(unsigned long)a,(unsigned long)bv,
      (unsigned long)((s>>24)&1),(unsigned long)((s>>25)&1),(unsigned long)((s>>26)&1),frame->channels,
      (unsigned long)(frame->first_index+i*frame->step));
  }
  memcpy(file("WAVE    CSV",(uint32_t)pos), csv, pos);
  uint8_t *bmp=file("SCREEN  BMP",54+480*272*3); bmp[0]='B'; bmp[1]='M'; put32(bmp+2,54+480*272*3);
  put32(bmp+10,54); put32(bmp+14,40); put32(bmp+18,480); put32(bmp+22,272); put16(bmp+26,1); put16(bmp+28,24); put32(bmp+34,480*272*3);
  for(unsigned y=0;y<272;y++) for(unsigned x=0;x<480;x++){
    uint16_t p=pixels[(271-y)*480+x]; uint8_t *q=bmp+54+(y*480+x)*3;
    q[0]=(uint8_t)((p&31)*255/31); q[1]=(uint8_t)(((p>>5)&63)*255/63); q[2]=(uint8_t)((p>>11)*255/31);
  }
  ready=1;
}
int Scope_DiskReady(void){ return ready; }
int Scope_DiskRead(uint8_t *buf, uint32_t sector, uint16_t count){
  if(!ready||sector>=SECTORS||count>SECTORS-sector) return -1;
  memcpy(buf,DISK+sector*512,(size_t)count*512); return 0;
}
#ifdef SCOPE_HOST_TEST
int Scope_DiskDump(const char *path){ FILE *f=fopen(path,"wb"); if(!f) return -1; size_t n=fwrite(DISK,1,1048576,f); fclose(f); return n==1048576?0:-1; }
#endif

/* ===================== 以太网接收（原 scope_net.c） ===================== */
/* MPU keeps DMA SRAM noncached; CPU-owned SDRAM uses write-back cache. */
static RxSlot pool[POOL_COUNT] __attribute__((aligned(32)));
static uint32_t phy_address, check_tick;
static int link_up, phy_found;
static ScopeControl controller;
static uint32_t control_tick;
static uint8_t control_ready, control_due, control_retries;
static uint8_t control_frame[CONTROL_FRAME_BYTES] __attribute__((aligned(32)));
int Scope_NetConfigure(const ScopeConfig *c, int rearm){
  int changed=!control_ready||controller.timebase!=c->timebase||controller.channels!=c->channels||controller.source!=c->source||controller.mode!=c->mode||controller.falling!=c->falling||controller.level!=c->level;
  if(changed||rearm){
    if(!controller.session) controller.session=(HAL_GetTick()^SysTick->VAL^*(const uint32_t*)UID_BASE)|1u;
    controller.timebase=c->timebase; controller.channels=c->channels; controller.source=c->source; controller.mode=c->mode; controller.falling=c->falling; controller.level=c->level;
    controller.revision++; control_ready=1; control_due=1; control_retries=3; return 1;
  }
  return 0;
}
int Scope_NetControlAck(const ScopeStream *s){ return control_ready&&s->protocol==2&&s->control_valid&&s->control_session==controller.session&&s->control_revision==controller.revision; }
static void send_control(uint32_t tick){
  if(!link_up||!control_ready) return;
  if(!control_due&&tick-control_tick<(control_retries?100u:1000u)) return;
  Control_Encode(control_frame,&controller);
  ETH_BufferTypeDef b={0}; b.buffer=control_frame; b.len=CONTROL_FRAME_BYTES;
  ETH_TxPacketConfigTypeDef tx={0}; tx.Attributes=ETH_TX_PACKETS_FEATURES_CRCPAD; tx.CRCPadCtrl=ETH_CRC_PAD_INSERT; tx.Length=CONTROL_FRAME_BYTES; tx.TxBuffer=&b;
  if(HAL_ETH_Transmit(&heth,&tx,2)==HAL_OK){ if(control_retries) control_retries--; }
  control_due=0; /* Failed transmissions also back off; never retry per pump(). */
  control_tick=tick;
}
void HAL_ETH_RxAllocateCallback(uint8_t **buf){
  *buf=0; for(unsigned i=0;i<POOL_COUNT;i++) if(!pool[i].used){ pool[i].used=1; pool[i].len=0; pool[i].next=0; *buf=pool[i].data; break; }
}
void HAL_ETH_RxLinkCallback(void **start, void **end, uint8_t *buf, uint16_t len){
  RxSlot *s=(RxSlot*)buf; s->len=len;
  if(!*start) *start=s; else ((RxSlot*)*end)->next=s;
  *end=s;
}
static void update_link(void){
  uint32_t bsr=0, status=0; int now=0;
  if(!phy_found) return;
  HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr);
  if(HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr)==HAL_OK&&(bsr&4)){
    if(HAL_ETH_ReadPHYRegister(&heth,phy_address,31,&status)==HAL_OK&&(status&0x1000)) now=1;
  }
  if(now==link_up) return;
  if(link_up) HAL_ETH_Stop(&heth);
  if(now){
    ETH_MACConfigTypeDef mac;
    HAL_ETH_GetMACConfig(&heth,&mac);
    uint32_t mode=status&0x1C;
    mac.Speed=(mode==0x08||mode==0x18)?ETH_SPEED_100M:ETH_SPEED_10M;
    mac.DuplexMode=(mode==0x14||mode==0x18)?ETH_FULLDUPLEX_MODE:ETH_HALFDUPLEX_MODE;
    HAL_ETH_SetMACConfig(&heth,&mac);
    if(HAL_ETH_Start(&heth)!=HAL_OK) now=0;
    control_due=1; /* Configuration frames only; ADC data travels in the opposite direction. */
  }
  link_up=now;
}
void Scope_NetInit(void){
  memset(pool,0,sizeof(pool));
  for(uint32_t p=0;p<32;p++){
    uint32_t id1=0, id2=0;
    if(HAL_ETH_ReadPHYRegister(&heth,p,2,&id1)==HAL_OK&&HAL_ETH_ReadPHYRegister(&heth,p,3,&id2)==HAL_OK&&id1==0x0007&&(id2&0xFFF0)==0xC130){ phy_address=p; phy_found=1; break; }
  }
  if(phy_found){
    /* Restart autonegotiation; never force a duplex mismatch. */
    HAL_ETH_WritePHYRegister(&heth,phy_address,0,0x1200);
  }
  update_link();
}
int Scope_NetLink(void){ return link_up; }
void Scope_NetPoll(ScopeStream *stream){
  uint32_t tick=HAL_GetTick();
  if(tick-check_tick>=200){ check_tick=tick; update_link(); }
  if(!link_up) return;
  send_control(tick);
  for(unsigned n=0;n<32;n++){
    RxSlot *packet=0;
    if(HAL_ETH_ReadData(&heth,(void**)&packet)!=HAL_OK) break;
    if(packet){
      size_t len=0; const uint8_t *p=packet->next?0:Scope_UDP(packet->data,packet->len,&len);
      if(p) Scope_Ingest(stream,p,len,tick);
      while(packet){ RxSlot *next=packet->next; packet->used=0; packet=next; }
    }
  }
}

/* ===================== 界面与主循环（原 scope_app.c） ===================== */
/* Rasterized ASCII display font, 7 x 12 pixels. */
const uint8_t scope_font[95][12]={
  {0,0,0,0,0,0,0,0,0,0,0,0},
  {8,8,8,8,0,8,8,0,0,0,0,0},
  {52,20,0,0,0,0,0,0,0,0,0,0},
  {20,126,20,20,126,36,36,0,0,0,0,0},
  {40,40,56,12,10,22,60,16,0,0,0,0},
  {86,92,56,30,26,42,102,0,0,0,0,0},
  {36,44,56,58,110,102,62,0,0,0,0,0},
  {8,8,0,0,0,0,0,0,0,0,0,0},
  {24,16,16,16,16,16,24,8,4,0,0,0},
  {8,12,4,4,4,12,8,24,16,0,0,0},
  {44,28,44,8,0,0,0,0,0,0,0,0},
  {0,8,8,126,8,8,0,0,0,0,0,0},
  {0,0,0,0,0,24,8,8,48,0,0,0},
  {0,0,0,60,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,24,24,0,0,0,0,0},
  {4,12,8,8,16,16,32,32,0,0,0,0},
  {38,38,110,122,34,38,28,0,0,0,0,0},
  {40,8,8,8,8,8,62,0,0,0,0,0},
  {36,6,4,12,24,48,62,0,0,0,0,0},
  {4,4,28,6,2,6,60,0,0,0,0,0},
  {28,20,36,100,126,4,4,0,0,0,0,0},
  {32,32,60,6,6,4,56,0,0,0,0,0},
  {48,32,60,38,34,38,28,0,0,0,0,0},
  {6,4,4,8,8,16,16,0,0,0,0,0},
  {38,54,28,54,34,38,60,0,0,0,0,0},
  {38,34,38,62,6,4,56,0,0,0,0,0},
  {0,24,24,0,0,24,24,0,0,0,0,0},
  {0,24,24,0,0,8,8,8,48,0,0,0},
  {4,12,16,48,16,12,4,0,0,0,0,0},
  {0,0,62,0,62,0,0,0,0,0,0,0},
  {48,24,12,6,12,24,48,0,0,0,0,0},
  {12,4,4,28,0,24,24,0,0,0,0,0},
  {50,34,93,85,94,94,64,96,60,0,0,0},
  {28,20,52,38,62,98,66,0,0,0,0,0},
  {38,38,60,38,34,38,60,0,0,0,0,0},
  {48,32,32,96,32,48,30,0,0,0,0,0},
  {38,34,34,34,34,38,60,0,0,0,0,0},
  {32,32,62,32,32,32,62,0,0,0,0,0},
  {32,32,60,32,32,32,32,0,0,0,0,0},
  {48,32,110,98,98,50,30,0,0,0,0,0},
  {34,34,62,34,34,34,34,0,0,0,0,0},
  {8,8,8,8,8,8,62,0,0,0,0,0},
  {4,4,4,4,4,36,56,0,0,0,0,0},
  {36,40,48,48,40,36,38,0,0,0,0,0},
  {48,48,48,48,48,48,62,0,0,0,0,0},
  {102,118,90,74,66,66,66,0,0,0,0,0},
  {50,50,42,42,46,38,38,0,0,0,0,0},
  {38,98,98,98,98,38,28,0,0,0,0,0},
  {38,34,38,60,32,32,32,0,0,0,0,0},
  {38,98,98,98,98,38,60,8,14,0,0,0},
  {38,38,36,60,44,38,34,0,0,0,0,0},
  {32,32,56,12,6,6,60,0,0,0,0,0},
  {8,8,8,8,8,8,8,0,0,0,0,0},
  {34,34,34,34,34,38,60,0,0,0,0,0},
  {98,34,38,52,20,28,24,0,0,0,0,0},
  {66,66,106,122,54,54,38,0,0,0,0,0},
  {52,28,24,24,28,38,98,0,0,0,0,0},
  {34,52,28,24,8,8,8,0,0,0,0,0},
  {4,4,8,24,16,32,62,0,0,0,0,0},
  {16,16,16,16,16,16,16,16,28,0,0,0},
  {48,16,24,8,8,4,4,2,0,0,0,0},
  {12,12,12,12,12,12,12,12,28,0,0,0},
  {28,52,34,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,127,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0},
  {0,60,6,62,38,38,62,0,0,0,0,0},
  {32,60,54,34,34,38,60,0,0,0,0,0},
  {0,30,48,32,32,48,30,0,0,0,0,0},
  {6,30,38,38,38,38,62,0,0,0,0,0},
  {0,28,38,62,32,48,30,0,0,0,0,0},
  {24,24,126,24,24,24,24,0,0,0,0,0},
  {0,30,38,38,60,32,62,34,60,0,0,0},
  {32,60,54,34,34,34,34,0,0,0,0,0},
  {0,56,8,8,8,8,62,0,0,0,0,0},
  {0,60,4,4,4,4,4,4,56,0,0,0},
  {32,38,44,56,56,44,38,0,0,0,0,0},
  {8,8,8,8,8,8,62,0,0,0,0,0},
  {0,126,106,106,106,106,106,0,0,0,0,0},
  {0,60,54,34,34,34,34,0,0,0,0,0},
  {0,28,38,34,34,38,28,0,0,0,0,0},
  {0,60,54,34,34,38,60,32,32,0,0,0},
  {0,30,38,38,38,38,62,6,6,0,0,0},
  {0,62,50,32,32,32,32,0,0,0,0,0},
  {0,28,32,56,12,6,60,0,0,0,0,0},
  {16,126,16,16,16,16,14,0,0,0,0,0},
  {0,34,34,34,34,38,62,0,0,0,0,0},
  {0,98,38,36,20,20,24,0,0,0,0,0},
  {0,66,74,122,50,54,54,0,0,0,0,0},
  {0,38,52,24,28,52,38,0,0,0,0,0},
  {0,98,38,36,20,24,24,16,112,0,0,0},
  {0,62,4,8,16,16,62,0,0,0,0,0},
  {8,24,24,48,24,24,24,8,12,0,0,0},
  {8,8,8,8,8,8,8,8,8,0,0,0},
  {8,8,8,6,8,8,8,8,48,0,0,0},
  {0,0,0,58,110,0,0,0,0,0,0,0}
};
static const uint16_t colors[5]={0xFFE0,0x07FF,0x07E0,0xF81F,0xFD20};
static const char *names[5]={"CH1","CH2","D0","D1","D2"};
static const char *tb_names[5]={"10ms","5ms","1ms","500us","100us"};
static const char *modes[3]={"AUTO","NORMAL","SINGLE"};
static ScopeStream stream;
static ScopeConfig config={0,31,1,0,0,2048};
static ScopeFrame shown, reference;
static uint16_t *draw=FB1, *front=FB0;
static uint32_t screen_tick, touch_tick, fps_tick, frames, fps, last_packet;
static uint8_t paused, has_frame, compare, has_reference, touch_was_down, button_was_down, measure_channel=2;
static uint8_t no_data;
static uint8_t history_count, history_index, history_next;
static ScopeFrame history[8];
static char notice[48];
static char status_text[80];
static uint32_t status_tick;
static uint8_t status_flags=255;
static uint16_t status_color;
volatile uint32_t scope_timing_ms[3];
extern USBD_HandleTypeDef hUsbDeviceFS;
static void pixel(int x, int y, uint16_t c){ if((unsigned)x<480&&(unsigned)y<272) draw[y*480+x]=c; }
static void rect(int x, int y, int w, int h, uint16_t c){ for(int j=y;j<y+h;j++) for(int i=x;i<x+w;i++) pixel(i,j,c); }
static void line(int x0, int y0, int x1, int y1, uint16_t c){
  int dx=abs(x1-x0), sx=x0<x1?1:-1, dy=-abs(y1-y0), sy=y0<y1?1:-1, e=dx+dy;
  for(;;){ pixel(x0,y0,c); if(x0==x1&&y0==y1) break; int e2=e*2; if(e2>=dy){ e+=dy; x0+=sx; } if(e2<=dx){ e+=dx; y0+=sy; } }
}
static void text(int x, int y, uint16_t color, const char *fmt, ...){
  char str[100]; va_list a; va_start(a,fmt); vsnprintf(str,sizeof(str),fmt,a); va_end(a);
  for(const char *p=str;*p&&x<478;p++,x+=7){ unsigned ch=(unsigned char)*p; if(ch<32||ch>126) ch='?';
    for(int j=0;j<12;j++) for(int i=0;i<7;i++) if(scope_font[ch-32][j]&(1u<<(6-i))) pixel(x+i,y+j,color);
  }
}
static void button(int x, int y, int w, const char *label, uint16_t c, int active){
  rect(x,y,w-2,22,active?0x2124:0x1082); line(x,y+21,x+w-3,y+21,c); text(x+4,y+5,active?c:MUTED,"%s",label);
}
static void net_poll(void){ Scope_NetPoll(&stream); }
static void wave(const ScopeFrame *f, int ghost){
  for(int ch=0;ch<5;ch++){
    if(!(f->channels&(1u<<ch))) continue;
    uint16_t color=ghost?0x632C:colors[ch]; int oldy=0;
    for(unsigned i=0;i<SCOPE_POINTS;i++){
      uint32_t p=f->sample[i]; int y;
      if(ch<2) y=169-(int)(((p>>(ch*12))&4095)*120/4095);
      else y=190+(ch-2)*21-((p>>(24+ch-2))&1)*11;
      if(i){ if(ch<2) line(39+i,oldy,40+i,y,color); else { line(39+i,oldy,40+i,oldy,color); line(40+i,oldy,40+i,y,color); } }
      oldy=y;
    }
    net_poll();
  }
}
static void render(void){
  /* The previous request must have completed before its old buffer is reused. */
  if(hltdc.Instance->SRCR&LTDC_SRCR_VBR) return;
  for(int y=0;y<272;y++){ for(int x=0;x<480;x++) draw[y*480+x]=BG; if(y%24==0) net_poll(); }
  button(0,0,80,tb_names[config.timebase],WHITE,1);
  for(int i=0;i<5;i++) button(80+i*46,0,46,names[i],colors[i],(config.channels>>i)&1);
  button(310,0,80,paused?"RUN":"PAUSE",WHITE,1); button(390,0,90,"SAVE USB",WHITE,has_frame);
  if(has_frame){
    text(2,26,colors[0],"CH1 %lumV %lu.%luHz",(unsigned long)shown.vpp_mv[0],(unsigned long)(shown.frequency_mhz[0]/1000),(unsigned long)(shown.frequency_mhz[0]%1000/100));
    text(242,26,colors[1],"CH2 %lumV %lu.%luHz",(unsigned long)shown.vpp_mv[1],(unsigned long)(shown.frequency_mhz[1]/1000),(unsigned long)(shown.frequency_mhz[1]%1000/100));
    int ch=measure_channel;
    text(2,38,colors[ch],"%s %lu.%luHz HIGH %luus",names[ch],(unsigned long)(shown.frequency_mhz[ch]/1000),(unsigned long)(shown.frequency_mhz[ch]%1000/100),(unsigned long)shown.width_us[ch-2]);
    text(300,38,MUTED,"%luSa/s %luFPS",(unsigned long)shown.rate,(unsigned long)fps);
  } else {
    if(!Scope_NetLink()) text(2,26,WHITE,"Ethernet link down: check CN9");
    else if(!stream.started) text(2,26,WHITE,"LINK up: waiting for valid data");
    else if(!Scope_NetControlAck(&stream)) text(2,26,WHITE,"Waiting for sender config ACK");
    else {
      uint32_t rate=stream.rate?stream.rate:500000u;
      uint32_t step=(uint32_t)((uint64_t)rate*scope_timebase_us[config.timebase]/50000000u);
      uint32_t need=step*(SCOPE_POINTS-1u)+1u;
      if(stream.valid<need) text(2,26,WHITE,"Buffering: %lu/%lu samples",(unsigned long)stream.valid,(unsigned long)need);
      else text(2,26,WHITE,config.mode?"Waiting for trigger":"Preparing waveform");
    }
  }
  for(int i=0;i<=8;i++) line(40+i*50,49,40+i*50,233,GRID);
  for(int i=0;i<=4;i++) line(40,49+i*30,440,49+i*30,GRID);
  for(int i=0;i<3;i++){ line(40,190+i*21,440,190+i*21,GRID); text(2,178+i*21,colors[i+2],"D%d",i); }
  uint16_t scale=has_frame?shown.vref:stream.vref;
  text(2,49,MUTED,"%lu.%luV",(unsigned long)(scale/1000),(unsigned long)(scale%1000/100)); text(2,158,MUTED,"0V");
  text(443,65,MUTED,"50"); text(443,78,MUTED,"pts"); text(443,91,MUTED,"/div");
  if(has_frame){
    if(compare&&has_reference&&reference.step==shown.step&&reference.rate==shown.rate&&reference.vref==shown.vref) wave(&reference,1);
    wave(&shown,0);
  }
  if(config.source<2){ int y=169-(int)((uint32_t)config.level*120/4095); for(int x=40;x<440;x+=8) line(x,y,x+2,y,colors[config.source]); }
  char src[12]; snprintf(src,sizeof(src),"TR:%s",names[config.source]);
  button(0,236,70,src,colors[config.source],1); button(70,236,60,modes[config.mode],WHITE,1);
  button(130,236,50,config.falling?"FALL":"RISE",WHITE,1); button(180,236,26,"-",WHITE,1);
  text(208,242,WHITE,"%lumV",(unsigned long)((uint32_t)config.level*(stream.vref?stream.vref:3300)/4095));
  button(266,236,26,"+",WHITE,1); button(292,236,60,compare?"CMP ON":"REF",WHITE,1);
  button(352,236,60,"HIST",WHITE,history_count>0); button(412,236,68,"MEAS",colors[measure_channel],1);
  if(notice[0]) text(2,260,WHITE,"%s",notice);
  else {
    int linked=Scope_NetLink(), ack=Scope_NetControlAck(&stream);
    uint8_t flags=(uint8_t)((linked?1:0)|(paused?2:0)|(no_data?4:0)|(ack?8:0));
    uint32_t now=HAL_GetTick();
    /* Keep the fast waveform redraw independent from the readable 1Hz footer.
       Link, pause, timeout and configuration changes still appear promptly. */
    if(flags!=status_flags||now-status_tick>=1000u){
      const char *state=paused?"HOLD":(no_data?"NO DATA":(!ack?"CFG WAIT":(has_frame&&shown.triggered?"HW TRIG":"AUTO")));
      snprintf(status_text,sizeof(status_text),"%-7s %-8s RX:%10lu LOSS:%10lu CRC:%10lu",linked?"LINK":"NO LINK",state,(unsigned long)stream.packets,(unsigned long)stream.lost,(unsigned long)stream.bad);
      status_color=linked?0x07E0:0xF800; status_tick=now; status_flags=flags;
    }
    text(2,260,status_color,"%s",status_text);
  }
  /* Swap during vertical blank; never draw into a pending front buffer. */
  SCB_CleanDCache_by_Addr((uint32_t*)draw,480*272*2);
  HAL_LTDC_SetAddress_NoReload(&hltdc,(uint32_t)draw,0);
  HAL_LTDC_Reload(&hltdc,LTDC_RELOAD_VERTICAL_BLANKING);
  /* Next frame starts >=40ms later; vertical blank completes asynchronously. */
  uint16_t *old=front; front=draw; draw=old;
}
static void export_frame(void){
  if(!has_frame){ snprintf(notice,sizeof(notice),"No received frame to save"); return; }
  paused=1;
  render(); /* Keep CSV and screenshot synchronized after a history selection. */
  /* Disk contents remain immutable while the host is reading them. */
  USBD_Stop(&hUsbDeviceFS); HAL_Delay(30);
  memcpy(SHOT,front,480*272*2); Scope_DiskBuild(&shown,SHOT);
  USBD_Start(&hUsbDeviceFS);
  snprintf(notice,sizeof(notice),"Saved: unplug/replug USB CN13 to read files");
}
static void action(unsigned x, unsigned y){
  notice[0]=0;
  if(y<24){
    if(x<80){
      if(paused) snprintf(notice,sizeof(notice),"Resume before changing timebase");
      else { config.timebase=(config.timebase+1)%5; has_frame=0; compare=0; last_packet=0; }
    }
    else if(x<310){ config.channels^=1u<<((x-80)/46); shown.channels=config.channels&stream.channels; }
    else if(x<390){ paused=!paused; if(!paused){ Scope_NetConfigure(&config,1); has_frame=0; last_packet=0; } }
    else export_frame();
  } else if(y>=236&&y<259){
    if(x<70) config.source=(config.source+1)%5;
    else if(x<130){ config.mode=(config.mode+1)%3; paused=0; }
    else if(x<180) config.falling=!config.falling;
    else if(x<206) config.level=config.level>128?config.level-128:0;
    else if(x>=266&&x<292) config.level=config.level<3967?config.level+128:4095;
    else if(x>=292&&x<352){ if(!has_reference&&has_frame){ reference=shown; has_reference=1; } compare=!compare; }
    else if(x>=352&&x<412&&history_count){
      paused=1; shown=history[(history_next+7-history_index)%8]; history_index=(history_index+1)%history_count; has_frame=1; config.channels=shown.channels;
      for(unsigned t=0;t<5;t++) if((uint64_t)shown.step*50000000/shown.rate==scope_timebase_us[t]) config.timebase=(uint8_t)t;
    }
    else if(x>=412) measure_channel=measure_channel==4?2:measure_channel+1;
  } else if(y>=49&&y<=169&&config.source<2){ config.level=(uint16_t)((169-y)*4095/120); }
}
static void input(void){
  uint8_t t[5]={0}; int down=0; unsigned x=0, y=0;
  if(HAL_I2C_Mem_Read(&hi2c3,0x70,0x02,I2C_MEMADD_SIZE_8BIT,t,5,2)==HAL_OK){
    down=(t[0]&15)>0;
    /* FT5336 on this board has TS_SWAP_XY in ST's BSP. */
    y=((t[1]&15)<<8)|t[2]; x=((t[3]&15)<<8)|t[4];
    if(x>=480||y>=272) down=0;
  }
  if(down&&!touch_was_down) action(x,y);
  touch_was_down=(uint8_t)down;
  int btn=HAL_GPIO_ReadPin(GPIOI,GPIO_PIN_11)==GPIO_PIN_SET;
  if(btn&&!button_was_down){ paused=!paused; notice[0]=0; if(!paused){ Scope_NetConfigure(&config,1); has_frame=0; last_packet=0; } }
  button_was_down=(uint8_t)btn;
}
void Scope_MemoryInit(void){
  MPU_Region_InitTypeDef region={0}; HAL_MPU_Disable(); region.Enable=MPU_REGION_ENABLE;
  region.Number=MPU_REGION_NUMBER0; region.BaseAddress=0xC0000000; region.Size=MPU_REGION_SIZE_8MB;
  region.AccessPermission=MPU_REGION_FULL_ACCESS; region.IsBufferable=MPU_ACCESS_BUFFERABLE;
  region.IsCacheable=MPU_ACCESS_CACHEABLE; region.IsShareable=MPU_ACCESS_NOT_SHAREABLE;
  region.TypeExtField=MPU_TEX_LEVEL1; region.DisableExec=MPU_INSTRUCTION_ACCESS_DISABLE;
  HAL_MPU_ConfigRegion(&region);
  /* Ethernet descriptors, packet pool and CPU globals stay noncached in SRAM.
     Only CPU-owned SDRAM uses write-back cache; LCD buffers are cleaned above. */
  region.Number=MPU_REGION_NUMBER1; region.BaseAddress=0x20000000; region.Size=MPU_REGION_SIZE_512KB;
  region.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE; region.IsCacheable=MPU_ACCESS_NOT_CACHEABLE; region.IsShareable=MPU_ACCESS_SHAREABLE;
  HAL_MPU_ConfigRegion(&region); HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
  FMC_SDRAM_CommandTypeDef c={0}; c.CommandTarget=FMC_SDRAM_CMD_TARGET_BANK1; c.AutoRefreshNumber=1;
  c.CommandMode=FMC_SDRAM_CMD_CLK_ENABLE; if(HAL_SDRAM_SendCommand(&hsdram1,&c,1000)!=HAL_OK) Error_Handler();
  HAL_Delay(1); c.CommandMode=FMC_SDRAM_CMD_PALL; HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_AUTOREFRESH_MODE; c.AutoRefreshNumber=8; HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_LOAD_MODE; c.AutoRefreshNumber=1; c.ModeRegisterDefinition=0x230; /* burst 1, CAS 3, write single */
  HAL_SDRAM_SendCommand(&hsdram1,&c,1000); HAL_SDRAM_ProgramRefreshRate(&hsdram1,1542); /* 100MHz, 64ms/4096 minus 20 */
  volatile uint32_t *test=RING; test[0]=0x55AA1234; test[1]=0xAA55FEDC;
  if(test[0]!=0x55AA1234||test[1]!=0xAA55FEDC) Error_Handler();
}
void Scope_AppInit(void){
  /* MPU keeps all Ethernet DMA memory noncached; SDRAM is write-back cached. */
  if(SCB->CCR&SCB_CCR_DC_Msk) SCB_DisableDCache();
  SCB_EnableICache(); SCB_EnableDCache();
  memset(FB0,0,480*272*2); memset(FB1,0,480*272*2);
  SCB_CleanDCache_by_Addr((uint32_t*)FB0,480*272*2);
  Scope_Reset(&stream,RING); stream.vref=3300; Scope_SetServiceHook(net_poll);
  uint8_t zero=0; HAL_I2C_Mem_Write(&hi2c3,0x70,0xA4,I2C_MEMADD_SIZE_8BIT,&zero,1,20);
  Scope_NetInit(); Scope_NetConfigure(&config,1); render();
}
void Scope_AppTask(void){
  uint32_t tick=HAL_GetTick(); net_poll();
  if(tick-touch_tick>=20){ touch_tick=tick; input(); }
  if(Scope_NetConfigure(&config,0)){ has_frame=0; last_packet=0; compare=0; }
  if(tick-fps_tick>=1000){ fps=frames; frames=0; fps_tick=tick; }
  if(tick-screen_tick<40) return;
  screen_tick=tick;
  if(!paused&&Scope_NetControlAck(&stream)&&stream.packets!=last_packet){
    /* Work from an immutable copy while the model pumps live Ethernet RX. */
    uint32_t measure_tick=HAL_GetTick();
    ScopeStream frozen=stream; memcpy(SNAPSHOT,RING,SCOPE_RING_SIZE*sizeof(uint32_t)); frozen.ring=SNAPSHOT;
    scope_timing_ms[0]=HAL_GetTick()-measure_tick; measure_tick=HAL_GetTick();
    ScopeFrame next; int result=Scope_MakeFrame(&frozen,&config,&next);
    scope_timing_ms[1]=HAL_GetTick()-measure_tick;
    if(result==1&&(!has_frame||next.first_index!=shown.first_index)){
      shown=next; has_frame=1; last_packet=stream.packets; frames++;
      if(config.mode==2) paused=1;
      history[history_next]=shown; history_next=(history_next+1)%8; if(history_count<8) history_count++; history_index=0;
    } else if(result<0) snprintf(notice,sizeof(notice),"Source rate too low for 50 points/div");
  }
  /* net_poll() and Scope_MakeFrame() may receive packets after the entry tick.
     Read time after those calls: entry_tick - newer_last_tick would wrap and
     falsely report a timeout while live data is arriving. Keep RX counters
     visible even during a real outage instead of replacing them with notice. */
  no_data=(uint8_t)(!paused&&stream.started&&HAL_GetTick()-stream.last_tick>500u);
  uint32_t render_tick=HAL_GetTick(); render(); scope_timing_ms[2]=HAL_GetTick()-render_tick;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ETH_Init();
  MX_FMC_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
  Scope_AppInit();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    Scope_AppTask();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 400;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_6) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LTDC|RCC_PERIPHCLK_CLK48;
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 384;
  PeriphClkInitStruct.PLLSAI.PLLSAIR = 5;
  PeriphClkInitStruct.PLLSAI.PLLSAIQ = 2;
  PeriphClkInitStruct.PLLSAI.PLLSAIP = RCC_PLLSAIP_DIV8;
  PeriphClkInitStruct.PLLSAIDivQ = 1;
  PeriphClkInitStruct.PLLSAIDivR = RCC_PLLSAIDIVR_8;
  PeriphClkInitStruct.Clk48ClockSelection = RCC_CLK48SOURCE_PLLSAIP;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
