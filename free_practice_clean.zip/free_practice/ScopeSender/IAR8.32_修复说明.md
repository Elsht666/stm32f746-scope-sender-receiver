# IAR 8.32 编译修复

日期：2026-10-28。基于用户当前的 `C:\STM32F\Project_backup\ScopeSender` 副本修复，保留 EWARM V8.32 的 CubeMX 配置。

## 报错原因

`sender_app.h` 实际位于工程的 `App` 目录。CubeMX 切换为 IAR 后，生成的 EWARM 工程只有外设初始化文件，没有添加自定义应用的头文件路径和源文件，因此出现 Pe1696。

## 完成的修复

- 在 IAR 的 C/C++ Compiler → Preprocessor → Additional include directories 中添加 `$PROJ_DIR$/../App`。
- 增加 Application/Sender 分组，包含 `sender_app.c`、`sender_capture.c`、`sender_codec.c`、`sender_net.c`、`scope_font.c`。
- 补回 16 个 RX、4 个 TX 描述符配置，并把 Ethernet 描述符改为 32 字节对齐的普通 SRAM 分配，避免 CubeMX 默认固定地址布局重叠。
- IAR 链接配置把内部 RAM 起点改为 0x20010000，避开 DMA 无法访问的 DTCM。
- 对中断更新的计数值分别读取，再用于队列判断和界面格式化，消除 IAR Pa082 警告。
- 更新 `tools/post_generate.py`，以后从 CubeMX 再生成 EWARM 工程后，也可自动恢复这些集成配置。

## 打开与重建

关闭并重新打开 `EWARM/ScopeSender.ewp`，选择 ScopeSender 配置，执行 Project → Rebuild All。重新打开可以避免已打开的 IAR 继续使用旧工程配置。

从 CubeMX 再生成代码后，先在工程根目录执行：

```powershell
python tools/post_generate.py
```

然后回 IAR 重新加载工程并 Rebuild All。不要只复制 `sender_app.h` 到 Src，应用的全部 C 文件仍必须参与构建。

## 实际验证

- 本机 IAR EWARM 8.32.3 的 IarBuild 已实际编译并链接全部应用：**0 错误、0 警告**。
- IAR map 确认 RX 描述符为 0x20021480，TX 描述符为 0x200219A0，ADC 和 GPIO 缓冲也均在 DMA 可访问的 SRAM 内，并满足 32 字节对齐。
- IAR 产物位于 `EWARM/ScopeSender/Exe/ScopeSender.out`、`ScopeSender.hex`，链接 map 位于 `EWARM/ScopeSender/List/ScopeSender.map`。
- 本次完成的是 IAR 工程迁移与编译验证，**没有把新生成的 IAR 固件烧到板上**。原 `联调验证.md` 中的实板记录是此前 GNU Arm 固件的记录。

引脚与通信协议保持原工程配置。麦克风、电位器的通道取决于实际接入 A0 或 A1，界面的 POT/MIC 是固定说明文字。
