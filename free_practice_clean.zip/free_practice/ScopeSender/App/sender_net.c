#include "sender_app.h"
#include "sender_codec.h"
#include "eth.h"
#include <string.h>
static uint8_t rx_buffers[ETH_RX_DESC_CNT+2][1536] __attribute__((aligned(32)));
static uint8_t rx_used[ETH_RX_DESC_CNT+2];
static uint32_t phy_address,check_tick;
static int phy_found,link_up,speed;
static uint8_t session_pending=1;
void Sender_NewSession(void){session_pending=1;}
void HAL_ETH_RxAllocateCallback(uint8_t **p){*p=0;for(unsigned i=0;i<ETH_RX_DESC_CNT+2;i++)if(!rx_used[i]){rx_used[i]=1;*p=rx_buffers[i];break;}}
void HAL_ETH_RxLinkCallback(void **start,void **end,uint8_t *buf,uint16_t length){
  (void)length;for(unsigned i=0;i<ETH_RX_DESC_CNT+2;i++)if(buf==rx_buffers[i]){rx_used[i]=0;break;}
  *start=buf;*end=buf; /* Sender discards incoming Ethernet frames. */
}
static void update_link(void){
  if(!phy_found)return;
  uint32_t bsr=0,status=0;int now=0;
  HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr);
  if(HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr)==HAL_OK&&(bsr&4)&&HAL_ETH_ReadPHYRegister(&heth,phy_address,31,&status)==HAL_OK&&(status&0x1000))now=1;
  if(now==link_up)return;
  if(link_up)HAL_ETH_Stop(&heth);
  if(now){
    uint32_t mode=status&0x1C;ETH_MACConfigTypeDef mac;HAL_ETH_GetMACConfig(&heth,&mac);
    speed=(mode==8||mode==0x18)?100:10;mac.Speed=speed==100?ETH_SPEED_100M:ETH_SPEED_10M;
    mac.DuplexMode=(mode==0x14||mode==0x18)?ETH_FULLDUPLEX_MODE:ETH_HALFDUPLEX_MODE;
    HAL_ETH_SetMACConfig(&heth,&mac);if(HAL_ETH_Start(&heth)!=HAL_OK)now=0;session_pending=1;
  }
  link_up=now;if(!now)speed=0;
}
void Sender_NetInit(void){
  for(uint32_t p=0;p<32;p++){uint32_t id1=0,id2=0;if(HAL_ETH_ReadPHYRegister(&heth,p,2,&id1)==HAL_OK&&HAL_ETH_ReadPHYRegister(&heth,p,3,&id2)==HAL_OK&&id1==7&&(id2&0xFFF0)==0xC130){phy_address=p;phy_found=1;break;}}
  if(phy_found)HAL_ETH_WritePHYRegister(&heth,phy_address,0,0x1200);
  update_link();
}
int Sender_NetLink(void){return link_up;}
int Sender_NetSpeed(void){return speed;}
void Sender_NetPoll(void){
  uint32_t now=HAL_GetTick();if(now-check_tick>=200){check_tick=now;update_link();}
  if(link_up)for(int i=0;i<4;i++){void *p=0;if(HAL_ETH_ReadData(&heth,&p)!=HAL_OK)break;}
}
int Sender_Send(uint8_t *frame){
  if(!link_up||speed!=100)return 0;
  if(session_pending)Sender_SetReset(frame,1);
  ETH_BufferTypeDef buffer={0};buffer.buffer=frame;buffer.len=SENDER_FRAME_BYTES;
  ETH_TxPacketConfigTypeDef tx={0};tx.Attributes=ETH_TX_PACKETS_FEATURES_CRCPAD;tx.CRCPadCtrl=ETH_CRC_PAD_INSERT;tx.Length=SENDER_FRAME_BYTES;tx.TxBuffer=&buffer;
  HAL_StatusTypeDef result=HAL_ETH_Transmit(&heth,&tx,2);
  if(result==HAL_OK)session_pending=0;
  return result==HAL_OK;
}
