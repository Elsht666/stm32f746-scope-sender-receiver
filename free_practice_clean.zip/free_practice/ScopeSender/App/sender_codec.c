#include "sender_codec.h"
#include <string.h>
static uint32_t table[256];
static void le16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void le32(uint8_t *p,uint32_t v){le16(p,(uint16_t)v);le16(p+2,(uint16_t)(v>>16));}
static void be16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
void Sender_CodecInit(void){for(uint32_t i=0;i<256;i++){uint32_t c=i;for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xEDB88320u:0);table[i]=c;}}
uint32_t Sender_CRC32(const uint8_t *a,size_t n,const uint8_t *b,size_t m){
  uint32_t c=0xFFFFFFFFu;for(size_t i=0;i<n;i++)c=table[(c^a[i])&255]^(c>>8);for(size_t i=0;i<m;i++)c=table[(c^b[i])&255]^(c>>8);return c^0xFFFFFFFFu;
}
static uint16_t ip_checksum(const uint8_t *p){uint32_t s=0;for(int i=0;i<20;i+=2)s+=((uint16_t)p[i]<<8)|p[i+1];while(s>>16)s=(s&65535)+(s>>16);return (uint16_t)~s;}
void Sender_SetReset(uint8_t *frame,uint8_t reset){uint8_t *p=frame+42;p[23]=reset?1:0;le32(p+28,Sender_CRC32(p,28,p+32,SENDER_BLOCK*4));}
void Sender_Packet(uint8_t *e,const uint32_t *a,const uint32_t *b,const uint32_t *g,uint32_t seq,uint32_t first,uint8_t reset){
  memset(e,0,SENDER_FRAME_BYTES);memset(e,255,6);
  const uint8_t mac[6]={2,0,0,0,7,0x47};memcpy(e+6,mac,6);be16(e+12,0x0800);
  uint8_t *ip=e+14;ip[0]=0x45;be16(ip+2,SENDER_FRAME_BYTES-14);be16(ip+4,(uint16_t)seq);be16(ip+6,0x4000);ip[8]=64;ip[9]=17;
  ip[12]=192;ip[13]=168;ip[14]=7;ip[15]=1;memset(ip+16,255,4);be16(ip+10,ip_checksum(ip));
  uint8_t *udp=ip+20;be16(udp,5001);be16(udp+2,5000);be16(udp+4,8+SENDER_PAYLOAD); /* IPv4 UDP checksum=0 is allowed */
  uint8_t *p=udp+8;memcpy(p,"SCOP",4);p[4]=1;p[5]=1;le16(p+6,SENDER_BLOCK);le32(p+8,seq);le32(p+12,first);le32(p+16,SENDER_SAMPLE_RATE);le16(p+20,3300);p[22]=31;le32(p+24,first*2u);
  for(unsigned i=0;i<SENDER_BLOCK;i++){
    /* D0=Arduino D5/PI0; D1=Arduino D7/PI3; D2=Arduino D8/PI2. */
    uint32_t bits=(g[i]&1u)|((g[i]>>2)&2u)|(g[i]&4u);
    le32(p+32+4*i,(a[i]&4095u)|((uint32_t)(b[i]&4095u)<<12)|(bits<<24));
  }
  Sender_SetReset(e,reset);
}
