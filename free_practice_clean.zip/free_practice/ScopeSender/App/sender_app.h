#ifndef SENDER_APP_H
#define SENDER_APP_H
#include <stdint.h>
void Sender_MemoryInit(void);
void Sender_AppInit(void);
void Sender_AppTask(void);
void Sender_CaptureInit(void);
void Sender_CaptureSet(int enabled);
void Sender_CaptureService(void);
void Sender_NetInit(void);
void Sender_NetPoll(void);
int Sender_NetLink(void);
int Sender_NetSpeed(void);
int Sender_Send(uint8_t *frame);
void Sender_NewSession(void);
void Sender_PWMSet(uint32_t frequency,int enabled);
uint32_t Sender_PWMFrequency(void);
extern volatile uint32_t sender_blocks,sender_drops,sender_sent,sender_errors,sender_restarts;
extern volatile uint16_t sender_adc1,sender_adc2;
extern volatile uint8_t sender_digital,sender_running,sender_fault;
#endif
