#ifndef SENDER_CODEC_H
#define SENDER_CODEC_H
#include <stddef.h>
#include <stdint.h>
#define SENDER_SAMPLE_RATE 500000u
#define SENDER_BLOCK 256u
#define SENDER_PAYLOAD (32u+SENDER_BLOCK*4u)
#define SENDER_FRAME_BYTES (14u+20u+8u+SENDER_PAYLOAD)
void Sender_CodecInit(void);
uint32_t Sender_CRC32(const uint8_t *a,size_t n,const uint8_t *b,size_t m);
void Sender_Packet(uint8_t *out,const uint32_t *ch1,const uint32_t *ch2,const uint32_t *gpio,
                   uint32_t seq,uint32_t first,uint8_t reset);
void Sender_SetReset(uint8_t *frame,uint8_t reset);
#endif
