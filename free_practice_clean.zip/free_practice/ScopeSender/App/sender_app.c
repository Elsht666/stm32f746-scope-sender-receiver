#include "sender_app.h"
#include "main.h"
#include "fmc.h"
#include "i2c.h"
#include "ltdc.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define FB0 ((uint16_t*)0xC0000000u)
#define FB1 ((uint16_t*)0xC0040000u)
#define BG 0x0841
#define WHITE 0xFFFF
#define CYAN 0x07FF
#define YELLOW 0xFFE0
static uint16_t *draw=FB1,*front=FB0;
static uint32_t screen_tick,input_tick,requested_pwm=1000;
static uint8_t pwm_on,touch_down,button_down;
extern const uint8_t scope_font[95][12];
static void service(void){Sender_NetPoll();Sender_CaptureService();}
static void pixel(int x,int y,uint16_t c){if((unsigned)x<480&&(unsigned)y<272)draw[y*480+x]=c;}
static void rect(int x,int y,int w,int h,uint16_t c){for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++)pixel(i,j,c);}
static void text(int x,int y,uint16_t color,const char *fmt,...){
  char str[100];va_list a;va_start(a,fmt);vsnprintf(str,sizeof(str),fmt,a);va_end(a);
  for(char *p=str;*p&&x<478;p++,x+=7){unsigned ch=(unsigned char)*p;if(ch<32||ch>126)ch='?';
    for(int j=0;j<12;j++)for(int i=0;i<7;i++)if(scope_font[ch-32][j]&(1u<<(6-i)))pixel(x+i,y+j,color);
  }
}
static void button(int x,int w,const char *s,uint16_t color){rect(x,226,w-3,30,0x2124);text(x+5,236,color,"%s",s);}
static void render(void){
  for(int y=0;y<272;y++){for(int x=0;x<480;x++)draw[y*480+x]=BG;if(y%24==0)service();}
  /* Read each ISR-owned value separately before formatting a display line. */
  uint16_t adc1=sender_adc1;
  uint16_t adc2=sender_adc2;
  uint8_t bits=sender_digital;
  uint32_t sent=sender_sent;
  uint32_t drops=sender_drops;
  uint32_t errors=sender_errors;
  uint32_t blocks=sender_blocks;
  uint32_t restarts=sender_restarts;
  uint8_t running=sender_running;
  text(12,9,WHITE,"SCOP SENDER - STM32F746G-DISCO");
  text(12,31,Sender_NetLink()?0x07E0:0xF800,"CN9: %s %dMbps",Sender_NetLink()?"LINK":"NO LINK",Sender_NetSpeed());
  text(12,51,WHITE,"ADC1 + ADC3 + GPIO : 500000 samples/s");
  text(12,75,YELLOW,"CH1 POT : A0 / PA0  %4u  %4lumV",adc1,(unsigned long)adc1*3300/4095);
  text(12,95,CYAN,"CH2 MIC : A1 / PF10 %4u  %4lumV",adc2,(unsigned long)adc2*3300/4095);
  text(12,117,0x07E0,"D0=D5:%d  D1=D7:%d  D2=D8:%d",bits&1,(bits>>1)&1,(bits>>2)&1);
  text(12,139,WHITE,"TX:%lu  DROP:%lu  ERR:%lu",(unsigned long)sent,(unsigned long)drops,(unsigned long)errors);
  text(12,159,WHITE,"CAP:%lu blocks  RESTART:%lu  %s",(unsigned long)blocks,(unsigned long)restarts,running?"RUN":"STOP");
  text(12,181,0xFD20,"D3 / PB4 : %s  %luHz  DUTY 50%%",pwm_on?"PWM ON":"PWM OFF",(unsigned long)Sender_PWMFrequency());
  text(12,203,WHITE,"MODULE VCC = 3.3V; A0/A1 SIGNAL <=3.3V");
  button(0,120,running?"STOP ADC":"START ADC",WHITE);
  button(120,120,pwm_on?"PWM OFF":"PWM ON",0xFD20);button(240,120,"FREQ -",WHITE);button(360,120,"FREQ +",WHITE);
  text(8,260,WHITE,"UDP 255.255.255.255:5000  CONNECT CN9 TO RECEIVER");
  HAL_LTDC_SetAddress_NoReload(&hltdc,(uint32_t)draw,0);HAL_LTDC_Reload(&hltdc,LTDC_RELOAD_VERTICAL_BLANKING);
  uint32_t start=HAL_GetTick();while((hltdc.Instance->SRCR&LTDC_SRCR_VBR)&&HAL_GetTick()-start<25)service();
  if(hltdc.Instance->SRCR&LTDC_SRCR_VBR)HAL_LTDC_Reload(&hltdc,LTDC_RELOAD_IMMEDIATE);
  uint16_t *tmp=front;front=draw;draw=tmp;
}
static void input(void){
  uint8_t t[5]={0};int down=0;unsigned x=0,y=0;
  if(HAL_I2C_Mem_Read(&hi2c3,0x70,2,I2C_MEMADD_SIZE_8BIT,t,5,2)==HAL_OK){down=(t[0]&15)>0;y=((t[1]&15)<<8)|t[2];x=((t[3]&15)<<8)|t[4];if(x>=480||y>=272)down=0;}
  if(down&&!touch_down&&y>=226&&y<258){
    if(x<120)Sender_CaptureSet(!sender_running);
    else if(x<240){pwm_on=!pwm_on;Sender_PWMSet(requested_pwm,pwm_on);}
    else if(x<360){requested_pwm=requested_pwm>1000?requested_pwm-1000:(requested_pwm>100?requested_pwm-100:100);Sender_PWMSet(requested_pwm,pwm_on);}
    else{requested_pwm+=requested_pwm<1000?100:1000;if(requested_pwm>10000)requested_pwm=10000;Sender_PWMSet(requested_pwm,pwm_on);}
  }
  touch_down=(uint8_t)down;
  int pressed=HAL_GPIO_ReadPin(GPIOI,GPIO_PIN_11)==GPIO_PIN_SET;
  if(pressed&&!button_down)Sender_CaptureSet(!sender_running);
  button_down=(uint8_t)pressed;
}
void Sender_MemoryInit(void){
  MPU_Region_InitTypeDef r={0};HAL_MPU_Disable();r.Enable=MPU_REGION_ENABLE;r.Number=MPU_REGION_NUMBER0;r.BaseAddress=0xC0000000;r.Size=MPU_REGION_SIZE_8MB;
  r.AccessPermission=MPU_REGION_FULL_ACCESS;r.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;r.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;r.IsShareable=MPU_ACCESS_SHAREABLE;r.TypeExtField=MPU_TEX_LEVEL1;r.DisableExec=MPU_INSTRUCTION_ACCESS_DISABLE;
  HAL_MPU_ConfigRegion(&r);HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
  FMC_SDRAM_CommandTypeDef c={0};c.CommandTarget=FMC_SDRAM_CMD_TARGET_BANK1;c.AutoRefreshNumber=1;c.CommandMode=FMC_SDRAM_CMD_CLK_ENABLE;
  if(HAL_SDRAM_SendCommand(&hsdram1,&c,1000)!=HAL_OK)Error_Handler();
  HAL_Delay(1);c.CommandMode=FMC_SDRAM_CMD_PALL;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_AUTOREFRESH_MODE;c.AutoRefreshNumber=8;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_LOAD_MODE;c.AutoRefreshNumber=1;c.ModeRegisterDefinition=0x230;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);HAL_SDRAM_ProgramRefreshRate(&hsdram1,1542);
}
void Sender_AppInit(void){
  if(SCB->CCR&SCB_CCR_DC_Msk)SCB_DisableDCache();
  SCB_EnableICache();
  memset(FB0,0,480*272*2);memset(FB1,0,480*272*2);Sender_NetInit();Sender_PWMSet(1000,0);Sender_CaptureInit();render();
}
void Sender_AppTask(void){
  service();uint32_t tick=HAL_GetTick();if(tick-input_tick>=20){input_tick=tick;input();}
  if(tick-screen_tick>=200){screen_tick=tick;render();}
}
