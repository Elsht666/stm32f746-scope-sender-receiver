# STM32F746G-DISCO 以太网采集发送端

本目录已补齐 IAR EWARM 8.32 支持，实编译为 **0 错误、0 警告**。使用 IAR 时打开 `EWARM/ScopeSender.ewp`，重新生成后的操作和验证范围见 [IAR8.32_修复说明.md](IAR8.32_修复说明.md)。本次 IAR 固件尚未烧录实板。

本工程与同目录的 `ScopeReceiver` 配套。发送板采集两路模拟和三路数字信号，以 UDP 广播传给接收板，电脑仅用于供电、烧录和调试。

**模块接线请先看 [接线说明.md](接线说明.md)**。已选择电位器 A0、麦克风 A1、数字输入 D5/D7/D8，测试方波输出 D3。

## 已实现

- ADC1_IN0 / PA0（A0）和 ADC3_IN8 / PF10（A1），12 位独立 ADC，由同一个 TIM8 事件触发，每通道 500000 Sa/s。
- TIM8_UPDATE 同时请求 DMA2 采样 GPIOI 的 PI0、PI3、PI2，对应三路数字输入。数字与模拟共用采样时钟；数字 GPIO 总线传输和 ADC 的采样孔径存在小于一个采样周期的硬件延迟，不能解释为电气上完全同时锁存。
- ADC1、ADC3、GPIO 三个循环 DMA 的半满/满事件汇合后打包，每包 256 组样本。发生 DMA 对齐异常或采集错误时重新同步，避免把不同时段拼成同一组数据。
- 32 包发送队列，SCOP v1 / IPv4 / UDP 广播，源 IP 192.168.7.1，目的 IP 255.255.255.255，目的端口 5000；与接收端协议一致。
- 采集与网络发送分离；LAN8742 自动协商，500kSa/s 模式需要 100M 链路，10M 时屏幕提示速率且不发送无法承载的全速数据。
- TIM3 / D3 输出 100Hz～10kHz、50% 占空比测试方波，默认关闭；触摸控制启停和频率。
- 屏幕显示实时 ADC 数值、数字输入、采集包数、发包数、队列丢包及错误统计。USER 按钮和 `STOP ADC / START ADC` 控制采集。

没有自动生成的假 ADC 波形。A0/A1 未连接时会采到悬空噪声，看到变化不代表已连接麦克风或电位器。

## 工程和固件

- `ScopeSender.ioc`：STM32CubeMX 6.18.1、STM32Cube FW_F7 V1.17.4 的配置，已实际生成代码。
- `Build/ScopeSender.hex`、`.bin`、`.elf`：已编译的发送端固件；Flash 地址 0x08000000。
- `Src/`、`Inc/`、`Drivers/`：CubeMX 初始化、HAL 与 CMSIS。
- `App/sender_capture.c`：循环 DMA、三路完成同步、发送队列、PWM。
- `App/sender_codec.c`：Ethernet / IPv4 / UDP / SCOP 编码及 CRC32。
- `App/sender_net.c`：PHY 自动协商及 Ethernet MAC 发包，不需要 LwIP、ARP 应答或路由器。
- `App/sender_app.c`：发送端触摸界面和状态显示。
- `MDK-ARM/ScopeSender.uvprojx`：Keil 工程；`GCC/` 和 `build.py` 为已经验证的 GNU Arm 构建。

修改 CubeMX 后的操作：

```powershell
python tools/post_generate.py
python build.py
```

只连接要烧录的一块板时，可执行 `python flash.py`。该脚本在检测到多个 ST-LINK 时会停止，防止覆盖错板；两板同时连接时，需要在 CubeProgrammer 中明确选择对应 ST-LINK。

## 关键硬件配置

系统时钟 200MHz；APB1=50MHz，APB1 定时器=100MHz；APB2=100MHz，TIM8=200MHz。TIM8 PSC=0、ARR=399，产生 500kHz 采样事件；两个 ADC 时钟均为 25MHz，采样时间 15 周期。

DMA：ADC1 使用 DMA2_Stream4 / Channel0，ADC3 使用 DMA2_Stream0 / Channel2，GPIOI 使用 DMA2_Stream1 / Channel7。缓冲和描述符全部位于 DMA 可访问的 SRAM1/2，发送端数据缓存关闭。

本芯片存在 TIM1/TIM8 触发 ADC 丢触发的已知限制，工程按 ST 官方 ES0290 第 2.2.1 节使用**双边沿触发**，实板已确认三个 DMA 的采样计数一致。不要把 ADC 的外部触发边沿改回单独 RISING。[ST 官方 ES0290](https://www.st.com.cn/resource/en/errata_sheet/es0290-stm32f74xxx-and-stm32f75xxx-device-limitations-stmicroelectronics.pdf)

## 联调

1. 两板 CN14 接电脑供电，CN9 之间接网线。
2. 发送端显示 `LINK 100Mbps`，TX 持续增加；接收端 RX 持续增加。
3. 接收端五个通道打开，先用 5ms/div、AUTO。启动或重连时允许重新积累连续样本。
4. 接上电位器和麦克风后，再检查电压、音频及触发；模块电源和输出范围必须符合接线说明。
5. 需要提高项 5 米验收时，换至少 5 米网线后重新记录帧率和连续性；本次不根据未知网线长度声称已完成 5 米验收。

已完成的实板和离线检查见 [联调验证.md](联调验证.md)。
