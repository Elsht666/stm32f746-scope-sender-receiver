# 接收端 IAR 8.32 编译修复

日期：2026-10-28。基于用户当前的 `C:\STM32F\Project_backup\ScopeReceiver` 副本，保留 CubeMX 的 EWARM V8.32 配置。

## 原因与修复

`scope_app.h` 在 `App` 目录中。CubeMX 切换到 IAR 后没有自动加入自定义应用目录，导致 main.c、fmc.c、usbd_storage_if.c 报 Pe1696。

本次补齐以下配置：

- C/C++ Compiler → Preprocessor → Additional include directories 增加 `$PROJ_DIR$/../App`。
- Application/Scope 分组加入 `scope_app.c`、`scope_core.c`、`scope_net.c`、`scope_disk.c`、`scope_font.c`。
- 保留 CubeMX 生成的 USB MSC 库，恢复应用的只读存储回调及静态 USB 分配接口。
- 恢复 64 个 RX、4 个 TX 描述符；Ethernet 描述符使用 32 字节对齐的普通 SRAM 分配，避免默认固定地址重叠。
- IAR 的 RAM 链接起点为 0x20010000，避开 DMA 无法访问的 DTCM。
- `tools/post_generate.py` 已支持恢复 EWARM 应用分组、头文件路径和内存布局。

## 使用

在 IAR 中重新加载 `EWARM/ScopeReceiver.ewp`，选择 ScopeReceiver 配置，执行 Project → Rebuild All。提示文件被外部修改时，选择加载磁盘上的新版本。

以后在 CubeMX 重新生成代码后，先在工程根目录运行：

```powershell
python tools/post_generate.py
```

再重新加载 IAR 工程并 Rebuild All。

## 验证

- 本机 IAR EWARM 8.32.3 实际编译、链接全部应用和 USB MSC：**0 错误、0 警告**。
- IAR map：RX 描述符 0x20035CC0，TX 描述符 0x20037F20，接收池 0x200101C0，均在 DMA 可访问的 SRAM 内且满足 32 字节对齐。
- IAR 报告只读代码 38600 字节、只读数据 2306 字节、读写数据 172193 字节，内部 RAM 在 256KB 布局范围内。
- GNU Arm 构建也通过；实际接收核心、触发、测量、丢包/乱序处理和 CSV/BMP 导出的本机测试通过，独立 FAT12 解析验证通过。
- IAR 固件位于 `EWARM/ScopeReceiver/Exe/ScopeReceiver.hex`、`ScopeReceiver.out`；链接 map 位于 `EWARM/ScopeReceiver/List/ScopeReceiver.map`。

本次完成工程迁移、编译链接和离线测试，**没有重新烧录 IAR 固件做实板验证**。原有实板联调记录对应此前的 GNU Arm 固件。
