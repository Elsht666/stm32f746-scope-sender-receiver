#include "scope_core.h"
#include <string.h>
const uint32_t scope_timebase_us[5]={10000,5000,1000,500,100};
static void (*service_hook)(void);
void Scope_SetServiceHook(void (*hook)(void)){service_hook=hook;}
static void pump(uint32_t i){if(!(i&511u)&&service_hook)service_hook();}
static uint16_t le16(const uint8_t *p){return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static uint32_t le32(const uint8_t *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint16_t be16(const uint8_t *p){return (uint16_t)((uint16_t)p[0]<<8|p[1]);}
void Scope_Reset(ScopeStream *s,uint32_t *ring){memset(s,0,sizeof(*s));s->ring=ring;}
uint32_t Scope_CRC32(const uint8_t *a,size_t n,const uint8_t *b,size_t m){
  static uint32_t table[256];static int ready;
  if(!ready){for(uint32_t i=0;i<256;i++){uint32_t c=i;for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xEDB88320u:0);table[i]=c;}ready=1;}
  uint32_t crc=0xFFFFFFFFu;
  for(size_t i=0;i<n;i++)crc=table[(crc^a[i])&255]^(crc>>8);
  for(size_t i=0;i<m;i++)crc=table[(crc^b[i])&255]^(crc>>8);
  return crc^0xFFFFFFFFu;
}
int Scope_Ingest(ScopeStream *s,const uint8_t *p,size_t len,uint32_t tick){
  if(len<32||memcmp(p,"SCOP",4)||p[4]!=1||p[5]!=1){s->bad++;return 0;}
  uint32_t n=le16(p+6),seq=le32(p+8),first=le32(p+12),rate=le32(p+16);
  uint16_t ref=le16(p+20);uint8_t mask=p[22];
  if(!n||n>SCOPE_MAX_SAMPLES||len!=32+4*n||rate<5000||rate>500000||ref<3000||ref>3600||!mask||(mask&~31u)||(p[23]&~1u)||le32(p+28)!=Scope_CRC32(p,28,p+32,4*n)){
    s->bad++;return 0;
  }
  for(uint32_t i=0;i<n;i++)if(le32(p+32+i*4)&0xF8000000u){s->bad++;return 0;}
  int reset=(p[23]&1)||!s->started;
  if(s->started&&!reset&&(int32_t)(seq-s->sequence)<=0){s->stale++;return 0;}
  if(s->started&&!reset&&(first!=s->next_index||seq!=s->sequence+1)){
    uint32_t gap=seq-s->sequence-1;if(gap<0x80000000u)s->lost+=gap;
    s->valid=0;s->generation++;
  }
  if(reset||rate!=s->rate||ref!=s->vref||mask!=s->channels){s->valid=0;s->generation++;}
  s->rate=rate;s->vref=ref;s->channels=mask;
  for(uint32_t i=0;i<n;i++){
    s->ring[s->write]=le32(p+32+i*4);s->write=(s->write+1)&(SCOPE_RING_SIZE-1);
  }
  s->valid+=n;if(s->valid>SCOPE_RING_SIZE)s->valid=SCOPE_RING_SIZE;
  s->next_index=first+n;s->sequence=seq;s->packets++;s->last_tick=tick;s->started=1;
  return 1;
}
static uint32_t raw_at(const uint32_t *raw,uint32_t origin,uint32_t offset){return raw[(origin+offset)&(SCOPE_RING_SIZE-1)];}
static int crossed(uint16_t a,uint16_t b,uint16_t level,int falling){return falling?(a>level&&b<=level):(a<level&&b>=level);}
typedef struct {uint32_t first,last,edges,rise,width_sum,width_count;uint8_t high;} Edges;
static void rise(Edges *e,uint32_t i){e->high=1;e->rise=i;if(!e->edges)e->first=i;e->last=i;e->edges++;}
static void fall(Edges *e,uint32_t i){e->high=0;if(e->rise){e->width_sum+=i-e->rise;e->width_count++;}e->rise=0;}
static uint32_t frequency(const Edges *e,uint32_t rate){return e->edges>=2&&e->last>e->first?(uint32_t)((uint64_t)(e->edges-1)*rate*1000/(e->last-e->first)):0;}
static void analog_edge(Edges *e,uint16_t v,uint16_t mid,uint16_t hys,uint32_t i){if(!e->high&&v>mid+hys)rise(e,i);else if(e->high&&v<=mid-hys)fall(e,i);}
int Scope_MakeFrame(const ScopeStream *s,const ScopeConfig *cfg,ScopeFrame *f){
  if(!s->started||cfg->timebase>4||cfg->source>4)return 0;
  const uint32_t *raw=s->ring;uint32_t origin=(s->write-s->valid)&(SCOPE_RING_SIZE-1);
  uint64_t numerator=(uint64_t)s->rate*scope_timebase_us[cfg->timebase];
  /* Exact 50 samples/division: never silently display a false time scale. */
  if(numerator%50000000u)return -1;
  uint32_t step=(uint32_t)(numerator/50000000u),span=step*(SCOPE_POINTS-1)+1;
  if(!step||span>s->valid)return 0;
  uint32_t start=s->valid-span;int triggered=0;
  unsigned shift=cfg->source<2?cfg->source*12:24+cfg->source-2,mask=cfg->source<2?4095:1;
  uint16_t level=cfg->source<2?cfg->level:(cfg->falling?0:1);
  if((s->channels&(1u<<cfg->source))&&s->valid>=span+step*100){
    uint32_t newest=s->valid-1-step*299,oldest=step*100;
    /* Search at most one screen of raw data for a recent edge. */
    if(newest>span+oldest)oldest=newest-span;
    uint16_t b=(uint16_t)((raw_at(raw,origin,newest)>>shift)&mask);
    for(uint32_t i=newest;i>=oldest&&i>0;i--){
      pump(i);
      uint16_t a=(uint16_t)((raw_at(raw,origin,i-1)>>shift)&mask);
      int edge=crossed(a,b,level,cfg->falling);
      if(edge){start=i-step*100;triggered=1;break;}
      b=a;
    }
  }
  if(cfg->mode&&!triggered)return 0;
  memset(f,0,sizeof(*f));f->rate=s->rate;f->step=step;f->vref=s->vref;
  f->channels=cfg->channels&s->channels;f->triggered=(uint8_t)triggered;
  f->first_index=s->next_index-s->valid+start;
  for(uint32_t i=0;i<SCOPE_POINTS;i++)f->sample[i]=raw_at(raw,origin,start+i*step);
  /* Two shared passes over every raw sample: first analog extrema and digital
     edges, then analog thresholds. This keeps exact raw-sample measurements
     while avoiding ten separate reads of the SDRAM time window. */
  uint16_t lo0=4095,hi0=0,lo1=4095,hi1=0;
  Edges digital[3]={{0}},analog[2]={{0}};
  uint32_t initial=raw_at(raw,origin,start),previous=(initial>>24)&7;
  for(int ch=0;ch<3;ch++)digital[ch].high=(uint8_t)((previous>>ch)&1);
  for(uint32_t i=0;i<span;i++){
    pump(i);uint32_t word=raw_at(raw,origin,start+i);uint16_t v0=word&4095,v1=(word>>12)&4095;
    if(v0<lo0)lo0=v0;
    if(v0>hi0)hi0=v0;
    if(v1<lo1)lo1=v1;
    if(v1>hi1)hi1=v1;
    uint32_t bits=(word>>24)&7,changed=bits^previous;
    if(i&&changed)for(int ch=0;ch<3;ch++)if(changed&(1u<<ch)){if(bits&(1u<<ch))rise(&digital[ch],i);else fall(&digital[ch],i);}
    previous=bits;
  }
  uint16_t mid0=(lo0+hi0)/2,mid1=(lo1+hi1)/2,hys0=(hi0-lo0)/20,hys1=(hi1-lo1)/20;
  uint8_t active0=(f->channels&1)&&(hi0-lo0>=16),active1=(f->channels&2)&&(hi1-lo1>=16);
  analog[0].high=(initial&4095)>mid0;analog[1].high=((initial>>12)&4095)>mid1;
  if(active0||active1)for(uint32_t i=1;i<span;i++){
    pump(i);uint32_t word=raw_at(raw,origin,start+i);
    if(active0)analog_edge(&analog[0],word&4095,mid0,hys0,i);
    if(active1)analog_edge(&analog[1],(word>>12)&4095,mid1,hys1,i);
  }
  if(f->channels&1){f->vpp_mv[0]=(uint16_t)((uint32_t)(hi0-lo0)*s->vref/4095);f->frequency_mhz[0]=frequency(&analog[0],s->rate);}
  if(f->channels&2){f->vpp_mv[1]=(uint16_t)((uint32_t)(hi1-lo1)*s->vref/4095);f->frequency_mhz[1]=frequency(&analog[1],s->rate);}
  for(int ch=0;ch<3;ch++)if(f->channels&(4u<<ch)){
    f->frequency_mhz[ch+2]=frequency(&digital[ch],s->rate);
    if(digital[ch].width_count)f->width_us[ch]=(uint32_t)((uint64_t)digital[ch].width_sum*1000000/(s->rate*(uint64_t)digital[ch].width_count));
  }
  return 1;
}
static uint32_t sum16(const uint8_t *p,size_t n,uint32_t sum){
  while(n>=2){sum+=be16(p);p+=2;n-=2;}if(n)sum+=(uint16_t)p[0]<<8;return sum;
}
static uint16_t fold(uint32_t s){while(s>>16)s=(s&65535)+(s>>16);return (uint16_t)s;}
const uint8_t *Scope_UDP(const uint8_t *e,size_t len,size_t *payload_len){
  if(len<42||be16(e+12)!=0x0800)return NULL;
  const uint8_t *ip=e+14;size_t ihl=(ip[0]&15)*4;
  if((ip[0]>>4)!=4||ihl<20||len<14+ihl+8||ip[9]!=17)return NULL;
  uint16_t total=be16(ip+2);if(total<ihl+8||total>len-14||(be16(ip+6)&0x3FFF))return NULL;
  if(fold(sum16(ip,ihl,0))!=65535)return NULL;
  /* Broadcast destination only: no ARP or IP transmission is needed. */
  if(!(ip[16]==255&&ip[17]==255&&ip[18]==255&&ip[19]==255))return NULL;
  const uint8_t *udp=ip+ihl;uint16_t ulen=be16(udp+4);
  if(be16(udp+2)!=SCOPE_PORT||ulen<8||ulen!=total-ihl)return NULL;
  if(be16(udp+6)){
    uint32_t sum=sum16(ip+12,8,17+ulen);if(fold(sum16(udp,ulen,sum))!=65535)return NULL;
  }
  *payload_len=ulen-8;return udp+8;
}
