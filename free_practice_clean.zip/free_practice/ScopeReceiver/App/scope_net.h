#ifndef SCOPE_NET_H
#define SCOPE_NET_H
#include "scope_core.h"
void Scope_NetInit(void);
void Scope_NetPoll(ScopeStream *s);
int Scope_NetLink(void);
#endif
