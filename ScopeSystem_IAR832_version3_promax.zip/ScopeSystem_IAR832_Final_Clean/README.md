# STM32F746G-DISCO 示波器系统：最终 IAR 源码工程

本工程以已经验证成功的 R3 为基础，适用 STM32CubeMX 6.18.1（EWARM，最低 V8.32）和 IAR for ARM 8.32.1。功能源码、外设配置及 IAR 编译配置均与验证版一致。

此前两端在原生 IAR 8.32.1 中均以 0 错误、0 警告编译并烧录，用户确认 10ms、5ms 五条波形显示正常，电位器、麦克风实时响应，DROP、LOSS、CRC 均为 0。

## 打开与编译

1. 完整解压压缩包，打开本目录 ScopeSystem.eww，同时加载发送、接收两个工程。
2. 选择 ScopeSender，执行 Project → Rebuild All；再选择 ScopeReceiver，同样执行 Rebuild All。当前工程已配置完成，可直接编译。
3. 对应工程按 Ctrl+D 下载并调试，停在 main 后按 F5 运行。
4. 两板同时连接时，探针列表中发送板选择 43244853，接收板选择 67244354。完整序号分别为 066FFF313130525043244853、066FFF514966504867244354。
5. 两板 CN14 连接电脑供电，CN9 之间接网线。电脑不需要运行转发程序。接线及操作见《使用与接线说明.md》。

单独打开也可以使用 ScopeSender/EWARM/ScopeSender.eww 或 ScopeReceiver/EWARM/ScopeReceiver.eww。编译后，IAR 会重新生成各自 EWARM/<工程名>/Obj、Exe、List 目录，固件在 Exe 下。

## 目录内容

| 目录或文件 | 用途 |
|---|---|
| ScopeSystem.eww | 两端共用的 IAR 工作区入口 |
| ScopeSender、ScopeReceiver 下的 .ioc | CubeMX 芯片、引脚、时钟及外设配置 |
| App | 手写应用源码：采样、通信、触发、界面及导出 |
| Inc、Src | 头文件与 CubeMX 生成的初始化源码，含应用接入代码 |
| Drivers | IAR 编译需要的 ST HAL、CMSIS 驱动源码及原许可证 |
| ScopeReceiver/Middlewares | USB MSC 导出使用的 ST USB Device 源码及许可证 |
| EWARM | IAR 工程、下载配置、启动汇编、Flash 链接配置 |
| tools/post_generate.py | CubeMX 再生成代码后的 IAR 应用接入恢复脚本 |

本包已移除 GCC/LLVM 构建与烧录脚本、GCC 和 Keil 工程、主机测试、验证日志、历史修复记录、备用固件、所有编译产物、IAR 缓存及未使用的链接脚本。保留的 ST 驱动是源码依赖；CMSIS 自带的编译器兼容头文件属于库的组成部分。

## CubeMX 重新生成代码之后

仅修改 App 并在 IAR 中编译时，不需要运行脚本。若使用 CubeMX 的 Generate Code，请按以下顺序操作：

1. 打开相应 .ioc，工具链仍选 EWARM，最低 V8.32，并保留用户代码（Keep User Code）。固件包版本是 STM32Cube FW_F7 V1.17.4。若固件包路径提示失效，在 CubeMX 中选择本机对应版本的固件包。
2. 生成完成后，在对应 ScopeSender 或 ScopeReceiver 根目录运行 `python tools/post_generate.py`。本机的 Python 是 C:\allpython\anaconda\python.exe；脚本只使用 Python 标准库，无额外模块依赖。
3. 若两端均重新生成，两端都要运行各自脚本。重新打开 IAR 工作区并 Rebuild All。

脚本恢复 App 文件引用、头文件路径、main/FMC 应用入口、High/Speed 优化、DMA 内存布局及接收端 USB 配置。它不编译或烧录，不依赖其他工具链；已移除其中 Keil 处理代码。保留它是为了防止重新生成后再出现“找不到 sender_app.h/scope_app.h”或缓冲配置回退的问题。

脚本会恢复预设的部分 USER CODE 区域；若自行修改这些接入区域，先保留自己的修改。未执行必要恢复时，IAR 的 Run_tools_post_generate_py_after_CubeMX_Generate_Code 提示用于阻止编译配置回退的固件。

## 手写应用代码速查

- 发送端 sender_app.c：应用启动、任务循环、LCD 状态与 PWM 控制；sender_capture.c：双 ADC 与两组 GPIO 的定时 DMA 同步采样、四路完成汇合和 64 块发送队列；sender_codec.c：样本打包和 CRC；sender_trigger.c：采集端触发；sender_net.c：以太网数据发送及控制配置接收。
- 接收端 scope_app.c：触摸界面、绘图与任务调度；scope_core.c：数据解析、连续样本窗口和波形测量；scope_net.c：以太网数据接收与控制发送；scope_disk.c：CSV、BMP 和 USB 只读磁盘内容。
- 两端 scope_control.c：SCTL 配置协议；scope_font.c：界面字体数据。详细帧格式见《通信协议.md》。
