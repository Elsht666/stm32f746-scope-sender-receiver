#include "scope_app.h"
#include <string.h>
#include <stdio.h>
/* A frozen, read-only FAT12 superfloppy, exposed through USB MSC.
   This module is also compiled on the host for filesystem validation. */
#ifndef SCOPE_HOST_TEST
#define DISK ((uint8_t*)0xC0200000u)
#else
static uint8_t host_disk[1048576];
#define DISK host_disk
#endif
#define SECTORS 2048u
#define DATA_SECTOR 17u
static volatile int ready;
static char csv_text[32768];
static uint16_t next_cluster;
static unsigned dir_entry;
static void put16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void put32(uint8_t *p,uint32_t v){put16(p,(uint16_t)v);put16(p+2,(uint16_t)(v>>16));}
static void fat(uint16_t cluster,uint16_t value){
  for(int copy=0;copy<2;copy++){
    uint8_t *f=DISK+(1+copy*6)*512;unsigned o=cluster+cluster/2;
    if(cluster&1){f[o]=(uint8_t)((f[o]&15)|(value<<4));f[o+1]=(uint8_t)(value>>4);}
    else{f[o]=(uint8_t)value;f[o+1]=(uint8_t)((f[o+1]&0xF0)|(value>>8));}
  }
}
static uint8_t *file(const char name[11],uint32_t size){
  uint16_t first=next_cluster,n=(uint16_t)((size+511)/512);uint8_t *d=DISK+13*512+dir_entry++*32;
  memcpy(d,name,11);d[11]=0x21; /* archive + read-only */
  put16(d+24,(uint16_t)((46<<9)|(10<<5)|26)); /* 2026-10-26, no RTC configured */
  put16(d+26,first);put32(d+28,size);
  for(unsigned i=0;i<n;i++)fat(next_cluster++,i+1==n?0xFFF:(uint16_t)(first+i+1));
  return DISK+(DATA_SECTOR+first-2)*512;
}
void Scope_DiskBuild(const ScopeFrame *frame,const uint16_t *pixels){
  ready=0;memset(DISK,0,1048576);next_cluster=2;dir_entry=0;
  uint8_t *b=DISK;b[0]=0xEB;b[1]=0x3C;b[2]=0x90;memcpy(b+3,"SCOPERX ",8);
  put16(b+11,512);b[13]=1;put16(b+14,1);b[16]=2;put16(b+17,64);put16(b+19,SECTORS);b[21]=0xF8;
  put16(b+22,6);put16(b+24,1);put16(b+26,1);b[36]=0x80;b[38]=0x29;
  put32(b+39,0x7462026);memcpy(b+43,"SCOPE_RX   ",11);memcpy(b+54,"FAT12   ",8);b[510]=0x55;b[511]=0xAA;
  fat(0,0xFF8);fat(1,0xFFF);
  static const char info[]="STM32F746G-DISCO receive-only oscilloscope\r\n"
    "WAVE.CSV: 400 displayed samples, 50 points/div, common time axis.\r\n"
    "SCREEN.BMP: exact 480 x 272 RGB screenshot at SAVE.\r\n"
    "Files are frozen until the next SAVE; RAM is cleared on reset.\r\n"
    "Unplug CN13 before SAVE again; then reconnect to refresh host cache.\r\n"
    "No PC is needed for reception, display, trigger or measurement.\r\n";
  memcpy(file("README  TXT",sizeof(info)-1),info,sizeof(info)-1);
  uint8_t *csv=(uint8_t*)csv_text;size_t pos=0;
  pos+=(size_t)snprintf((char*)csv,32768,"time_us,CH1_mV,CH2_mV,D0,D1,D2,channel_mask,sample_index\r\n");
  for(unsigned i=0;i<SCOPE_POINTS;i++){
    uint32_t s=frame->sample[i],a=(s&4095)*frame->vref/4095,bv=((s>>12)&4095)*frame->vref/4095;
    pos+=(size_t)snprintf((char*)csv+pos,32768-pos,"%lu,%lu,%lu,%lu,%lu,%lu,%u,%lu\r\n",
      (unsigned long)((uint64_t)i*frame->step*1000000/frame->rate),(unsigned long)a,(unsigned long)bv,
      (unsigned long)((s>>24)&1),(unsigned long)((s>>25)&1),(unsigned long)((s>>26)&1),frame->channels,
      (unsigned long)(frame->first_index+i*frame->step));
  }
  memcpy(file("WAVE    CSV",(uint32_t)pos),csv,pos);
  uint8_t *bmp=file("SCREEN  BMP",54+480*272*3);bmp[0]='B';bmp[1]='M';put32(bmp+2,54+480*272*3);
  put32(bmp+10,54);put32(bmp+14,40);put32(bmp+18,480);put32(bmp+22,272);put16(bmp+26,1);put16(bmp+28,24);put32(bmp+34,480*272*3);
  for(unsigned y=0;y<272;y++)for(unsigned x=0;x<480;x++){
    uint16_t p=pixels[(271-y)*480+x];uint8_t *q=bmp+54+(y*480+x)*3;
    q[0]=(uint8_t)((p&31)*255/31);q[1]=(uint8_t)(((p>>5)&63)*255/63);q[2]=(uint8_t)((p>>11)*255/31);
  }
  ready=1;
}
int Scope_DiskReady(void){return ready;}
int Scope_DiskRead(uint8_t *buf,uint32_t sector,uint16_t count){
  if(!ready||sector>=SECTORS||count>SECTORS-sector)return -1;
  memcpy(buf,DISK+sector*512,(size_t)count*512);return 0;
}
#ifdef SCOPE_HOST_TEST
int Scope_DiskDump(const char *path){FILE *f=fopen(path,"wb");if(!f)return -1;size_t n=fwrite(DISK,1,1048576,f);fclose(f);return n==1048576?0:-1;}
#endif
