#include "scope_app.h"
#include "scope_net.h"
#include "main.h"
#include "fmc.h"
#include "i2c.h"
#include "ltdc.h"
#include "usb_device.h"
#include "usbd_core.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#define FB0 ((uint16_t*)0xC0000000u)
#define FB1 ((uint16_t*)0xC0040000u)
#define RING ((uint32_t*)0xC0100000u)
#define SHOT ((uint16_t*)0xC0140000u)
#define SNAPSHOT ((uint32_t*)0xC0180000u)
#define BG 0x0841
#define WHITE 0xFFFF
#define GRID 0x2965
#define MUTED 0x8C71
static const uint16_t colors[5]={0xFFE0,0x07FF,0x07E0,0xF81F,0xFD20};
static const char *names[5]={"CH1","CH2","D0","D1","D2"};
static const char *tb_names[5]={"10ms","5ms","1ms","500us","100us"};
static const char *modes[3]={"AUTO","NORMAL","SINGLE"};
static ScopeStream stream;
static ScopeConfig config={0,31,1,0,0,2048};
static ScopeFrame shown,reference;
static uint16_t *draw=FB1,*front=FB0;
static uint32_t screen_tick,touch_tick,fps_tick,frames,fps,last_packet;
static uint8_t paused,has_frame,compare,has_reference,touch_was_down,button_was_down,measure_channel=2;
static uint8_t no_data;
static uint8_t history_count,history_index,history_next;
static ScopeFrame history[8];
static char notice[48];
static char status_text[80];
static uint32_t status_tick;
static uint8_t status_flags=255;
static uint16_t status_color;
volatile uint32_t scope_timing_ms[3];
extern const uint8_t scope_font[95][12];
extern USBD_HandleTypeDef hUsbDeviceFS;
void Scope_DiskBuild(const ScopeFrame *f,const uint16_t *pixels);
static void pixel(int x,int y,uint16_t c){if((unsigned)x<480&&(unsigned)y<272)draw[y*480+x]=c;}
static void rect(int x,int y,int w,int h,uint16_t c){for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++)pixel(i,j,c);}
static void line(int x0,int y0,int x1,int y1,uint16_t c){
  int dx=abs(x1-x0),sx=x0<x1?1:-1,dy=-abs(y1-y0),sy=y0<y1?1:-1,e=dx+dy;
  for(;;){pixel(x0,y0,c);if(x0==x1&&y0==y1)break;int e2=e*2;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}
}
static void text(int x,int y,uint16_t color,const char *fmt,...){
  char str[100];va_list a;va_start(a,fmt);vsnprintf(str,sizeof(str),fmt,a);va_end(a);
  for(const char *p=str;*p&&x<478;p++,x+=7){unsigned ch=(unsigned char)*p;if(ch<32||ch>126)ch='?';
    for(int j=0;j<12;j++)for(int i=0;i<7;i++)if(scope_font[ch-32][j]&(1u<<(6-i)))pixel(x+i,y+j,color);
  }
}
static void button(int x,int y,int w,const char *label,uint16_t c,int active){
  rect(x,y,w-2,22,active?0x2124:0x1082);line(x,y+21,x+w-3,y+21,c);text(x+4,y+5,active?c:MUTED,"%s",label);
}
static void net_poll(void){Scope_NetPoll(&stream);}
static void wave(const ScopeFrame *f,int ghost){
  for(int ch=0;ch<5;ch++){
    if(!(f->channels&(1u<<ch)))continue;
    uint16_t color=ghost?0x632C:colors[ch];int oldy=0;
    for(unsigned i=0;i<SCOPE_POINTS;i++){
      uint32_t p=f->sample[i];int y;
      if(ch<2)y=169-(int)(((p>>(ch*12))&4095)*120/4095);
      else y=190+(ch-2)*21-((p>>(24+ch-2))&1)*11;
      if(i){if(ch<2)line(39+i,oldy,40+i,y,color);else{line(39+i,oldy,40+i,oldy,color);line(40+i,oldy,40+i,y,color);}}
      oldy=y;
    }
    net_poll();
  }
}
static void render(void){
  /* The previous request must have completed before its old buffer is reused. */
  if(hltdc.Instance->SRCR&LTDC_SRCR_VBR)return;
  for(int y=0;y<272;y++){for(int x=0;x<480;x++)draw[y*480+x]=BG;if(y%24==0)net_poll();}
  button(0,0,80,tb_names[config.timebase],WHITE,1);
  for(int i=0;i<5;i++)button(80+i*46,0,46,names[i],colors[i],(config.channels>>i)&1);
  button(310,0,80,paused?"RUN":"PAUSE",WHITE,1);button(390,0,90,"SAVE USB",WHITE,has_frame);
  if(has_frame){
    text(2,26,colors[0],"CH1 %lumV %lu.%luHz",(unsigned long)shown.vpp_mv[0],(unsigned long)(shown.frequency_mhz[0]/1000),(unsigned long)(shown.frequency_mhz[0]%1000/100));
    text(242,26,colors[1],"CH2 %lumV %lu.%luHz",(unsigned long)shown.vpp_mv[1],(unsigned long)(shown.frequency_mhz[1]/1000),(unsigned long)(shown.frequency_mhz[1]%1000/100));
    int ch=measure_channel;
    text(2,38,colors[ch],"%s %lu.%luHz HIGH %luus",names[ch],(unsigned long)(shown.frequency_mhz[ch]/1000),(unsigned long)(shown.frequency_mhz[ch]%1000/100),(unsigned long)shown.width_us[ch-2]);
    text(300,38,MUTED,"%luSa/s %luFPS",(unsigned long)shown.rate,(unsigned long)fps);
  }else{
    if(!Scope_NetLink())text(2,26,WHITE,"Ethernet link down: check CN9");
    else if(!stream.started)text(2,26,WHITE,"LINK up: waiting for valid data");
    else if(!Scope_NetControlAck(&stream))text(2,26,WHITE,"Waiting for sender config ACK");
    else{
      uint32_t rate=stream.rate?stream.rate:500000u;
      uint32_t step=(uint32_t)((uint64_t)rate*scope_timebase_us[config.timebase]/50000000u);
      uint32_t need=step*(SCOPE_POINTS-1u)+1u;
      if(stream.valid<need)text(2,26,WHITE,"Buffering: %lu/%lu samples",(unsigned long)stream.valid,(unsigned long)need);
      else text(2,26,WHITE,config.mode?"Waiting for trigger":"Preparing waveform");
    }
  }
  for(int i=0;i<=8;i++)line(40+i*50,49,40+i*50,233,GRID);
  for(int i=0;i<=4;i++)line(40,49+i*30,440,49+i*30,GRID);
  for(int i=0;i<3;i++){line(40,190+i*21,440,190+i*21,GRID);text(2,178+i*21,colors[i+2],"D%d",i);}
  uint16_t scale=has_frame?shown.vref:stream.vref;
  text(2,49,MUTED,"%lu.%luV",(unsigned long)(scale/1000),(unsigned long)(scale%1000/100));text(2,158,MUTED,"0V");
  text(443,65,MUTED,"50");text(443,78,MUTED,"pts");text(443,91,MUTED,"/div");
  if(has_frame){
    if(compare&&has_reference&&reference.step==shown.step&&reference.rate==shown.rate&&reference.vref==shown.vref)wave(&reference,1);
    wave(&shown,0);
  }
  if(config.source<2){int y=169-(int)((uint32_t)config.level*120/4095);for(int x=40;x<440;x+=8)line(x,y,x+2,y,colors[config.source]);}
  char src[12];snprintf(src,sizeof(src),"TR:%s",names[config.source]);
  button(0,236,70,src,colors[config.source],1);button(70,236,60,modes[config.mode],WHITE,1);
  button(130,236,50,config.falling?"FALL":"RISE",WHITE,1);button(180,236,26,"-",WHITE,1);
  text(208,242,WHITE,"%lumV",(unsigned long)((uint32_t)config.level*(stream.vref?stream.vref:3300)/4095));
  button(266,236,26,"+",WHITE,1);button(292,236,60,compare?"CMP ON":"REF",WHITE,1);
  button(352,236,60,"HIST",WHITE,history_count>0);button(412,236,68,"MEAS",colors[measure_channel],1);
  if(notice[0])text(2,260,WHITE,"%s",notice);
  else{
    int linked=Scope_NetLink(),ack=Scope_NetControlAck(&stream);
    uint8_t flags=(uint8_t)((linked?1:0)|(paused?2:0)|(no_data?4:0)|(ack?8:0));
    uint32_t now=HAL_GetTick();
    /* Keep the fast waveform redraw independent from the readable 1Hz footer.
       Link, pause, timeout and configuration changes still appear promptly. */
    if(flags!=status_flags||now-status_tick>=1000u){
      const char *state=paused?"HOLD":(no_data?"NO DATA":(!ack?"CFG WAIT":(has_frame&&shown.triggered?"HW TRIG":"AUTO")));
      snprintf(status_text,sizeof(status_text),"%-7s %-8s RX:%10lu LOSS:%10lu CRC:%10lu",linked?"LINK":"NO LINK",state,(unsigned long)stream.packets,(unsigned long)stream.lost,(unsigned long)stream.bad);
      status_color=linked?0x07E0:0xF800;status_tick=now;status_flags=flags;
    }
    text(2,260,status_color,"%s",status_text);
  }
  /* Swap during vertical blank; never draw into a pending front buffer. */
  SCB_CleanDCache_by_Addr((uint32_t*)draw,480*272*2);
  HAL_LTDC_SetAddress_NoReload(&hltdc,(uint32_t)draw,0);
  HAL_LTDC_Reload(&hltdc,LTDC_RELOAD_VERTICAL_BLANKING);
  /* Next frame starts >=40ms later; vertical blank completes asynchronously. */
  uint16_t *old=front;front=draw;draw=old;
}
static void export_frame(void){
  if(!has_frame){snprintf(notice,sizeof(notice),"No received frame to save");return;}
  paused=1;
  render(); /* Keep CSV and screenshot synchronized after a history selection. */
  /* Disk contents remain immutable while the host is reading them. */
  USBD_Stop(&hUsbDeviceFS);HAL_Delay(30);
  memcpy(SHOT,front,480*272*2);Scope_DiskBuild(&shown,SHOT);
  USBD_Start(&hUsbDeviceFS);
  snprintf(notice,sizeof(notice),"Saved: unplug/replug USB CN13 to read files");
}
static void action(unsigned x,unsigned y){
  notice[0]=0;
  if(y<24){
    if(x<80){
      if(paused)snprintf(notice,sizeof(notice),"Resume before changing timebase");
      else{config.timebase=(config.timebase+1)%5;has_frame=0;compare=0;last_packet=0;}
    }
    else if(x<310){config.channels^=1u<<((x-80)/46);shown.channels=config.channels&stream.channels;}
    else if(x<390){paused=!paused;if(!paused){Scope_NetConfigure(&config,1);has_frame=0;last_packet=0;}}
    else export_frame();
  }else if(y>=236&&y<259){
    if(x<70)config.source=(config.source+1)%5;
    else if(x<130){config.mode=(config.mode+1)%3;paused=0;}
    else if(x<180)config.falling=!config.falling;
    else if(x<206)config.level=config.level>128?config.level-128:0;
    else if(x>=266&&x<292)config.level=config.level<3967?config.level+128:4095;
    else if(x>=292&&x<352){if(!has_reference&&has_frame){reference=shown;has_reference=1;}compare=!compare;}
    else if(x>=352&&x<412&&history_count){
      paused=1;shown=history[(history_next+7-history_index)%8];history_index=(history_index+1)%history_count;has_frame=1;config.channels=shown.channels;
      for(unsigned t=0;t<5;t++)if((uint64_t)shown.step*50000000/shown.rate==scope_timebase_us[t])config.timebase=(uint8_t)t;
    }
    else if(x>=412)measure_channel=measure_channel==4?2:measure_channel+1;
  }else if(y>=49&&y<=169&&config.source<2){config.level=(uint16_t)((169-y)*4095/120);}
}
static void input(void){
  uint8_t t[5]={0};int down=0;unsigned x=0,y=0;
  if(HAL_I2C_Mem_Read(&hi2c3,0x70,0x02,I2C_MEMADD_SIZE_8BIT,t,5,2)==HAL_OK){
    down=(t[0]&15)>0;
    /* FT5336 on this board has TS_SWAP_XY in ST's BSP. */
    y=((t[1]&15)<<8)|t[2];x=((t[3]&15)<<8)|t[4];
    if(x>=480||y>=272)down=0;
  }
  if(down&&!touch_was_down)action(x,y);
  touch_was_down=(uint8_t)down;
  int btn=HAL_GPIO_ReadPin(GPIOI,GPIO_PIN_11)==GPIO_PIN_SET;
  if(btn&&!button_was_down){paused=!paused;notice[0]=0;if(!paused){Scope_NetConfigure(&config,1);has_frame=0;last_packet=0;}}
  button_was_down=(uint8_t)btn;
}
void Scope_MemoryInit(void){
  MPU_Region_InitTypeDef region={0};HAL_MPU_Disable();region.Enable=MPU_REGION_ENABLE;
  region.Number=MPU_REGION_NUMBER0;region.BaseAddress=0xC0000000;region.Size=MPU_REGION_SIZE_8MB;
  region.AccessPermission=MPU_REGION_FULL_ACCESS;region.IsBufferable=MPU_ACCESS_BUFFERABLE;
  region.IsCacheable=MPU_ACCESS_CACHEABLE;region.IsShareable=MPU_ACCESS_NOT_SHAREABLE;
  region.TypeExtField=MPU_TEX_LEVEL1;region.DisableExec=MPU_INSTRUCTION_ACCESS_DISABLE;
  HAL_MPU_ConfigRegion(&region);
  /* Ethernet descriptors, packet pool and CPU globals stay noncached in SRAM.
     Only CPU-owned SDRAM uses write-back cache; LCD buffers are cleaned above. */
  region.Number=MPU_REGION_NUMBER1;region.BaseAddress=0x20000000;region.Size=MPU_REGION_SIZE_512KB;
  region.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;region.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;region.IsShareable=MPU_ACCESS_SHAREABLE;
  HAL_MPU_ConfigRegion(&region);HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
  FMC_SDRAM_CommandTypeDef c={0};c.CommandTarget=FMC_SDRAM_CMD_TARGET_BANK1;c.AutoRefreshNumber=1;
  c.CommandMode=FMC_SDRAM_CMD_CLK_ENABLE;if(HAL_SDRAM_SendCommand(&hsdram1,&c,1000)!=HAL_OK)Error_Handler();
  HAL_Delay(1);c.CommandMode=FMC_SDRAM_CMD_PALL;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_AUTOREFRESH_MODE;c.AutoRefreshNumber=8;HAL_SDRAM_SendCommand(&hsdram1,&c,1000);
  c.CommandMode=FMC_SDRAM_CMD_LOAD_MODE;c.AutoRefreshNumber=1;c.ModeRegisterDefinition=0x230; /* burst 1, CAS 3, write single */
  HAL_SDRAM_SendCommand(&hsdram1,&c,1000);HAL_SDRAM_ProgramRefreshRate(&hsdram1,1542); /* 100MHz, 64ms/4096 minus 20 */
  volatile uint32_t *test=RING;test[0]=0x55AA1234;test[1]=0xAA55FEDC;
  if(test[0]!=0x55AA1234||test[1]!=0xAA55FEDC)Error_Handler();
}
void Scope_AppInit(void){
  /* MPU keeps all Ethernet DMA memory noncached; SDRAM is write-back cached. */
  if(SCB->CCR&SCB_CCR_DC_Msk)SCB_DisableDCache();
  SCB_EnableICache();SCB_EnableDCache();
  memset(FB0,0,480*272*2);memset(FB1,0,480*272*2);
  SCB_CleanDCache_by_Addr((uint32_t*)FB0,480*272*2);
  Scope_Reset(&stream,RING);stream.vref=3300;Scope_SetServiceHook(net_poll);
  uint8_t zero=0;HAL_I2C_Mem_Write(&hi2c3,0x70,0xA4,I2C_MEMADD_SIZE_8BIT,&zero,1,20);
  Scope_NetInit();Scope_NetConfigure(&config,1);render();
}
void Scope_AppTask(void){
  uint32_t tick=HAL_GetTick();net_poll();
  if(tick-touch_tick>=20){touch_tick=tick;input();}
  if(Scope_NetConfigure(&config,0)){has_frame=0;last_packet=0;compare=0;}
  if(tick-fps_tick>=1000){fps=frames;frames=0;fps_tick=tick;}
  if(tick-screen_tick<40)return;
  screen_tick=tick;
  if(!paused&&Scope_NetControlAck(&stream)&&stream.packets!=last_packet){
    /* Work from an immutable copy while the model pumps live Ethernet RX. */
    uint32_t measure_tick=HAL_GetTick();
    ScopeStream frozen=stream;memcpy(SNAPSHOT,RING,SCOPE_RING_SIZE*sizeof(uint32_t));frozen.ring=SNAPSHOT;
    scope_timing_ms[0]=HAL_GetTick()-measure_tick;measure_tick=HAL_GetTick();
    ScopeFrame next;int result=Scope_MakeFrame(&frozen,&config,&next);
    scope_timing_ms[1]=HAL_GetTick()-measure_tick;
    if(result==1&&(!has_frame||next.first_index!=shown.first_index)){
      shown=next;has_frame=1;last_packet=stream.packets;frames++;
      if(config.mode==2)paused=1;
      history[history_next]=shown;history_next=(history_next+1)%8;if(history_count<8)history_count++;history_index=0;
    }else if(result<0)snprintf(notice,sizeof(notice),"Source rate too low for 50 points/div");
  }
  /* net_poll() and Scope_MakeFrame() may receive packets after the entry tick.
     Read time after those calls: entry_tick - newer_last_tick would wrap and
     falsely report a timeout while live data is arriving. Keep RX counters
     visible even during a real outage instead of replacing them with notice. */
  no_data=(uint8_t)(!paused&&stream.started&&HAL_GetTick()-stream.last_tick>500u);
  uint32_t render_tick=HAL_GetTick();render();scope_timing_ms[2]=HAL_GetTick()-render_tick;
}
