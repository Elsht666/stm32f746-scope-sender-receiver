#ifndef SCOPE_APP_H
#define SCOPE_APP_H
#include <stdint.h>
#include "scope_core.h"
void Scope_AppInit(void);
void Scope_MemoryInit(void);
void Scope_AppTask(void);
int Scope_DiskReady(void);
int Scope_DiskRead(uint8_t *buf,uint32_t sector,uint16_t count);
#endif
