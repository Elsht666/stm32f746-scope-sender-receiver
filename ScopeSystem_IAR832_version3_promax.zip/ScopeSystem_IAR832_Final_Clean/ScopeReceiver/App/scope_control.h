#ifndef SCOPE_CONTROL_H
#define SCOPE_CONTROL_H
#include <stdint.h>
#include <stddef.h>
#define CONTROL_FRAME_BYTES 70u
typedef struct {
  uint8_t timebase,channels,source,mode,falling;
  uint16_t level;
  uint32_t session,revision;
} ScopeControl;
void Control_Encode(uint8_t out[CONTROL_FRAME_BYTES],const ScopeControl *c);
int Control_Decode(const uint8_t *frame,size_t bytes,ScopeControl *c);
#endif
