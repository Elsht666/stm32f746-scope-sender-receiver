#ifndef SCOPE_CORE_H
#define SCOPE_CORE_H
#include <stdint.h>
#include <stddef.h>
#define SCOPE_POINTS 400u
#define SCOPE_RING_SIZE 65536u
#define SCOPE_PORT 5000u
#define SCOPE_MAX_SAMPLES 256u
typedef struct {
  uint8_t timebase, channels, source, mode, falling;
  uint16_t level;
} ScopeConfig;
typedef struct {
  uint32_t sample[SCOPE_POINTS];
  uint32_t rate, step, first_index;
  uint16_t vref;
  uint8_t channels, triggered;
  uint32_t frequency_mhz[5], width_us[3];
  uint16_t vpp_mv[2];
} ScopeFrame;
typedef struct {
  uint32_t *ring, write, valid, next_index, sequence, rate;
  uint32_t packets, bad, lost, stale, last_tick, generation;
  uint16_t vref;
  uint8_t channels, started;
  uint32_t control_session,control_revision,trigger_history[8];
  uint8_t protocol,control_valid,trigger_count,trigger_next;
} ScopeStream;
extern const uint32_t scope_timebase_us[5];
void Scope_Reset(ScopeStream *s, uint32_t *ring);
uint32_t Scope_CRC32(const uint8_t *a, size_t n, const uint8_t *b, size_t m);
int Scope_Ingest(ScopeStream *s, const uint8_t *data, size_t len, uint32_t tick);
int Scope_MakeFrame(const ScopeStream *s, const ScopeConfig *cfg, ScopeFrame *f);
void Scope_SetServiceHook(void (*hook)(void));
/* Validates a complete Ethernet/IPv4/UDP frame; returns the SCOP payload. */
const uint8_t *Scope_UDP(const uint8_t *eth, size_t len, size_t *payload_len);
#endif
