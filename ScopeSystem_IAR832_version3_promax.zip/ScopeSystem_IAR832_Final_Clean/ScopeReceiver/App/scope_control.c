#include "scope_control.h"
#include <string.h>
static uint16_t le16(const uint8_t *p){return p[0]|(uint16_t)p[1]<<8;}
static uint32_t le32(const uint8_t *p){return le16(p)|(uint32_t)le16(p+2)<<16;}
static uint16_t be16(const uint8_t *p){return (uint16_t)p[0]<<8|p[1];}
static void pl16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void pl32(uint8_t *p,uint32_t v){pl16(p,(uint16_t)v);pl16(p+2,(uint16_t)(v>>16));}
static void pb16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static uint32_t crc(const uint8_t *p,size_t n){uint32_t c=0xffffffffu;for(size_t i=0;i<n;i++){c^=p[i];for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xedb88320u:0);}return c^0xffffffffu;}
static uint32_t sum(const uint8_t *p,size_t n,uint32_t s){while(n>=2){s+=be16(p);p+=2;n-=2;}if(n)s+=(uint16_t)*p<<8;return s;}
static uint16_t fold(uint32_t s){while(s>>16)s=(s&65535)+(s>>16);return (uint16_t)s;}
void Control_Encode(uint8_t *e,const ScopeControl *c){
  memset(e,0,CONTROL_FRAME_BYTES);memset(e,255,6);const uint8_t mac[6]={2,0,0,0,7,0x46};memcpy(e+6,mac,6);pb16(e+12,0x800);
  uint8_t *ip=e+14;ip[0]=0x45;pb16(ip+2,CONTROL_FRAME_BYTES-14);pb16(ip+6,0x4000);ip[8]=64;ip[9]=17;ip[12]=192;ip[13]=168;ip[14]=7;ip[15]=2;memset(ip+16,255,4);pb16(ip+10,(uint16_t)~fold(sum(ip,20,0)));
  uint8_t *u=ip+20;pb16(u,5002);pb16(u+2,5003);pb16(u+4,36);
  uint8_t *p=u+8;memcpy(p,"SCTL",4);p[4]=1;p[5]=c->timebase;p[6]=c->channels;p[7]=c->source;p[8]=c->mode;p[9]=c->falling;pl16(p+10,c->level);pl32(p+12,c->session);pl32(p+16,c->revision);pl32(p+24,crc(p,24));
}
int Control_Decode(const uint8_t *e,size_t n,ScopeControl *c){
  if(n<CONTROL_FRAME_BYTES||be16(e+12)!=0x800)return 0;
  const uint8_t *ip=e+14;size_t h=(ip[0]&15)*4;
  if((ip[0]>>4)!=4||h<20||n<14+h+36||ip[9]!=17||(be16(ip+6)&0x3fff)||be16(ip+2)!=h+36||fold(sum(ip,h,0))!=65535)return 0;
  if(!(ip[16]==255&&ip[17]==255&&ip[18]==255&&ip[19]==255))return 0;
  const uint8_t *u=ip+h;if(be16(u+2)!=5003||be16(u+4)!=36)return 0;
  if(be16(u+6)&&fold(sum(u,36,sum(ip+12,8,17+36)))!=65535)return 0;
  const uint8_t *p=u+8;
  if(memcmp(p,"SCTL",4)||p[4]!=1||p[5]>4||(p[6]&~31u)||p[7]>4||p[8]>2||p[9]>1||le16(p+10)>4095||!le32(p+12)||le32(p+20)||le32(p+24)!=crc(p,24))return 0;
  memset(c,0,sizeof(*c));c->timebase=p[5];c->channels=p[6];c->source=p[7];c->mode=p[8];c->falling=p[9];c->level=le16(p+10);c->session=le32(p+12);c->revision=le32(p+16);return 1;
}
