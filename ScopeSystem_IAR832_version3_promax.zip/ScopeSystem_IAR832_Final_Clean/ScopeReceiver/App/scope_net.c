#include "scope_net.h"
#include "eth.h"
#include <string.h>
#include "scope_control.h"
/* MPU keeps DMA SRAM noncached; CPU-owned SDRAM uses write-back cache. */
#define POOL_COUNT (ETH_RX_DESC_CNT+4)
typedef struct RxSlot { uint8_t data[1536]; struct RxSlot *next; uint16_t len; uint8_t used; } RxSlot;
static RxSlot pool[POOL_COUNT] __attribute__((aligned(32)));
static uint32_t phy_address,check_tick;
static int link_up,phy_found;
static ScopeControl controller;
static uint32_t control_tick;
static uint8_t control_ready,control_due,control_retries;
static uint8_t control_frame[CONTROL_FRAME_BYTES] __attribute__((aligned(32)));
int Scope_NetConfigure(const ScopeConfig *c,int rearm){
  int changed=!control_ready||controller.timebase!=c->timebase||controller.channels!=c->channels||controller.source!=c->source||controller.mode!=c->mode||controller.falling!=c->falling||controller.level!=c->level;
  if(changed||rearm){
    if(!controller.session)controller.session=(HAL_GetTick()^SysTick->VAL^*(const uint32_t*)UID_BASE)|1u;
    controller.timebase=c->timebase;controller.channels=c->channels;controller.source=c->source;controller.mode=c->mode;controller.falling=c->falling;controller.level=c->level;
    controller.revision++;control_ready=1;control_due=1;control_retries=3;return 1;
  }
  return 0;
}
int Scope_NetControlAck(const ScopeStream *s){return control_ready&&s->protocol==2&&s->control_valid&&s->control_session==controller.session&&s->control_revision==controller.revision;}
static void send_control(uint32_t tick){
  if(!link_up||!control_ready)return;
  if(!control_due&&tick-control_tick<(control_retries?100u:1000u))return;
  Control_Encode(control_frame,&controller);
  ETH_BufferTypeDef b={0};b.buffer=control_frame;b.len=CONTROL_FRAME_BYTES;
  ETH_TxPacketConfigTypeDef tx={0};tx.Attributes=ETH_TX_PACKETS_FEATURES_CRCPAD;tx.CRCPadCtrl=ETH_CRC_PAD_INSERT;tx.Length=CONTROL_FRAME_BYTES;tx.TxBuffer=&b;
  if(HAL_ETH_Transmit(&heth,&tx,2)==HAL_OK){if(control_retries)control_retries--;}
  control_due=0; /* Failed transmissions also back off; never retry per pump(). */
  control_tick=tick;
}
void HAL_ETH_RxAllocateCallback(uint8_t **buf){
  *buf=0;for(unsigned i=0;i<POOL_COUNT;i++)if(!pool[i].used){pool[i].used=1;pool[i].len=0;pool[i].next=0;*buf=pool[i].data;break;}
}
void HAL_ETH_RxLinkCallback(void **start,void **end,uint8_t *buf,uint16_t len){
  RxSlot *s=(RxSlot*)buf;s->len=len;
  if(!*start)*start=s;else ((RxSlot*)*end)->next=s;
  *end=s;
}
static void update_link(void){
  uint32_t bsr=0,status=0;int now=0;
  if(!phy_found)return;
  HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr);
  if(HAL_ETH_ReadPHYRegister(&heth,phy_address,1,&bsr)==HAL_OK&&(bsr&4)){
    if(HAL_ETH_ReadPHYRegister(&heth,phy_address,31,&status)==HAL_OK&&(status&0x1000))now=1;
  }
  if(now==link_up)return;
  if(link_up)HAL_ETH_Stop(&heth);
  if(now){
    ETH_MACConfigTypeDef mac;
    HAL_ETH_GetMACConfig(&heth,&mac);
    uint32_t mode=status&0x1C;
    mac.Speed=(mode==0x08||mode==0x18)?ETH_SPEED_100M:ETH_SPEED_10M;
    mac.DuplexMode=(mode==0x14||mode==0x18)?ETH_FULLDUPLEX_MODE:ETH_HALFDUPLEX_MODE;
    HAL_ETH_SetMACConfig(&heth,&mac);
    if(HAL_ETH_Start(&heth)!=HAL_OK)now=0;
    control_due=1; /* Configuration frames only; ADC data travels in the opposite direction. */
  }
  link_up=now;
}
void Scope_NetInit(void){
  memset(pool,0,sizeof(pool));
  for(uint32_t p=0;p<32;p++){
    uint32_t id1=0,id2=0;
    if(HAL_ETH_ReadPHYRegister(&heth,p,2,&id1)==HAL_OK&&HAL_ETH_ReadPHYRegister(&heth,p,3,&id2)==HAL_OK&&id1==0x0007&&(id2&0xFFF0)==0xC130){phy_address=p;phy_found=1;break;}
  }
  if(phy_found){
    /* Restart autonegotiation; never force a duplex mismatch. */
    HAL_ETH_WritePHYRegister(&heth,phy_address,0,0x1200);
  }
  update_link();
}
int Scope_NetLink(void){return link_up;}
void Scope_NetPoll(ScopeStream *stream){
  uint32_t tick=HAL_GetTick();
  if(tick-check_tick>=200){check_tick=tick;update_link();}
  if(!link_up)return;
  send_control(tick);
  for(unsigned n=0;n<32;n++){
    RxSlot *packet=0;
    if(HAL_ETH_ReadData(&heth,(void**)&packet)!=HAL_OK)break;
    if(packet){
      size_t len=0;const uint8_t *p=packet->next?0:Scope_UDP(packet->data,packet->len,&len);
      if(p)Scope_Ingest(stream,p,len,tick);
      while(packet){RxSlot *next=packet->next;packet->used=0;packet=next;}
    }
  }
}
