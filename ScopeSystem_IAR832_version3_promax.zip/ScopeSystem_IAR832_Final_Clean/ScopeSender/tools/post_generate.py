"""Run after STM32CubeMX Generate Code to integrate the sender application."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
def block(path,tag,code):
    p=ROOT/path;s=p.read_text();pattern=r'(/\* USER CODE BEGIN '+re.escape(tag)+r' \*/).*?(/\* USER CODE END '+re.escape(tag)+r' \*/)'
    s,n=re.subn(pattern,lambda m:m[1]+'\n'+code+'\n  '+m[2],s,flags=re.S)
    if n!=1:raise RuntimeError(f'{path}: expected one {tag}, got {n}')
    p.write_text(s)
def main():
    header=ROOT/'Inc/stm32f7xx_hal_conf.h'
    content=header.read_text()
    if '#include "scope_project_config.h"' not in content:
        content=content.replace('/* USER CODE END Header */','#include "scope_project_config.h"\n/* USER CODE END Header */',1)
        header.write_text(content)
    block('Src/main.c','Includes','#include "sender_app.h"')
    block('Src/main.c','2','  Sender_AppInit();')
    block('Src/main.c','3','    Sender_AppTask();\n  }')
    block('Src/fmc.c','0','#include "sender_app.h"')
    block('Src/fmc.c','FMC_Init 2','  Sender_MemoryInit();')
    block('Src/eth.c','MACADDRESS','  MACAddr[0]=2; MACAddr[1]=0; MACAddr[2]=0; MACAddr[3]=0; MACAddr[4]=7; MACAddr[5]=0x47;')
    p=ROOT/'Src/eth.c';s=p.read_text();s=re.sub(r'#if defined \( __ICCARM__ \).*?#endif',
      '/* All DMA memory is in SRAM1/2, not DTCM. */\n'
      'ETH_DMADescTypeDef DMARxDscrTab[ETH_RX_DESC_CNT] __attribute__((aligned(32)));\n'
      'ETH_DMADescTypeDef DMATxDscrTab[ETH_TX_DESC_CNT] __attribute__((aligned(32)));',s,count=1,flags=re.S);p.write_text(s)
    p=ROOT/'Inc/stm32f7xx_hal_conf.h';s=p.read_text();mark='/* Sender descriptor counts */';s=re.sub(re.escape(mark)+r'.*?\n\n','',s,flags=re.S)
    s=s.replace('#define HAL_MODULE_ENABLED',mark+'\n#ifndef ETH_RX_DESC_CNT\n#define ETH_RX_DESC_CNT 16U\n#endif\n#ifndef ETH_TX_DESC_CNT\n#define ETH_TX_DESC_CNT 4U\n#endif\n\n#define HAL_MODULE_ENABLED',1);p.write_text(s)
    integrate_iar()
    print('Sender application integrated.')

def integrate_iar():
    """Preserve the custom application when CubeMX generates EWARM projects."""
    project=ROOT/'EWARM/ScopeSender.ewp'
    if not project.exists():return
    tree=ET.parse(project)
    for config in tree.findall('configuration'):
        for option in config.findall('.//option'):
            name=option.findtext('name')
            if name in ('CCOptLevel','CCOptStrategy','CCOptStrategySlave'):
                option.find('state').text='3' if name=='CCOptLevel' else '2'
            if name=='CCDefines':
                for item in list(option.findall('state')):
                    if (item.text or '').startswith('SCOPE_IAR_INTEGRATED'):option.remove(item)
                ET.SubElement(option,'state').text='SCOPE_IAR_INTEGRATED=3'
            if name=='CCIncludePath2':
                paths=[s.text for s in option.findall('state')]
                if '$PROJ_DIR$/../App' not in paths:
                    ET.SubElement(option,'state').text='$PROJ_DIR$/../App'
            elif name=='IlinkMapFile':option.find('state').text='1'
            elif name=='IlinkIcfOverride':option.find('state').text='1'
            elif name=='IlinkIcfFile':option.find('state').text='$PROJ_DIR$/stm32f746xx_flash.icf'
    groups=tree.getroot()
    for group in list(groups):
        if group.tag=='group' and (group.findtext('name') or '').startswith('Application/'):
            groups.remove(group)
    group=ET.SubElement(groups,'group')
    ET.SubElement(group,'name').text='Application/Sender'
    for source in sorted((ROOT/'App').glob('*.c')):
        entry=ET.SubElement(group,'file')
        ET.SubElement(entry,'name').text='$PROJ_DIR$/../App/'+source.name
    entry=ET.SubElement(group,'file')
    ET.SubElement(entry,'name').text='$PROJ_DIR$/../Inc/scope_project_config.h'
    normalize_iar_sources(tree)
    ET.indent(tree,space='  ')
    tree.write(project,encoding='utf-8',xml_declaration=True)
    icf=ROOT/'EWARM/stm32f746xx_flash.icf'
    s=icf.read_text()
    s=re.sub(r'(__ICFEDIT_region_RAM_start__\s*=\s*)0x[0-9A-Fa-f]+',r'\g<1>0x20010000',s)
    icf.write_text(s)

def normalize_iar_sources(tree):
    """Repair CubeMX absolute entries and remove duplicate source references."""
    for entry in tree.findall('.//file/name'):
        value=(entry.text or '').replace('\\','/')
        marker='/'+ROOT.name+'/'
        if marker in value:
            rel=value.rsplit(marker,1)[1]
            if not (ROOT/rel).is_file():raise RuntimeError('Missing source: '+value)
            entry.text='$PROJ_DIR$/../'+rel
    seen=set()
    for parent in tree.iter():
        for item in list(parent):
            if item.tag!='file' or item.find('name') is None:continue
            value=(item.findtext('name') or '').replace('\\','/')
            if not value.startswith('$PROJ_DIR$/'):raise RuntimeError('Nonportable source: '+value)
            source=(ROOT/'EWARM'/value.replace('$PROJ_DIR$/','')).resolve()
            if not source.is_file() or not source.is_relative_to(ROOT.resolve()):
                raise RuntimeError('Invalid source: '+value)
            if source in seen:parent.remove(item)
            else:seen.add(source)

if __name__=='__main__':main()
