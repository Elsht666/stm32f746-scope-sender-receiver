#ifndef SCOPE_PROJECT_CONFIG_H
#define SCOPE_PROJECT_CONFIG_H
/* This file and its include in the HAL header USER CODE region survive CubeMX. */
#if defined(__ICCARM__) && (!defined(SCOPE_IAR_INTEGRATED) || SCOPE_IAR_INTEGRATED != 3)
#error Run_tools_post_generate_py_after_CubeMX_Generate_Code
#endif
#ifndef ETH_RX_DESC_CNT
#define ETH_RX_DESC_CNT 16U
#endif
#ifndef ETH_TX_DESC_CNT
#define ETH_TX_DESC_CNT 4U
#endif
#if ETH_RX_DESC_CNT != 16U || ETH_TX_DESC_CNT != 4U
#error Incorrect_Ethernet_descriptor_counts_run_tools_post_generate_py
#endif
#endif
