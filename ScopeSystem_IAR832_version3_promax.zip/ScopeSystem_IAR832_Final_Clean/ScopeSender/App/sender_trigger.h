#ifndef SENDER_TRIGGER_H
#define SENDER_TRIGGER_H
#include "scope_control.h"
typedef struct {ScopeControl control;uint32_t index,seen;uint16_t previous;uint8_t primed,valid;} SenderTrigger;
void Sender_TriggerReset(SenderTrigger *t,const ScopeControl *c);
void Sender_TriggerBlock(SenderTrigger *t,const uint32_t *ch1,const uint32_t *ch2,const uint32_t *gpio_a,const uint32_t *gpio_i,uint32_t first,unsigned count);
static inline uint8_t Sender_DigitalBits(uint32_t pa,uint32_t pi){return (uint8_t)(((pa>>15)&1u)|(((pi>>3)&1u)<<1)|(((pi>>2)&1u)<<2));}
#endif
