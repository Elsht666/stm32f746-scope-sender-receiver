#include "sender_trigger.h"
#include <string.h>
void Sender_TriggerReset(SenderTrigger *t,const ScopeControl *c){memset(t,0,sizeof(*t));t->control=*c;}
void Sender_TriggerBlock(SenderTrigger *t,const uint32_t *a,const uint32_t *b,const uint32_t *pa,const uint32_t *pi,uint32_t first,unsigned count){
  static const uint32_t holdoff[5]={40000,20000,4000,2000,400};
  for(unsigned i=0;i<count;i++){
    unsigned source=t->control.source;uint16_t value=source==0?(uint16_t)(a[i]&4095):source==1?(uint16_t)(b[i]&4095):(uint16_t)((Sender_DigitalBits(pa[i],pi[i])>>(source-2))&1);
    uint16_t level=source<2?t->control.level:(t->control.falling?0:1);uint32_t index=first+i;
    int edge=t->primed&&(t->control.falling?(t->previous>level&&value<=level):(t->previous<level&&value>=level));
    /* Accumulate the quarter-screen pretrigger history before arming.
       Otherwise SINGLE could latch an edge at sample 1 and never obtain
       the samples that should precede it. 'seen' also works across wrap. */
    uint32_t pre=holdoff[t->control.timebase]/4;
    if(edge&&t->seen>=pre&&(!t->valid||(t->control.mode!=2&&(uint32_t)(index-t->index)>=holdoff[t->control.timebase]))){t->index=index;t->valid=1;}
    if(t->seen<pre)t->seen++;
    t->previous=value;t->primed=1;
  }
}
