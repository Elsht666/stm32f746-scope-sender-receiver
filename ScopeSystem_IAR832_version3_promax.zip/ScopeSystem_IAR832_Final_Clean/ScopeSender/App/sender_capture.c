#include "sender_app.h"
#include "sender_codec.h"
#ifdef SENDER_CAPTURE_HOST_TEST
#include "capture_mock_hal.h"
#else
#include "adc.h"
#include "tim.h"
#endif
#include <string.h>
#define DMA_COUNT (SENDER_BLOCK*2u)
#define QUEUE_COUNT 64u
static uint32_t analog1[DMA_COUNT] __attribute__((aligned(32)));
static uint32_t analog2[DMA_COUNT] __attribute__((aligned(32)));
static uint32_t digital[DMA_COUNT] __attribute__((aligned(32)));
static uint32_t digital_a[DMA_COUNT] __attribute__((aligned(32)));
static ScopeControl control={0,31,1,0,0,2048,0,0},pending_control;
static uint8_t control_pending;
static SenderTrigger trigger;
typedef struct {uint8_t data[SENDER_FRAME_BYTES];} __attribute__((aligned(32))) Packet;
static Packet queue[QUEUE_COUNT];
static volatile uint32_t head,tail;
static uint32_t sample_index,packet_sequence;
static volatile uint8_t ready_mask[2];
volatile uint32_t sender_blocks,sender_drops,sender_sent,sender_errors,sender_restarts;
volatile uint16_t sender_ch1_raw,sender_ch2_raw;
volatile uint8_t sender_digital,sender_running,sender_fault;
volatile uint32_t sender_dma_events[8];
extern DMA_HandleTypeDef hdma_tim8_up;
extern DMA_HandleTypeDef hdma_tim8_ch1;
void Sender_ControlSubmit(const ScopeControl *c){pending_control=*c;control_pending=1;}
static void completed(unsigned half,unsigned bit){
  if(!sender_running)return;
  sender_dma_events[(bit==1?0:bit==2?2:bit==4?4:6)+half]++;
  if(ready_mask[half]&bit){sender_fault=1;sender_errors++;return;}
  ready_mask[half]|=(uint8_t)bit;
  if(ready_mask[half]!=15)return;
  ready_mask[half]=0;sender_blocks++;
  unsigned off=half*SENDER_BLOCK;
  sender_ch1_raw=(uint16_t)analog2[off];sender_ch2_raw=(uint16_t)analog1[off];sender_digital=Sender_DigitalBits(digital_a[off],digital[off]);
  uint32_t seq=packet_sequence++,first=sample_index;sample_index+=SENDER_BLOCK;
  uint32_t current_head=head;
  uint32_t current_tail=tail;
  Sender_TriggerBlock(&trigger,analog2+off,analog1+off,digital_a+off,digital+off,first,SENDER_BLOCK);
  if(current_head-current_tail>=QUEUE_COUNT){sender_drops++;return;}
  Sender_Packet(queue[current_head&(QUEUE_COUNT-1)].data,analog2+off,analog1+off,digital_a+off,digital+off,seq,first,0,&trigger);
  __DMB();head=current_head+1;
}
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *h){completed(0,h->Instance==ADC1?1:2);}
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *h){completed(1,h->Instance==ADC1?1:2);}
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *h){(void)h;sender_fault=1;sender_errors++;}
static void gpio_half(DMA_HandleTypeDef *h){(void)h;completed(0,4);}
static void gpio_full(DMA_HandleTypeDef *h){(void)h;completed(1,4);}
static void gpio_a_half(DMA_HandleTypeDef *h){(void)h;completed(0,8);}
static void gpio_a_full(DMA_HandleTypeDef *h){(void)h;completed(1,8);}
static void gpio_error(DMA_HandleTypeDef *h){(void)h;sender_fault=1;sender_errors++;}
void Sender_CaptureInit(void){Sender_CodecInit();Sender_CaptureSet(1);}
void Sender_CaptureSet(int enabled){
  sender_running=0;HAL_TIM_OC_Stop(&htim8,TIM_CHANNEL_1);HAL_TIM_Base_Stop(&htim8);__HAL_TIM_DISABLE_DMA(&htim8,TIM_DMA_UPDATE|TIM_DMA_CC1);
  HAL_ADC_Stop_DMA(&hadc1);HAL_ADC_Stop_DMA(&hadc3);HAL_DMA_Abort(&hdma_tim8_up);HAL_DMA_Abort(&hdma_tim8_ch1);
  ready_mask[0]=ready_mask[1]=0;head=tail=0;sample_index=packet_sequence=0;sender_fault=0;
  Sender_TriggerReset(&trigger,&control);
  if(!enabled)return;
  hdma_tim8_up.XferHalfCpltCallback=gpio_half;hdma_tim8_up.XferCpltCallback=gpio_full;hdma_tim8_up.XferErrorCallback=gpio_error;
  hdma_tim8_ch1.XferHalfCpltCallback=gpio_a_half;hdma_tim8_ch1.XferCpltCallback=gpio_a_full;hdma_tim8_ch1.XferErrorCallback=gpio_error;
  if(HAL_DMA_Start_IT(&hdma_tim8_up,(uint32_t)&GPIOI->IDR,(uint32_t)digital,DMA_COUNT)!=HAL_OK)Error_Handler();
  if(HAL_DMA_Start_IT(&hdma_tim8_ch1,(uint32_t)&GPIOA->IDR,(uint32_t)digital_a,DMA_COUNT)!=HAL_OK)Error_Handler();
  if(HAL_ADC_Start_DMA(&hadc1,(uint32_t*)analog1,DMA_COUNT)!=HAL_OK)Error_Handler();
  if(HAL_ADC_Start_DMA(&hadc3,(uint32_t*)analog2,DMA_COUNT)!=HAL_OK)Error_Handler();
  /* First tick wraps ARR to zero, generating UPDATE and CC1 together.
     This avoids a GPIOA sample occurring one period before the ADC samples. */
  __HAL_TIM_SET_COUNTER(&htim8,__HAL_TIM_GET_AUTORELOAD(&htim8));__HAL_TIM_CLEAR_FLAG(&htim8,TIM_FLAG_UPDATE|TIM_FLAG_CC1);
  __HAL_TIM_ENABLE_DMA(&htim8,TIM_DMA_UPDATE|TIM_DMA_CC1);Sender_NewSession();sender_running=1;
  if(HAL_TIM_OC_Start(&htim8,TIM_CHANNEL_1)!=HAL_OK)Error_Handler();
}
void Sender_CaptureService(void){
  if(control_pending){int running=sender_running;control=pending_control;control_pending=0;Sender_CaptureSet(running);}
  if(sender_fault){sender_restarts++;Sender_CaptureSet(1);}
  /* Send promptly; at 100Mbit/s one frame takes about 90us on the wire. */
  for(unsigned i=0;i<8;i++){
    uint32_t current_tail=tail;
    uint32_t current_head=head;
    if(current_tail==current_head)break;
    Packet *p=&queue[current_tail&(QUEUE_COUNT-1)];__DMB();
    if(Sender_NetLink()&&Sender_NetSpeed()==100){
      if(Sender_Send(p->data))sender_sent++;else sender_errors++;
    }
    __DMB();tail=current_tail+1;
  }
}
void Sender_PWMSet(uint32_t freq,int enabled){
  if(freq<100)freq=100;
  if(freq>10000)freq=10000;
  HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_1);
  uint32_t ticks=(1000000u+freq/2)/freq;
  __HAL_TIM_SET_AUTORELOAD(&htim3,ticks-1);__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,ticks/2);__HAL_TIM_SET_COUNTER(&htim3,0);
  htim3.Instance->EGR=TIM_EGR_UG;
  if(enabled)HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
}
uint32_t Sender_PWMFrequency(void){return 1000000u/(__HAL_TIM_GET_AUTORELOAD(&htim3)+1);}
